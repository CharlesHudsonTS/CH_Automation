package com.ch.ta.utils.constants;

public interface ObjectConstants
{
    public static final String URL                                      = "url";

    public static final String SHOW_PWD_BUTTON                          = "SHOW_PWD_BUTTON";

    public static final String HIDE_PWD_BUTTON                          = "HIDE_PWD_BUTTON";

    public static final String KEEP_IN_CONTACT_LINK                     = "KEEP_IN_CONTACT_LINK";

    public static final String MY_ACCOUNT_LINK                          = "MY_ACCOUNT_LINK";

    public static final String ACCOUNT_DETAILS_LINK_HOME                = "ACCOUNT_DETAILS_LINK_HOME";

    public static final String ORDER_HISTORY_LINK_HOME                  = "ORDER_HISTORY_LINK_HOME";

    public static final String SIGN_OUT_LINK                            = "SIGN_OUT_LINK";

    public static final String ACCOUNT_DETAILS_TAB                      = "ACCOUNT_DETAILS_TAB";

    public static final String ORDER_HISTORY_TAB                        = "ORDER_HISTORY_TAB";

    public static final String EDIT_PERSONAL_INFO                       = "EDIT_PERSONAL_INFO";

    public static final String EDIT_PASSWORD_SECURITY                   = "EDIT_PASSWORD_SECURITY";

    public static final String EDIT_COMMUNICATION_PREFERENCE            = "EDIT_COMMUNICATION_PREFERENCE";

    public static final String CURRENT_PWD_BOX                          = "CURRENT_PWD_BOX";

    public static final String NEW_PWD_BOX                              = "NEW_PWD_BOX";

    public static final String CONFIRM_NEW_PWD_BOX                      = "CONFIRM_NEW_PWD_BOX";

    public static final String SAVE_NEW_PWD_BUTTON                      = "SAVE_NEW_PWD_BUTTON";

    public static final String CANCEL_EDIT_PWD_BUTTON                   = "CANCEL_EDIT_PWD_BUTTON";

    public static final String MINIMIZE_PERSONAL_INFO                   = "MINIMIZE_PERSONAL_INFO";

    public static final String MINIMIZE_PASSWORD_SECURITY               = "MINIMIZE_PASSWORD_SECURITY";

    public static final String MINIMIZE_COMMUNICATION_PREFERENCE        = "MINIMIZE_COMMUNICATION_PREFERENCE";

    public static final String MINIMIZE_MY_INSTALLERS                   = "MINIMIZE_MY_INSTALLERS";

    public static final String CREATE_ACC_TITLE                         = "CREATE_ACC_TITLE";

    public static final String CREATE_ACC_STATIC_TEXT                   = "CREATE_ACC_STATIC_TEXT";

    public static final String SIGN_IN_CREATE_ACC                       = "SIGN_IN_CREATE_ACC";

    public static final String SETUP_UR_SECTION_TITLE                   = "SETUP_UR_SECTION_TITLE";

    public static final String EMAIL_ADDRESS_NOTE                       = "EMAIL_ADDRESS_NOTE";

    public static final String PASSWORD_REQ                             = "PASSWORD_REQ";

    public static final String AGREE_TERMS_N_COND                       = "AGREE_TERMS_N_COND";

    public static final String TELL_US_ABT_URSELF_TITLE                 = "TELL_US_ABT_URSELF_TITLE";

    public static final String TELL_US_ABT_URSELF_STATIC_TEXT           = "TELL_US_ABT_URSELF_STATIC_TEXT";

    public static final String FIRST_NAME                               = "FIRST_NAME";

    public static final String LAST_NAME                                = "LAST_NAME";

    public static final String ADDRESS_LINE1                            = "ADDRESS_LINE1";

    public static final String ADDRESS_LINE2                            = "ADDRESS_LINE2";

    public static final String CITY                                     = "CITY";

    public static final String STATE                                    = "STATE";

    public static final String ZIPCODE                                  = "ZIPCODE";

    public static final String PHONE_NUM                                = "PHONE_NUM";

    public static final String ALT_PHONE_NUM                            = "ALT_PHONE_NUM";

    public static final String PERSONAL_INFO_LABEL                      = "PERSONAL_INFO_LABEL";

    public static final String PERSONAL_INFO_NAME                       = "PERSONAL_INFO_NAME";

    public static final String PERSONAL_INFO_ALT_PHONE                  = "PERSONAL_INFO_ALT_PHONE";

    public static final String PERSONAL_INFO_MOB_PHONE                  = "PERSONAL_INFO_MOB_PHONE";

    public static final String PERSONAL_INFO_BDAY_MONTH                 = "PERSONAL_INFO_BDAY_MONTH";

    public static final String PERSONAL_INFO_ADDRESS                    = "PERSONAL_INFO_ADDRESS";

    public static final String PASSWORD_SECURITY_LABEL                  = "PASSWORD_SECURITY_LABEL";

    public static final String PASSWORD_SECURITY_USERNAME               = "PASSWORD_SECURITY_USERNAME";

    public static final String PASSWORD_SECURITY_PASSWORD               = "PASSWORD_SECURITY_PASSWORD";

    public static final String COMMN_PREFERENCE_LABEL                   = "COMMN_PREFERENCE_LABEL";

    public static final String COMMN_PREFERENCE_REMINDERS               = "COMMN_PREFERENCE_REMINDERS";

    public static final String COMMN_PREFERENCE_PROMOTIONS              = "COMMN_PREFERENCE_PROMOTIONS";

    public static final String MY_PREFERED_INSTALLERS_LABEL             = "MY_PREFERED_INSTALLERS_LABEL";

    public static final String MY_PREFERED_INSTALLERS_LIST1             = "MY_PREFERED_INSTALLERS_LIST1";

    public static final String MY_PREFERED_INSTALLERS_LIST2             = "MY_PREFERED_INSTALLERS_LIST2";

    public static final String MY_PREFERED_INSTALLERS_MAPS              = "MY_PREFERED_INSTALLERS_MAPS";

    public static final String ACCORDION_INSTALLER1                     = "ACCORDION_INSTALLER1";

    public static final String INSTALLER_REMOVE_BUTTON                  = "INSTALLER_REMOVE_BUTTON";

    public static final String REMOVE_INSTALLER                         = "REMOVE_INSTALLER";

    public static final String SEARCH_ORDERS_BOX                        = "SEARCH_ORDERS_BOX";

    public static final String FILTER_BY_VEHICLE                        = "FILTER_BY_VEHICLE";

    public static final String FILTER_BY_DATE                           = "FILTER_BY_DATE";

    public static final String SORT_BY_ORDER_HIS                        = "SORT_BY_ORDER_HIS";

    public static final String SEARCH_ORDERS                            = "SEARCH_ORDERS";

    public static final String FILTER_BY_VEHICLE_ST                     = "FILTER_BY_VEHICLE_ST";

    public static final String FILTER_BY_DATE_ST                        = "FILTER_BY_DATE_ST";

    public static final String SORT_BY_ST                               = "SORT_BY_ST";

    public static final String ORDER_NAME_LINK                          = "ORDER_NAME_LINK";

    public static final String ORDER_DATE                               = "ORDER_DATE";

    public static final String ORDER_NUMBER                             = "ORDER_NUMBER";

    public static final String ORDER_TOTAL                              = "ORDER_TOTAL";

    public static final String ORDER_STATUS                             = "ORDER_STATUS";

    public static final String ITEMS_ORDERED                            = "ITEMS_ORDERED";

    public static final String YOUR_ORDER_STATIC_TEXT                   = "YOUR_ORDER_STATIC_TEXT";

    public static final String TRACKING_NUMBER                          = "TRACKING_NUMBER";

    public static final String ORDER_DETAILS                            = "ORDER_DETAILS";

    public static final String SHIPPING_DETAILS                         = "SHIPPING_DETAILS";

    public static final String PAYMENT_INFO                             = "PAYMENT_INFO";

    public static final String ORDER_ITEMS                              = "ORDER_ITEMS";

    public static final String ORDER_SUMMARY                            = "ORDER_SUMMARY";

    public static final String HEADER_TA_LOGO                           = "HEADER_TA_LOGO";

    public static final String HEADER_PHONE_NUMBER                      = "HEADER_PHONE_NUMBER";

    public static final String HEADER_LIVE_CHAT                         = "HEADER_LIVE_CHAT";

    public static final String HEADER_CUSTOMER_SERVICES                 = "HEADER_CUSTOMER_SERVICES";

    public static final String HEADER_CUSTOMER_SERVICES_CONTACT_US      = "HEADER_CUSTOMER_SERVICES_CONTACT_US";

    public static final String HEADER_CUSTOMER_SERVICES_ORDER_STATUS    = "HEADER_CUSTOMER_SERVICES_ORDER_STATUS";

    public static final String HEADER_CUSTOMER_SERVICES_RETURE_REPLACE  = "HEADER_CUSTOMER_SERVICES_RETURE_REPLACE";

    public static final String HEADER_CUSTOMER_SERVICES_FAQ             = "HEADER_CUSTOMER_SERVICES_FAQ";

    public static final String HEADER_FINANCING_OPTION                  = "HEADER_FINANCING_OPTION";

    public static final String HEADER_LANGAUGE_LINK                     = "HEADER_LANGAUGE_LINK";

    public static final String HEADER_LANGAUGE_OPTION1                  = "HEADER_LANGAUGE_OPTION1";

    public static final String HEADER_LANGAUGE_OPTION2                  = "HEADER_LANGAUGE_OPTION2";

    public static final String HEADER_LANGAUGE_OPTION3                  = "HEADER_LANGAUGE_OPTION3";

    public static final String HEADER_SIGNIN_REGISTRATION               = "HEADER_SIGNIN_REGISTRATION";

    public static final String HEADER_MY_ACCOUNT_LINK                   = "HEADER_MY_ACCOUNT_LINK";

    public static final String HEADER_MYACCOUNT_ACCOUNT_DETAILS         = "HEADER_MYACCOUNT_ACCOUNT_DETAILS";

    public static final String HEADER_MYACCOUNT_MY_GARAGE               = "HEADER_MYACCOUNT_MY_GARAGE";

    public static final String HEADER_MYACCOUNT_ORDER_HISTORY           = "HEADER_MYACCOUNT_ORDER_HISTORY";

    public static final String HEADER_MAIN_NAV_TIRES                    = "HEADER_MAIN_NAV_TIRES";

    public static final String HEADER_TIRE_SHOP_BY_VEHICLE              = "HEADER_TIRE_SHOP_BY_VEHICLE";

    public static final String HEADER_TIRE_SHOP_BY_TIRE_SIZE            = "HEADER_TIRE_SHOP_BY_TIRE_SIZE";

    public static final String HEADER_TIRE_SHOP_BY_BRAND                = "HEADER_TIRE_SHOP_BY_BRAND";

    public static final String HEADER_TIRE_SHOP_BY_TIRE_TYPE            = "HEADER_TIRE_SHOP_BY_TIRE_TYPE";

    public static final String HEADER_TIRE_DEALS_ADD                    = "HEADER_TIRE_DEALS_ADD";

    public static final String HEADER_KNOWLEDGE_CENTER                  = "HEADER_KNOWLEDGE_CENTER";

    public static final String HEADER_MAIN_NAV_DEALS                    = "HEADER_MAIN_NAV_DEALS";

    public static final String HEADER_INSTALLERS                        = "HEADER_INSTALLERS";

    public static final String HEADER_SEARCHBOX                         = "HEADER_SEARCHBOX";

    public static final String HEADER_SEARCHBOX_ICON                    = "HEADER_SEARCHBOX_ICON";

    public static final String HEADER_CART                              = "HEADER_CART";

    public static final String FOOTER_SIGNUP_ALERT_BOX                  = "FOOTER_SIGNUP_ALERT_BOX";

    public static final String FOOTER_SIGNUP_ALERT_BUTTON               = "FOOTER_SIGNUP_ALERT_BUTTON";

    public static final String FOOTER_SIGNUP_ALERT_TEXT                 = "FOOTER_SIGNUP_ALERT_TEXT";

    public static final String FOOTER_SOCIAL_MEDIA_TIWTTER              = "FOOTER_SOCIAL_MEDIA_TIWTTER";

    public static final String FOOTER_SOCIAL_MEDIA_FACEBOOK             = "FOOTER_SOCIAL_MEDIA_FACEBOOK";

    public static final String FOOTER_SOCIAL_MEDIA_INSTAGRAM            = "FOOTER_SOCIAL_MEDIA_INSTAGRAM";

    public static final String FOOTER_SOCIAL_MEDIA_TEXT                 = "FOOTER_SOCIAL_MEDIA_TEXT";

    public static final String FOOTER_WHY_BUYTIRES_BUYING_PROCESS       = "FOOTER_WHY_BUYTIRES_BUYING_PROCESS";

    public static final String FOOTER_WHY_BUYTIRES_PRICE_GUARANTEE      = "FOOTER_WHY_BUYTIRES_PRICE_GUARANTEE";

    public static final String FOOTER_WHY_BUYTIRES_RECOMMED_INSTALLER   = "FOOTER_WHY_BUYTIRES_RECOMMED_INSTALLER";

    public static final String FOOTER_WHY_BUYTIRES_TEXT                 = "FOOTER_WHY_BUYTIRES_TEXT";

    public static final String FOOTER_CUSTOMER_SERVICES_CONTACTUS       = "FOOTER_CUSTOMER_SERVICES_CONTACTUS";

    public static final String FOOTER_CUSTOMER_SERVICES_ORDER_STATUS    = "FOOTER_CUSTOMER_SERVICES_ORDER_STATUS";

    public static final String FOOTER_CUSTOMER_SERVICES_RETURNREPLACE   = "FOOTER_CUSTOMER_SERVICES_RETURNREPLACE";

    public static final String FOOTER_CUSTOMER_SERVICES_TEXT            = "FOOTER_CUSTOMER_SERVICES_TEXT";

    public static final String FOOTER_KNOWLEDGE_CENTER_TIRE_SIZECHART   = "FOOTER_KNOWLEDGE_CENTER_TIRE_SIZECHART";

    public static final String FOOTER_KNOWLEDGE_CENTER_TIRE_KNOWLEDGE   = "FOOTER_KNOWLEDGE_CENTER_TIRE_KNOWLEDGE";

    public static final String FOOTER_KNOWLEDGE_CENTER_ROUTINE          = "FOOTER_KNOWLEDGE_CENTER_ROUTINE";

    public static final String FOOTER_KNOWLEDGE_CENTER_TEXT             = "FOOTER_KNOWLEDGE_CENTER_TEXT";

    public static final String FOOTER_KNOWLEDGE_CENTER_ENVIRONMENTAL    = "FOOTER_KNOWLEDGE_CENTER_ENVIRONMENTAL";

    public static final String FOOTER_KNOWLEDGE_CENTER_BLOG             = "FOOTER_KNOWLEDGE_CENTER_BLOG";

    public static final String FOOTER_FINANCING_OPTION_BENEFITS         = "FOOTER_FINANCING_OPTION_BENEFITS";

    public static final String FOOTER_FINANCING_OPTION_PAY_BILL         = "FOOTER_FINANCING_OPTION_PAY_BILL";

    public static final String FOOTER_FINANCING_OPTION_APPLY_NOW        = "FOOTER_FINANCING_OPTION_APPLY_NOW";

    public static final String FOOTER_FINANCING_OPTION_TEXT             = "FOOTER_FINANCING_OPTION_TEXT";

    public static final String FOOTER_TIRE_INSTALLER_PROG_ABOUT         = "FOOTER_TIRE_INSTALLER_PROG_ABOUT";

    public static final String FOOTER_TIRE_INSTALLER_PROG_BECOME        = "FOOTER_TIRE_INSTALLER_PROG_BECOME";

    public static final String FOOTER_TIRE_INSTALLER_PROG_LOGIN         = "FOOTER_TIRE_INSTALLER_PROG_LOGIN";

    public static final String FOOTER_TIRE_INSTALLER_PROG_TEXT          = "FOOTER_TIRE_INSTALLER_PROG_TEXT";

    public static final String FOOTER_SITE_LOGO                         = "FOOTER_SITE_LOGO";

    public static final String FOOTER_TERMS_OF_SERVICES                 = "FOOTER_TERMS_OF_SERVICES";

    public static final String FOOTER_PRIVACY_POLICY                    = "FOOTER_PRIVACY_POLICY";

    public static final String FOOTER_COPY_RIGHT_TEXT                   = "FOOTER_COPY_RIGHT_TEXT";

    public static final String FOOTER_SITE_MAP                          = "FOOTER_SITE_MAP";

    public static final String FOOTER_CARD_LOGO1                        = "FOOTER_CARD_LOGO1";

    public static final String FOOTER_CARD_LOGO2                        = "FOOTER_CARD_LOGO2";

    public static final String FOOTER_CARD_LOGO3                        = "FOOTER_CARD_LOGO3";

    public static final String FOOTER_CARD_LOGO4                        = "FOOTER_CARD_LOGO4";

    public static final String FOOTER_CARD_LOGO5                        = "FOOTER_CARD_LOGO5";

    public static final String FOOTER_CARD_LOGO6                        = "FOOTER_CARD_LOGO6";

    public static final String FOOTER_CARD_LOGO7                        = "FOOTER_CARD_LOGO7";

    public static final String FOOTER_SOCIAL_MEDIA_WORDPRESS            = "FOOTER_SOCIAL_MEDIA_WORDPRESS";

    public static final String FOOTER_WHY_BUYTIRES_WHY_FROMUS           = "FOOTER_WHY_BUYTIRES_WHY_FROMUS";

    public static final String FOOTER_CUSTOMER_SERVICES_WARRANTY        = "FOOTER_CUSTOMER_SERVICES_WARRANTY";

    public static final String FOOTER_CUSTOMER_SERVICES_FAQ             = "FOOTER_CUSTOMER_SERVICES_FAQ";

    public static final String FOOTER_TA_ADVANTAGE_ABOUT_TA             = "FOOTER_TA_ADVANTAGE_ABOUT_TA";

    public static final String MY_GARAGE_TAB                            = "MY_GARAGE_TAB";

    public static final String MY_GARAGE_CAR_IMAGE                      = "MY_GARAGE_CAR_IMAGE";

    public static final String MY_GARAGE_TIRE_SIZE                      = "MY_GARAGE_TIRE_SIZE";

    public static final String HEADER_LOGO                              = "HEADER_LOGO";

    public static final String CONFIRM_PASSWORD_CREATE_ACC              = "CONFIRM_PASSWORD_CREATE_ACC";

    public static final String CREATE_YOUR_ACC_BUTTON                   = "CREATE_YOUR_ACC_BUTTON";

    public static final String TERMS_N_COND_LINK                        = "TERMS_N_COND_LINK";

    public static final String FORGOT_USERNAME_LINK                     = "FORGOT_USERNAME_LINK";

    public static final String FORGOT_PWD_LINK                          = "FORGOT_PWD_LINK";

    public static final String FORGET_PASSWORD_STATIC_TEXT              = "FORGET_PASSWORD_STATIC_TEXT";

    public static final String USERNAME_ERROR_MESSAGE                   = "USERNAME_ERROR_MESSAGE";

    public static final String PASSWORD_ERROR_MESSAGE                   = "PASSWORD_ERROR_MESSAGE";

    public static final String SIGN_IN_LINK                             = "SIGN_IN_LINK";

    public static final String SIGN_IN_BUTTON                           = "SIGN_IN_BUTTON";

    public static final String EMAIL_TEXTBOX                            = "EMAIL_TEXTBOX";

    public static final String PASSWORD_TEXTBOX                         = "PASSWORD_TEXTBOX";

    public static final String KEEP_ME_LOGGED_IN                        = "KEEP_ME_LOGGED_IN";

    public static final String FORGOT_USERNAME_PWD_LINK                 = "FORGOT_USERNAME_PWD_LINK";

    public static final String CREATE_AN_ACCOUNT_LINK_SIGNPAGE          = "CREATE_AN_ACCOUNT_LINK_SIGNPAGE";

    public static final String FACEBOOK_ICON                            = "FACEBOOK_ICON";

    public static final String TWITTER_ICON                             = "TWITTER_ICON";

    public static final String GOOGLE_ICON                              = "GOOGLE_ICON";

    public static final String YAHOO_ICON                               = "YAHOO_ICON";

    public static final String AOL_ICON                                 = "AOL_ICON";

    public static final String LINKED_IN_ICON                           = "LINKED_IN_ICON";

    public static final String WARNING_MESSAGE                          = "WARNING_MESSAGE";

    public static final String RESTORE_YOUR_ACC_LINK                    = "RESTORE_YOUR_ACC_LINK";

    public static final String SITE_LOGO_CREATE_ACCOUNT                 = "SITE_LOGO_CREATE_ACCOUNT";

    public static final String SIGN_IN_LINK_CREATE_ACC_PAGE             = "SIGN_IN_LINK_CREATE_ACC_PAGE";

    public static final String CREATE_ACC_WITH_EMAIL                    = "CREATE_ACC_WITH_EMAIL";

    public static final String BACK_TO_TOP_LINK                         = "BACK_TO_TOP_LINK";

    public static final String EMAIL_ADDRESS_CREATE_ACC                 = "EMAIL_ADDRESS_CREATE_ACC";

    public static final String PASSWORD_CREATE_ACC                      = "PASSWORD_CREATE_ACC";

    public static final String CREATE_AN_ACCOUNT_LINK                   = "CREATE_AN_ACCOUNT_LINK";

    public static final String ZIPCODE_CREATE_ACC                       = "ZIPCODE_CREATE_ACC";

    public static final String CONF_EMAIL_ADDRESS_CREATE_ACC            = "CONF_EMAIL_ADDRESS_CREATE_ACC";

    public static final String EMAIL_ADDRESS_CREATE_ACC_ERR_MSG         = "EMAIL_ADDRESS_CREATE_ACC_ERR_MSG";

    public static final String CONF_EMAIL_ADDRESS_CREATE_ACC_ERR_MSG    = "CONF_EMAIL_ADDRESS_CREATE_ACC_ERR_MSG";

    public static final String PASSWORD_CREATE_ACC_ERR_MSG              = "PASSWORD_CREATE_ACC_ERR_MSG";

    public static final String CONFIRM_PASSWORD_CREATE_ACC_ERR_MSG      = "CONFIRM_PASSWORD_CREATE_ACC_ERR_MSG";

    public static final String TERMS_N_COND_LINK_ERR_MSG                = "TERMS_N_COND_LINK_ERR_MSG";

    public static final String EXIST_EMAIL_ERROR_MSG                    = "EXIST_EMAIL_ERROR_MSG";

    public static final String HEADER_MYACCOUNT_SIGN_OUT                = "HEADER_MYACCOUNT_SIGN_OUT";

    public static final String FORGET_USERNAME_STATIC_TEXT              = "FORGET_USERNAME_STATIC_TEXT";

    public static final String INVALID_ERROR_MESSAGE                    = "INVALID_ERROR_MESSAGE";

    public static final String FORGOT_PWD_POPUP_CLOSE                   = "FORGOT_PWD_POPUP_CLOSE";

    public static final String FORGOT_PWD_EMAIL_TEXTBOX                 = "FORGOT_PWD_EMAIL_TEXTBOX";

    public static final String FORGOT_PASSWORD_CANCLE_BUTTON            = "FORGOT_PASSWORD_CANCLE_BUTTON";

    public static final String FORGOT_PASSWORD_SUBMIT_BUTTON            = "FORGOT_PASSWORD_SUBMIT_BUTTON";

    public static final String FORGOT_PASSWORD_NOTIFICATION_MESSAGE     = "FORGOT_PASSWORD_NOTIFICATION_MESSAGE";

    public static final String FORGOT_PASSWORD_INSTRUMENTAL_MESSAGE     = "FORGOT_PASSWORD_INSTRUMENTAL_MESSAGE";

    public static final String FORGOT_PASSWORD_ERROR_MESSAGE            = "FORGOT_PASSWORD_ERROR_MESSAGE";

    public static final String DISPLAY_SHOP_BY_VECHICLE                 = "DISPLAY_SHOP_BY_VECHICLE";

    public static final String MAKE_TEXT_BOX                            = "MAKE_TEXT_BOX";

    public static final String YEAR_TEXT_BOX                            = "YEAR_TEXT_BOX";

    public static final String MODEL_TEXT_BOX                           = "MODEL_TEXT_BOX";

    public static final String SUBMODEL_TEXT_BOX                        = "SUBMODEL_TEXT_BOX";

    public static final String SHOP_BUTTON                              = "SHOP_BUTTON";

    public static final String LICENCE_PLATE_NUMBER                     = "LICENCE_PLATE_NUMBER";

    public static final String SHOP_BY_TIRE_MAKE                        = "SHOP_BY_TIRE_MAKE";

    public static final String MAKE_ACCORDANT                           = "MAKE_ACCORDANT";

    public static final String YEAR_ACCORDANT                           = "YEAR_ACCORDANT";

    public static final String SHOP_BY_TIRE_YEAR                        = "SHOP_BY_TIRE_YEAR";

    public static final String MODEL_ACCORDANT                          = "MODEL_ACCORDANT";

    public static final String SHOP_BY_TIRE_MODEL                       = "SHOP_BY_TIRE_MODEL";

    public static final String SUBMODEL_ACCORDANT                       = "SUBMODEL_ACCORDANT";

    public static final String SHOP_BY_TIRE_SUBMODEL                    = "SHOP_BY_TIRE_SUBMODEL";

    public static final String DISPLY_STATE_TESTBOX                     = "DISPLY_STATE_TESTBOX";

    public static final String DISPLY_LICENCE_PLATE                     = "DISPLY_LICENCE_PLATE";

    public static final String SHOP_BUTTON_LICENSE                      = "SHOP_BUTTON_LICENSE";

    public static final String MMYE_LINK                                = "MMYE_LINK";

    public static final String SHOP_BY_TIRE_MAKE_ACURA                  = "SHOP_BY_TIRE_MAKE_ACURA";

    public static final String SHOP_BY_TIRE_YEAR_2018                   = "SHOP_BY_TIRE_YEAR_2018";

    public static final String SHOP_BY_TIRE_MODEL_RDX                   = "SHOP_BY_TIRE_MODEL_RDX";

    public static final String SHOP_BY_TIRE_SUBMODEL_BASE               = "SHOP_BY_TIRE_SUBMODEL_BASE";

    public static final String SHOP_BY_TYRE_TAB                         = "SHOP_BY_TYRE_TAB";

    public static final String WIDTH_ACCORDANT                          = "WIDTH_ACCORDANT";

    public static final String WIDTH_TAB                                = "WIDTH_TAB";

    public static final String RATIO_ACCORDANT                          = "RATIO_ACCORDANT";

    public static final String RATIO_TAB                                = "RATIO_TAB";

    public static final String DIAMETER_ACCORDANT                       = "DIAMETER_ACCORDANT";

    public static final String DIAMETER_TAB                             = "WIDTH_TAB";

    public static final String FORGET_USERNAME_INSTRUCTION_STATIC_TEXT  = "FORGET_USERNAME_INSTRUCTION_STATIC_TEXT";

    public static final String FORGET_USERNAME_CONTACT_US_STATIC_TEXT   = "FORGET_USERNAME_CONTACT_US_STATIC_TEXT";

    public static final String FORGET_USERNAME_TELEPHONE_NO_STATIC_TEXT = "FORGET_USERNAME_TELEPHONE_NO_STATIC_TEXT";

    public static final String FORGOT_USERNAME_CLOSE_BUTTON             = "FORGOT_USERNAME_CLOSE_BUTTON";

    public static final String FORGOT_PASSWORD_CONTACTNO_DILOG_WINDOW   = "FORGOT_PASSWORD_CONTACTNO_DILOG_WINDOW";

    public static final String ENJOY_BENEFITS                           = "ENJOY_BENEFITS";

    public static final String LISTOF_BENEFITS                          = "LISTOF_BENEFITS";

    public static final String INSTAGRAM_ICON                           = "INSTAGRAM_ICON";

    public static final String WORDPRESS_ICON                           = "WORDPRESS_ICON";

    public static final String DISPLAY_SETUP_ACCOUNT                    = "DISPLAY_SETUP_ACCOUNT";

    public static final String DISPLAY_EMAIL_ADDRESS                    = "DISPLAY_EMAIL_ADDRESS";

    public static final String DISPLAY_CONFIRM_EMAIL_ADDRESS            = "DISPLAY_CONFIRM_EMAIL_ADDRESS";

    public static final String DISPLAY_PASSWORD                         = "DISPLAY_PASSWORD";

    public static final String DISPLAY_CONFIRM_PASSWORD                 = "DISPLAY_CONFIRM_PASSWORD";

    public static final String DISPLAY_CREATEAN_ACCOUNT                 = "DISPLAY_CREATEAN_ACCOUNT";

    public static final String DISPLAY_ZIPCODE                          = "DISPLAY_ZIPCODE";

    public static final String DISPLAY_TIRE_AMERICA_TERMS               = "DISPLAY_TIRE_AMERICA_TERMS";

    public static final String CLICK_TIRE_AMERICA_TERMS                 = "CLICK_TIRE_AMERICA_TERMS";

    public static final String DISPLAY_TERMS_AND_CONDITIONS             = "DISPLAY_TERMS_AND_CONDITIONS";

    public static final String CONFIRM_EMAIL_TEXTBOX                    = "CONFIRM_EMAIL_TEXTBOX";

    public static final String CLICKON_EMAIL_ADDRESS                    = "CLICKON_EMAIL_ADDRESS";

    public static final String CLICKON_CONFIRM_EMAIL_ADDRESS            = "CLICKON_CONFIRM_EMAIL_ADDRESS";

    public static final String CLICKON_PASSWORD                         = "CLICKON_PASSWORD";

    public static final String CLICKON_CONFIRM_PASSWORD                 = "CLICKON_CONFIRM_PASSWORD";

    public static final String DISPLAY_SHOW_PWD                         = "DISPLAY_SHOW_PWD";

    public static final String DISPLAY_HIDE_PWD                         = "DISPLAY_HIDE_PWD";

    public static final String TIREAMERICA_LOGO                         = "TIREAMERICA_LOGO";

    public static final String PSWD_MATCH_CONFIRMATION                  = "PSWD_MATCH_CONFIRMATION";

    public static final String ATLEAST_NUMBERS                          = "ATLEAST_NUMBERS";

    public static final String DISPLAY_KEEPIN_CONTACT                   = "DISPLAY_KEEPIN_CONTACT";

    public static final String KEEP_IN_CONTACT                          = "KEEP_IN_CONTACT";

    public static final String CLICK_KEEP_IN_CONTACT_CHECKBOX           = "CLICK_KEEP_IN_CONTACT_CHECKBOX";

    public static final String KEEP_IN_CONTACT_CHECK                    = "KEEP_IN_CONTACT_CHECK";

    public static final String DISPLAY_MYACCOUNT                        = "DISPLAY_MYACCOUNT";

    public static final String LIST_OF_BENEFITS                         = "LIST_OF_BENEFITS";

    public static final String CREATE_AN_ACC_TITLE                      = "CREATE_AN_ACC_TITLE";

    public static final String CLICK_ZIPCODE                            = "CLICK_ZIPCODE";

    public static final String DISPLAY_EMAIL_ADDRESS_TITLE              = "DISPLAY_EMAIL_ADDRESS_TITLE";

    public static final String DISPLAY_CONFIRM_EMAIL_ADDRESS_TITLE      = "DISPLAY_CONFIRM_EMAIL_ADDRESS_TITLE";

    public static final String DISPLAY_PSWD_TITLE                       = "DISPLAY_PSWD_TITLE";

    public static final String DISPLAY_CONFIRMPSWD_TITLE                = "DISPLAY_CONFIRMPSWD_TITLE";

    public static final String DISPLAY_ZIPCODE_TITLE                    = "DISPLAY_ZIPCODE_TITLE";

    public static final String SHOW_CONFIRM_PWD_BUTTON                  = "SHOW_CONFIRM_PWD_BUTTON";

    public static final String DISPLAY_SHOW_CONFIRM_PWD                 = "DISPLAY_SHOW_CONFIRM_PWD";

    public static final String HIDE_CONFIRM_PWD_BUTTON                  = "HIDE_CONFIRM_PWD_BUTTON";

    public static final String DISPLAY_HIDE_CONFIRM_PWD                 = "DISPLAY_HIDE_CONFIRM_PWD";

    public static final String SELECT_CHECKBOX                          = "SELECT_CHECKBOX";

    public static final String DISPLAY_SUBSCRIBE_MAIL_TEXT              = "DISPLAY_SUBSCRIBE_MAIL_TEXT";

    public static final String DISPLAY_PSWD_CHARS                       = "DISPLAY_PSWD_CHARS";

    public static final String DISPLAY_PSWD_REQ_TITLE                   = "DISPLAY_PSWD_REQ_TITLE";

    public static final String DISPLAY_ATLEAST_EIGHT_CHARS              = "DISPLAY_ATLEAST_EIGHT_CHARS";

    public static final String DISPLAY_ATLEST_ONE_LETTER                = "DISPLAY_ATLEST_ONE_LETTER";

    public static final String DISPLAY_ATLEAST_ONE_NUMBER               = "DISPLAY_ATLEAST_ONE_NUMBER";

    public static final String DISPLAY_MATCH_CONFIRM                    = "DISPLAY_MATCH_CONFIRM";

    public static final String PASSWORD_CHARS                           = "PASSWORD_CHARS";

    public static final String ATLEST_ONE_LETTER                        = "ATLEST_ONE_LETTER";

    public static final String ATLEAST_ONE_NUMBER                       = "ATLEAST_ONE_NUMBER";

    public static final String ATLEAST_EIGHT_CHARS                      = "ATLEAST_EIGHT_CHARS";

    public static final String DISPLAY_EMPTY_PASSWORD                   = "DISPLAY_EMPTY_PASSWORD";

    public static final String DISPLAY_MESSAGE1                         = "DISPLAY_MESSAGE1";

    public static final String DISPLAY_MESSAGE                          = "DISPLAY_MESSAGE";

    public static final String DISPLAY_SHOP_BUTTON                      = "DISPLAY_SHOP_BUTTON";

    public static final String CLICK_SHOPTIRES_BYBRAND                  = "CLICK_SHOPTIRES_BYBRAND";

    public static final String CLICK_SHOPTIRES_BYTYPE                   = "CLICK_SHOPTIRES_BYTYPE";

    public static final String CLICK_SHOPTIRES_BYSIZE                   = "CLICK_SHOPTIRES_BYSIZE";

    public static final String GREEN_TICK_LETTER_REQ                    = "GREEN_TICK_LETTER_REQ";

    public static final String GREEN_TICK_NUMBER_REQ                    = "GREEN_TICK_NUMBER_REQ";

    public static final String GREEN_TICK_MIN_LENGTH_REQ                = "GREEN_TICK_MIN_LENGTH_REQ";

    public static final String RED_STATE_MIN_LENGTH_REQ                 = "RED_STATE_MIN_LENGTH_REQ";

    public static final String RED_STATE_NUMBER_REQ                     = "RED_STATE_NUMBER_REQ";

    public static final String RED_STATE_MATCH_CONF                     = "RED_STATE_MATCH_CONF";

    public static final String GREEN_TICK_MATCH_CONF                    = "GREEN_TICK_MATCH_CONF";

    public static final String RED_STATE_LETTER_REQ                     = "RED_STATE_LETTER_REQ";

    public static final String ERROR_MESSAGE                            = "ERROR_MESSAGE";

    public static final String DEFALUT_NUMBER                           = "DEFALUT_NUMBER";

    public static final String DEFALUT_ATLEAST_CHARS                    = "DEFALUT_ATLEAST_CHARS";

    public static final String DEFALUT_MATCH_CONFIRM                    = "DEFALUT_MATCH_CONFIRM";

}
