package com.ch.ta.desktopTests;

public class RegistrationTest {

}
