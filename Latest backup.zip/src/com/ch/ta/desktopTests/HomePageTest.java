package com.ch.ta.desktopTests;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ch.ExcelUtils.ExcelProperty;
import com.ch.report.utils.AbstractTestCaseReport;
import com.ch.reports.TestCaseDetail;
import com.ch.reports.TestCaseFactory;
import com.ch.ta.desktopPages.HomePage;
import com.ch.ta.desktopPages.HomePageMYMPage;
import com.ch.ta.utils.CommonUtils;
import com.ch.ta.utils.constants.FileConstants;
import com.ch.utils.SeleniumUtils;

@Listeners(com.ch.utils.ParallelFactory.class)
public class HomePageTest extends AbstractTestCaseReport implements FileConstants {

	@BeforeMethod
	public void tyreURL() throws Exception {
		CommonUtils.desktopView();
		CommonUtils.TBCURL();
	}

	// Test Case : 1
	@Test
	public void monetateBanner() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.isMonetateBanner();
			testcase.assertTrue(HomePage.isMonetateBanner(), "System should display Monetate Banner ",
					"System is not displaying Monetate Banner ");
			testcase.pass("System should display Monetate Banner ");
		} catch (Exception e) {
			testcase.error("System is not displaying Monetate Banner ", e);
			e.printStackTrace();
		}
	}

	// Test Case : 2
	@Test
	public void progressBar() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			testcase.assertTrue(HomePage.isProgressBar(), "System should display Progress Bar ",
					"System is not displaying Progress Bar ");
			testcase.pass("System should display Progress Bar ");
		} catch (Exception e) {
			testcase.error("System is not displaying Progress Bar ", e);
			e.printStackTrace();
		}
	}

	// Test Case : 3
	@Test
	public void progresBarWithoutSelectingVehicle() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.isProgBarYourVehicle();
			testcase.assertTrue(HomePage.isProgBarYourVehicle(),
					"System should display Progress Bar with first step(Your Vehicle) should be highlighted.",
					"System is not displaying Progress Bar with first step(Your Vehicle) should be highlighted. ");
			testcase.pass("System should display Progress Bar with first step(Your Vehicle) should be highlighted. ");
		} catch (Exception e) {
			testcase.error(
					"System is not displaying Progress Bar with first step(Your Vehicle) should be highlighted. ", e);
			e.printStackTrace();
		}
	}

	// Test Case : 4
	@Test
	public void progresBarWithSelectingVehicle() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.isProgBarYourVehicle();
			testcase.assertTrue(HomePage.isProgBarYourVehicle(),
					"System should display Progress Bar with first step(Your Vehicle) should be highlighted.",
					"System is not displaying Progress Bar with first step(Your Vehicle) should be highlighted. ");
			testcase.pass("System should display Progress Bar with first step(Your Vehicle) should be highlighted. ");
		} catch (Exception e) {
			testcase.error(
					"System is not displaying Progress Bar with first step(Your Vehicle) should be highlighted. ", e);
			e.printStackTrace();
		}
	}

	// Test Case : 5
	@Test
	public void aSpotSection() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.isASpot();
			testcase.assertTrue(HomePage.isASpot(), "System should display A-Spot section as per the configuration.",
					"System is not displaying A-Spot section as per the configuration. ");
			testcase.pass("System should display A-Spot section as per the configuration.");
		} catch (Exception e) {
			testcase.error("System is not displaying A-Spot section as per the configuration. ", e);
			e.printStackTrace();
		}
	}

	// Test Case : 6
	@Test
	public void aSpotYMMEComponent() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.isASpotYmmeComponent();
			testcase.assertTrue(HomePage.isASpotYmmeComponent(),
					"System should display A-Spot YMME Component as per the configuration.",
					"System is not displaying A-Spot  YMME Component as per the configuration. ");
			testcase.pass("System should display A-Spot YMME Component as per the configuration.");
		} catch (Exception e) {
			testcase.error("System is not displaying A-Spot YMME Component as per the configuration. ", e);
			e.printStackTrace();
		}
	}

	// Test Case : 7
	@Test
	public void aSpotYMMECompForNewUser() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.isShopByVehicleDefault();
			testcase.assertTrue(HomePage.isShopByVehicleDefault(),
					"System should display Shop by vehicle tab as default.",
					"System is not displaying Shop by vehicle tab as default.");
			testcase.pass("System should display Shop by vehicle tab as default.");
		} catch (Exception e) {
			testcase.error("System is not displaying Shop by vehicle tab as default.", e);
			e.printStackTrace();
		}
	}

	// Test Case : 8
	@Test
	public void liveChat() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.isLiveChat();
			testcase.assertTrue(HomePage.isLiveChat(), "System should display live chat button to the side of page.",
					"System is not displaying live chat button to the side of page.");
			testcase.pass("System should display live chat button to the side of page.");
		} catch (Exception e) {
			testcase.error("System is not displaying live chat button to the side of page.", e);
			e.printStackTrace();
		}
	}

	// Test Case : 9 //
	@Test
	public void liveChatBehaviour() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.clickLikeChat();
			testcase.assertTrue(HomePage.isLiveChat(), "System should display live chat button to the side of page.",
					"System is not displaying live chat button to the side of page.");
			testcase.pass("System should display live chat button to the side of page.");
		} catch (Exception e) {
			testcase.error("System is not displaying live chat button to the side of page.", e);
			e.printStackTrace();
		}
	}

	// Test Case : 10
	@Test
	public void aSpotWorksComponents() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.isHowitWorksComponents();
			testcase.assertTrue(HomePage.isHowitWorksComponents(),
					" System should display How it works component on home page.",
					"System is not displaying How it works component on home page.");
			testcase.pass(" System should display How it works component on home page.");
		} catch (Exception e) {
			testcase.error("System is not displaying How it works component on home page.", e);
			e.printStackTrace();
		}
	}

	// Test Case : 11
	@Test
	public void valuePropositionComponents() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.isValuePropositionComponents();
			testcase.assertTrue(HomePage.isValuePropositionComponents(),
					"System should display Value Proposition Component spot on home page.",
					"System is not displaying Value Proposition Component spot on home page.");
			testcase.pass("System should display Value Proposition Component spot on home page.");
		} catch (Exception e) {
			testcase.error("System is not displaying Value Proposition Component spot on home page.", e);
			e.printStackTrace();
		}
	}

	// Test Case : 12 modify
	@Test
	public void findAnInstaller() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.isFindAnInstaller();
			testcase.assertTrue(HomePage.isValuePropositionComponents(),
					"System should display Value Proposition Component spot on home page.",
					"System is not displaying Value Proposition Component spot on home page.");
			testcase.pass("System should display Value Proposition Component spot on home page.");
		} catch (Exception e) {
			testcase.error("System is not displaying Value Proposition Component spot on home page.", e);
			e.printStackTrace();
		}
	}

	// Test Case : 13 modify
	@Test
	public void salePromotionShopNow() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.clickSalePromoShopNow();
			testcase.assertTrue(HomePage.isValuePropositionComponents(),
					"System should navigate user to targeted page.", "System is not navigating to targeted page.");
			testcase.pass("System should navigate user to targeted page.");
		} catch (Exception e) {
			testcase.error("System is not navigating to targeted page.", e);
			e.printStackTrace();
		}
	}

	// Test Case : 14 modify
	@Test
	public void creditCardApplyNow() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.clickCreditComponentApplyNow();
			testcase.assertTrue(HomePage.isValuePropositionComponents(),
					"System should navigate user to targeted page.", "System is not navigating to targeted page.");
			testcase.pass("System should navigate user to targeted page.");
		} catch (Exception e) {
			testcase.error("System is not navigating to targeted page.", e);
			e.printStackTrace();
		}
	}

	// Test Case : 15 modify
	@Test
	public void testimonalComponent() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.isTestimonials();
			testcase.assertTrue(HomePage.isTestimonials(),
					"System should be display with Read more testimonials link/button on home page.",
					"System is not displaying Read more testimonials link/button on home page.");
			testcase.pass("System should be display with Read more testimonials link/button on home page.");
		} catch (Exception e) {
			testcase.error("System is not displaying Read more testimonials link/button on home page.", e);
			e.printStackTrace();
		}
	}

	// Test Case : 16 modify
	@Test
	public void knowledgecenterArticleComponent() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.isTestimonials();
			testcase.assertTrue(HomePage.isTestimonials(),
					"System should be displayed with Read Article link in home page.",
					"System is not displaying Read Article link in home page.");
			testcase.pass("System should be displayed with Read Article link in home page.");
		} catch (Exception e) {
			testcase.error("System is not displaying Read Article link in home page.", e);
			e.printStackTrace();
		}
	}

	// Test Case : 26 modify
	@Test
	public void shopByVehicleTabYMMEComp() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.isShopByVehicleDefault();
			testcase.assertTrue(HomePage.isShopByVehicleDefault(),
					"System should display Shop by vehicle tab as default.",
					"System is not displaying Shop by vehicle tab as default.");
			testcase.pass("System should display Shop by vehicle tab as default.");
		} catch (Exception e) {
			testcase.error("System is not displaying Shop by vehicle tab as default.", e);
			e.printStackTrace();
		}
	}

	// Test Case : 26 modify
	@Test
	public void shopByTireTabYMMEComp() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.isShopByVehicleDefault();
			testcase.assertTrue(HomePage.isShopByVehicleDefault(),
					"System should display Shop by vehicle tab as default.",
					"System is not displaying Shop by vehicle tab as default.");
			testcase.pass("System should display Shop by vehicle tab as default.");
		} catch (Exception e) {
			testcase.error("System is not displaying Shop by vehicle tab as default.", e);
			e.printStackTrace();
		}
	}

	// Test case : 27
	public void verifyValidMYMSectionTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePageMYMPage.clickOnMake();
			HomePageMYMPage.clickOnValueOfMakeDropDown();
			Thread.sleep(4000);
			HomePageMYMPage.clickOnValueOfYearDropDown();
			Thread.sleep(4000);
			HomePageMYMPage.clickOnValueOfModelDropDown();
			Thread.sleep(4000);
			testcase.assertTrue(SeleniumUtils.iSDisplayed(ExcelProperty.getElementValue("", "")),
					"car image is displayed", "car image is not displayed");
			testcase.pass("System should display the autocomplete names of MYM ");
		} catch (Exception e) {
			testcase.error("System should display the autocomplete names of MYM", e);
			e.printStackTrace();
		}
	}

	// Test Case : 28 modify
	@Test
	public void findMyTiresValidDetails() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.isShopByVehicleDefault();
			testcase.assertTrue(HomePage.isShopByVehicleDefault(),
					"System should display Shop by vehicle tab as default.",
					"System is not displaying Shop by vehicle tab as default.");
			testcase.pass("System should display Shop by vehicle tab as default.");
		} catch (Exception e) {
			testcase.error("System is not displaying Shop by vehicle tab as default.", e);
			e.printStackTrace();
		}
	}

	// Test Case : 29 modify
	@Test
	public void findMyTiresInValidDetails() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.isShopByVehicleDefault();
			testcase.assertTrue(HomePage.isShopByVehicleDefault(),
					"System should display Shop by vehicle tab as default.",
					"System is not displaying Shop by vehicle tab as default.");
			testcase.pass("System should display Shop by vehicle tab as default.");
		} catch (Exception e) {
			testcase.error("System is not displaying Shop by vehicle tab as default.", e);
			e.printStackTrace();
		}
	}

	// Test Case : 30 modify
	@Test
	public void licensePlateLink() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.isShopByVehicleDefault();
			testcase.assertTrue(HomePage.isShopByVehicleDefault(),
					"System should display Shop by vehicle tab as default.",
					"System is not displaying Shop by vehicle tab as default.");
			testcase.pass("System should display Shop by vehicle tab as default.");
		} catch (Exception e) {
			testcase.error("System is not displaying Shop by vehicle tab as default.", e);
			e.printStackTrace();
		}
	}

	// Test Case : 31 modify
	@Test
	public void licensePlateDispInShopByVehi() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.isShopByVehicleDefault();
			testcase.assertTrue(HomePage.isShopByVehicleDefault(),
					"System should display Shop by vehicle tab as default.",
					"System is not displaying Shop by vehicle tab as default.");
			testcase.pass("System should display Shop by vehicle tab as default.");
		} catch (Exception e) {
			testcase.error("System is not displaying Shop by vehicle tab as default.", e);
			e.printStackTrace();
		}
	}

	// Test Case : 32 modify
	@Test
	public void licensePlateWithValidData() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.isShopByVehicleDefault();
			testcase.assertTrue(HomePage.isShopByVehicleDefault(),
					"System should display Shop by vehicle tab as default.",
					"System is not displaying Shop by vehicle tab as default.");
			testcase.pass("System should display Shop by vehicle tab as default.");
		} catch (Exception e) {
			testcase.error("System is not displaying Shop by vehicle tab as default.", e);
			e.printStackTrace();
		}
	}

	// Test Case : 33 modify
	@Test
	public void licensePlateBackButton() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.isShopByVehicleDefault();
			testcase.assertTrue(HomePage.isShopByVehicleDefault(),
					"System should display Shop by vehicle tab as default.",
					"System is not displaying Shop by vehicle tab as default.");
			testcase.pass("System should display Shop by vehicle tab as default.");
		} catch (Exception e) {
			testcase.error("System is not displaying Shop by vehicle tab as default.", e);
			e.printStackTrace();
		}
	}

	// Test Case : 34 modify
	@Test
	public void licensePlateInvalidData() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.isShopByVehicleDefault();
			testcase.assertTrue(HomePage.isShopByVehicleDefault(),
					"System should display Shop by vehicle tab as default.",
					"System is not displaying Shop by vehicle tab as default.");
			testcase.pass("System should display Shop by vehicle tab as default.");
		} catch (Exception e) {
			testcase.error("System is not displaying Shop by vehicle tab as default.", e);
			e.printStackTrace();
		}
	}

	// Test Case : 35 modify
	@Test
	public void licensePlateToMYM() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.isShopByVehicleDefault();
			testcase.assertTrue(HomePage.isShopByVehicleDefault(),
					"System should display Shop by vehicle tab as default.",
					"System is not displaying Shop by vehicle tab as default.");
			testcase.pass("System should display Shop by vehicle tab as default.");
		} catch (Exception e) {
			testcase.error("System is not displaying Shop by vehicle tab as default.", e);
			e.printStackTrace();
		}
	}

	// Test Case : 36 modify
	@Test
	public void aSpotYMMEShopByTires() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.isShopByVehicleDefault();
			testcase.assertTrue(HomePage.isShopByVehicleDefault(),
					"System should display Shop by vehicle tab as default.",
					"System is not displaying Shop by vehicle tab as default.");
			testcase.pass("System should display Shop by vehicle tab as default.");
		} catch (Exception e) {
			testcase.error("System is not displaying Shop by vehicle tab as default.", e);
			e.printStackTrace();
		}
	}

	// Test Case : 37 modify
	@Test
	public void shopTireSizeValidData() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.isShopByVehicleDefault();
			testcase.assertTrue(HomePage.isShopByVehicleDefault(),
					"System should display Shop by vehicle tab as default.",
					"System is not displaying Shop by vehicle tab as default.");
			testcase.pass("System should display Shop by vehicle tab as default.");
		} catch (Exception e) {
			testcase.error("System is not displaying Shop by vehicle tab as default.", e);
			e.printStackTrace();
		}
	}

	// Test Case : 38 modify
	@Test
	public void findMyTiresWithVaildData() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.isShopByVehicleDefault();
			testcase.assertTrue(HomePage.isShopByVehicleDefault(),
					"System should display Shop by vehicle tab as default.",
					"System is not displaying Shop by vehicle tab as default.");
			testcase.pass("System should display Shop by vehicle tab as default.");
		} catch (Exception e) {
			testcase.error("System is not displaying Shop by vehicle tab as default.", e);
			e.printStackTrace();
		}
	}

	// Test Case : 39 modify
	@Test
	public void shopTireSizeInVaildData() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.isShopByVehicleDefault();
			testcase.assertTrue(HomePage.isShopByVehicleDefault(),
					"System should display Shop by vehicle tab as default.",
					"System is not displaying Shop by vehicle tab as default.");
			testcase.pass("System should display Shop by vehicle tab as default.");
		} catch (Exception e) {
			testcase.error("System is not displaying Shop by vehicle tab as default.", e);
			e.printStackTrace();
		}
	}

	// Test Case : 40 modify
	@Test
	public void addDifferentRearTireSize() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.isShopByVehicleDefault();
			testcase.assertTrue(HomePage.isShopByVehicleDefault(),
					"System should display Shop by vehicle tab as default.",
					"System is not displaying Shop by vehicle tab as default.");
			testcase.pass("System should display Shop by vehicle tab as default.");
		} catch (Exception e) {
			testcase.error("System is not displaying Shop by vehicle tab as default.", e);
			e.printStackTrace();
		}
	}

	// Test Case : 41 modify
	@Test
	public void addDifferentRearTireSize2() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.isShopByVehicleDefault();
			testcase.assertTrue(HomePage.isShopByVehicleDefault(),
					"System should display Shop by vehicle tab as default.",
					"System is not displaying Shop by vehicle tab as default.");
			testcase.pass("System should display Shop by vehicle tab as default.");
		} catch (Exception e) {
			testcase.error("System is not displaying Shop by vehicle tab as default.", e);
			e.printStackTrace();
		}
	}

	// Test Case : 42 modify
	@Test
	public void whereCanIFindMyTireSize() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.isShopByVehicleDefault();
			testcase.assertTrue(HomePage.isShopByVehicleDefault(),
					"System should display Shop by vehicle tab as default.",
					"System is not displaying Shop by vehicle tab as default.");
			testcase.pass("System should display Shop by vehicle tab as default.");
		} catch (Exception e) {
			testcase.error("System is not displaying Shop by vehicle tab as default.", e);
			e.printStackTrace();
		}
	}

	// Test Case : 43 modify
	@Test
	public void displayOfMultiplTireSizeCompnents() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.isShopByVehicleDefault();
			testcase.assertTrue(HomePage.isShopByVehicleDefault(),
					"System should display Shop by vehicle tab as default.",
					"System is not displaying Shop by vehicle tab as default.");
			testcase.pass("System should display Shop by vehicle tab as default.");
		} catch (Exception e) {
			testcase.error("System is not displaying Shop by vehicle tab as default.", e);
			e.printStackTrace();
		}
	}
}
