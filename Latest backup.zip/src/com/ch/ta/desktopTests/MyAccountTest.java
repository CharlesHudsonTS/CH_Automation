package com.ch.ta.desktopTests;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ch.report.utils.AbstractTestCaseReport;
import com.ch.reports.TestCaseDetail;
import com.ch.reports.TestCaseFactory;
import com.ch.retry.Retry;
import com.ch.ta.desktopPages.HeaderFooterPage;
import com.ch.ta.desktopPages.LoginPage;
import com.ch.ta.desktopPages.MyAccountPage;
import com.ch.ta.utils.CommonUtils;
import com.ch.ta.utils.constants.FileConstants;
import com.ch.utils.SeleniumUtils;
import com.ch.utils.Type;

@Listeners(com.ch.utils.ParallelFactory.class)
public class MyAccountTest extends AbstractTestCaseReport implements FileConstants {
	public void tyreURL() throws Exception {
		CommonUtils.desktopView();
		CommonUtils.TBCURL();
	}

	// TA_REG_032
	// To verify the display of 'PERSONAL INFORMATION' section for signed In
	// user in 'My Account' page.
	// 1//
	@Test
	
	public void personalInfoTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(8);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(8);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				testcase.assertTrue(MyAccountPage.isPersonalInfoSectionTitle(),
						"Personal Info section Title is displayed", "Personal Info section Title is not displayed");
				testcase.assertTrue(MyAccountPage.isPersonalInfoSectionLabels(),
						"Personal Info section labels is displayed", "Personal Info section labels is not displayed");
				testcase.pass("Personal Information section is displayed with labels in My Account page");
				break;
			} catch (Exception e) {
				testcase.retry("Personal Information section is displayed with labels in My Account page", testcase,
						retry, e);
				e.printStackTrace();
			}
		}
	}

	// TA_REG_033
	// To verify the display of 'PERSONAL INFORMATION' section with minimum data
	// for signed In user in 'My Account' page.
	// 2//
	@Test
	public void personalInfoNoDataTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				testcase.assertTrue(MyAccountPage.isPersonalInfoNoData(),
						"Personal Info section with no data is displayed",
						"Personal Info section with no data is not displayed");
				testcase.pass("Personal Information section is displayed with no data in My Account page");
				break;
			} catch (Exception e) {
				testcase.retry("Personal Information section is displayed with no data in My Account page", testcase,
						retry, e);
				e.printStackTrace();
			}
		}
	}

	// TA_REG_034
	// To verify the display of 'PERSONAL INFORMATION' section with data for signed
	// In user in 'My Account' page.
	// 3//
	@Test
	public void personalInfoDataTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				testcase.assertTrue(MyAccountPage.isPersonalInfoNoData(),
						"Personal Info section with data is displayed",
						"Personal Info section with data is not displayed");
				testcase.pass("Personal Information section is displayed with data in My Account page");
				break;
			} catch (Exception e) {
				testcase.retry("Personal Information section is displayed with data in My Account page", testcase,
						retry, e);
				e.printStackTrace();
			}
		}

	}

	// 35//
	// To verify the functionality of 'Edit' button of 'PERSONAL INFORMATION'
	// section in 'My Account' page.
	// 4//
	@Test
	public void editPersonalDataTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditPersonalInfo();
				SeleniumUtils.wait(5);
				testcase.assertTrue(MyAccountPage.isPersonalInformationText(),
						"Edit Personal Info section with data is displayed",
						"Edit Personal Info section with data is not displayed");
				testcase.pass("Personal Information section is allowed to edit in My Account page");
				break;
			} catch (Exception e) {
				testcase.retry("Personal Information section is allowed to edit in My Account page", testcase, retry,
						e);
				e.printStackTrace();
			}
		}
	}

	// To verify the functionality of '-' icon of 'PERSONAL INFORMATION' section
	// in 'My Account' page.
	// 5//
	@Test
	public void minimizePersonalTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickMinimizePersonalInfo();
				SeleniumUtils.wait(5);
				testcase.assertTrue(MyAccountPage.isPersonalInfoSectionLabels(), "Minimises Personal Information",
						"Does not minimise Personal Information");
				testcase.pass("Personal Information section is allowed to minimize in My Account page");
				break;
			} catch (Exception e) {
				testcase.retry("Personal Information section is allowed to minimize in My Account page", testcase,
						retry, e);
				e.printStackTrace();
			}
		}
	}

	// 56//
	// To verify the display of 'PASSWORD & SECURITY' section for signed In user
	// in 'My Account' page.
	// 6//
	@Test
	public void passwordNSecurityTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				testcase.assertTrue(MyAccountPage.isPasswordSecuritySectionTitle(),
						"Password Security section Title is displayed",
						"Password Security section Title is not displayed");
				testcase.assertTrue(MyAccountPage.isPasswordSecuritySectionLabels(),
						"Password Security section labels is displayed",
						"Password Security section labels is not displayed");
				testcase.pass("Password Security section is displayed with labels in My Account page");
				break;
			} catch (Exception e) {
				testcase.retry("Password Security section is displayed with labels in My Account page", testcase, retry,
						e);
				e.printStackTrace();
			}
		}
	}

	// 57//
	// To verify the display of 'PASSWORD & SECURITY' section with data for
	// signed In user in 'My Account' page.
	// 7//
	@Test
	public void passwordSecurityDataTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				testcase.assertTrue(MyAccountPage.isPasswordSecuritySectionLabels(),
						"Password Security section labels is displayed",
						"Password Security section labels is not displayed");
				testcase.pass("Password Security section is displayed with the data given in My Account page");
				break;
			} catch (Exception e) {
				testcase.retry("Password Security section is displayed with the data given in My Account page",
						testcase, retry, e);
				e.printStackTrace();
			}
		}
	}

	// To verify the functionality of 'Edit' button of 'PASSWORD & SECURITY'
	// section in 'My Account' page.
	// 8//
	@Test
	public void editPwdNSecurityDataTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditPasswordSecurity();
				SeleniumUtils.wait(5);
				testcase.assertTrue(MyAccountPage.isPasswordSecuritySectionLabels(),
						"Edit Password Security section labels is displayed",
						"Edit Password Security section labels is not displayed");
				testcase.pass("Password and Security section is allowed to edit in My Account page");
				break;
			} catch (Exception e) {
				testcase.retry("Password and Security section is allowed to edit in My Account page", testcase, retry,
						e);
				e.printStackTrace();
			}
		}
	}

	// 85//
	// To verify the functionality of '-' icon of 'PASSWORD & SECURITY' section
	// in 'My Account' page.
	// 9//
	@Test
	public void minimizePwdNSecurityTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickMinimizePasswordSecurity();
				SeleniumUtils.wait(5);
				testcase.assertTrue(MyAccountPage.isPasswordSecuritySectionLabels(), "Minimises Password and Security",
						"Does not minimise Password and Security");
				testcase.pass("Password and Security section is allowed to edit in My Account page");
				break;
			} catch (Exception e) {
				testcase.retry("Password and Security section is allowed to edit in My Account page", testcase, retry,
						e);
				e.printStackTrace();
			}
		}
	}

	// 94//
	// To verify the display of 'COMMUNICATION PREFERENCES' section for signed
	// In user in 'My Account' page.
	// 10//
	@Test
	public void communPreferenceTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				testcase.assertTrue(MyAccountPage.isCommnPreferenceSectionTitle(),
						"Communication Preferences section Title is displayed",
						"Communication Preferences section Title is not displayed");
				testcase.assertTrue(MyAccountPage.isCommnPreferenceSectionLabels(),
						"Communication Preferences section labels is displayed",
						"Communication Preferences section labels is not displayed");
				testcase.pass("Communication Preferences section is displayed with labels in My Account page");
				break;
			} catch (Exception e) {
				testcase.retry("Communication Preferences section is displayed with labels in My Account page",
						testcase, retry, e);
				e.printStackTrace();
			}
		}
	}
//95//
	// To verify the display of 'COMMUNICATION PREFERENCES' section with data
	// for signed In user in 'My Account' page.
	// 11//
	@Test
	public void commnPreferenceDataTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				testcase.assertTrue(MyAccountPage.isCommnPreferenceSectionLabels(),
						"Communication Preferences section labels Data is displayed",
						"Communication Preferences section labels data is not displayed");
				testcase.pass("Communication Preference section is displayed with given data in My Account page");
				break;
			} catch (Exception e) {
				testcase.retry("Communication Preference section is displayed with given data in My Account page",
						testcase, retry, e);
				e.printStackTrace();
			}
		}
	}
//96//
	// To verify the functionality of 'Edit' button of 'COMMUNICATION
	// PREFERENCES' section in 'My Account' page.
	// 12//
	@Test
	public void editCommnPreferenceDataTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditCommunicationPreference();
				SeleniumUtils.wait(5);
				testcase.assertTrue(MyAccountPage.isCommnPreferenceSectionLabels(),
						"Communication Preferences section labels Data is displayed",
						"Communication Preferences section labels data is not displayed");
				testcase.pass("Communication Preferences section is allowed to edit in My Account page");
				break;
			} catch (Exception e) {
				testcase.retry("Communication Preferences section is allowed to edit in My Account page", testcase,
						retry, e);
				e.printStackTrace();
			}
		}
	}

	// To verify the functionality of '-' icon of 'COMMUNICATION PREFERENCES'
	// section in 'My Account' page.
	// 13//
	@Test
	public void minimizeCommnPreferenceTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickMinimizeCommunPref();
				SeleniumUtils.wait(5);
				testcase.assertTrue(MyAccountPage.isCommnPreferenceSectionLabels(),
						"Minimises Communication Preferences", "Does not minimise Communication Preferences");
				testcase.pass("Communication Preferences section is allowed to minimize in My Account page");
				break;
			} catch (Exception e) {
				testcase.retry("Communication Preferences section is allowed to minimize in My Account page", testcase,
						retry, e);
				e.printStackTrace();

			}
		}
	}
//101//
	// To verify the display of 'MY PREFERRED INSTALLERS' section for signed In
	// user in 'My Account' page.
	// 14//
	@Test
	public void myPrefInstallersTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				testcase.assertTrue(MyAccountPage.isMyPrefereedInstallersSectionTitle(),
						"My Preferred Installers section Title is displayed",
						"My Preferred Installers section Title is not displayed");
				// testcase.assertTrue(MyAccountPage.isMyPrefereedInstallersList(),
				// "My Preferred Installers section list is displayed",
				// "My Preferred Installers section list is not displayed");
				testcase.pass("My Preferred Installers section is displayed with title and list in My Account page");
				break;
			} catch (Exception e) {
				testcase.retry("My Preferred Installers section is displayed with title and list in My Account page",
						testcase, retry, e);
				e.printStackTrace();
			}
		}
	}
//102//
	// To verify the display of 'MY PREFERRED INSTALLERS' section with data for
	// signed In user in 'My Account' page.
	// 15//
	@Test
	public void myPrefInstallersLocationListTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				testcase.assertTrue(MyAccountPage.isMyPrefereedInstallersSectionTitle(),
						"My Preferred Installers section Title is displayed",
						"My Preferred Installers section Title is not displayed");

				testcase.pass(
						"My Preferred Installers section is displayed with list of installers with locations in maps in My Account page");
				break;
			} catch (Exception e) {
				testcase.retry(
						"My Preferred Installers section is displayed with list of installers with locations in maps in My Account page",
						testcase, retry, e);
				e.printStackTrace();
			}
		}
	}
//105//
	//16//
	// To verify the functionality of accordion in the list of installers in 'MY
	// PREFERRED INSTALLERS' section in 'My Account' page.
	@Test
	public void myPrefInstallersAccordionTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccordionInstaller1();
				SeleniumUtils.wait(5);
				testcase.assertTrue(MyAccountPage.isRemoveInstallerButton(), "Installer Details displayed by expanding",
						"Installer Details not displayed by expanding");
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccordionInstaller1();
				SeleniumUtils.wait(5);
				testcase.assertTrue(MyAccountPage.isRemoveInstallerButton(), "Installer Details is collapsed",
						"Installer Details is not collapsed");
				testcase.pass(
						"My Preferred Installers section is displayed with details expanded or collapsed by clicking accordion in My Account page");
				break;
			} catch (Exception e) {
				testcase.retry(
						"My Preferred Installers section is displayed with details expanded or collapsed by clicking accordion in My Account page",
						testcase, retry, e);
				e.printStackTrace();
			}
		}
	}
//104//
	//17//
	// To verify the functionality of accordion in the list of installers in 'MY
	// PREFERRED INSTALLERS' section in 'My Account' page.

	@Test
	public void myPrefInstallersRemoveBtnTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("test@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccordionInstaller1();
				SeleniumUtils.wait(5);
				testcase.assertTrue(MyAccountPage.isRemoveInstallerButton(), "Installer Details displayed by expanding",
						"Installer Details not displayed by expanding");
				SeleniumUtils.wait(5);
				MyAccountPage.clickRemoveInstaller1();
				SeleniumUtils.wait(5);
				testcase.assertFalse(MyAccountPage.isRemoveInstallerButton(), "Installer removed",
						"Installer not removed");
				testcase.pass(
						"Functionality of remove button for installer in My Preferred Installers section of My Account page");
				break;
			} catch (Exception e) {
				testcase.retry(
						"Functionality of remove button for installer in My Preferred Installers section of My Account page",
						testcase, retry, e);
				e.printStackTrace();
			}
		}
	}
//18//
	// To verify the functionality of '-' icon of 'MY PREFERRED INSTALLERS'
	// section in 'My Account' page.
	@Test
	public void myPrefInstallersMinimizeTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickMinimizeMyInstallers();
				SeleniumUtils.wait(5);
				// testcase.assertTrue(MyAccountPage.isMyPrefereedInstallersList(), "Installer
				// section minimised",
				// "Installer section not minimised");
				testcase.pass(
						"Functionality of minimize button for installer in My Preferred Installers section of My Account page");
				break;
			} catch (Exception e) {
				testcase.retry(
						"Functionality of minimize button for installer in My Preferred Installers section of My Account page",
						testcase, retry, e);
				e.printStackTrace();
			}
		}
	}
	// 36//
	//19//
	// To verify the display of typeahead suggestions for 'Address' field of
	// 'PERSONAL INFORMATION' section in 'My Account' page.//

	@Test
	public void personalInfoTypeaheadSuggestions() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditPersonalInfo();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAddressLineOne();
				SeleniumUtils.wait(2);
				MyAccountPage.enterAddressinAddressField();
				testcase.assertTrue(MyAccountPage.isPersonalInfoAutoSuggestion(),
						"Personal Info section with Auto suggestion data is displayed",
						"Personal Info section with Auto suggestion data is not displayed");
				testcase.pass("Personal Information section is displayed with auto suggestion data in My Account page");
				break;
			} catch (Exception e) {
				testcase.retry("Personal Information section is displayed with auto suggestion data in My Account page",
						testcase, retry, e);
				e.printStackTrace();
			}
		}

	}

	// 37//
	//20//
	// To verify the functionality of typeahead suggestions for 'Address' field of
	// 'PERSONAL INFORMATION' section in 'My Account' page.//
	@Test
	public void functionalityOfpersonalInfoTypeaheadSuggestions() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditPersonalInfo();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAddressLineOne();
				SeleniumUtils.wait(2);
				MyAccountPage.enterAddressinAddressField();
				SeleniumUtils.wait(4);
				MyAccountPage.clickAutosuggestedAddressLine();
				SeleniumUtils.wait(6);
				testcase.assertTrue(MyAccountPage.isPersonalInfoAutoSuggestion(),
						"Personal Info section with Auto suggestion data is displayed",
						"Personal Info section with Auto suggestion data is not displayed");
				testcase.pass("Personal Information section is displayed with auto suggestion data in My Account page");
				break;
			} catch (Exception e) {
				testcase.retry("Personal Information section is displayed with auto suggestion data in My Account page",
						testcase, retry, e);
				e.printStackTrace();
			}
		}

	}
	// 38//
	//21//
	// To verify the functionality of 'Save' button for 'PERSONAL INFORMATION'
	// section in 'My Account' page.//

	@Test
	public void functionalityOfpersonalInfoSaveButton() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditPersonalInfo();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAddressLineOne();
				SeleniumUtils.wait(2);
				MyAccountPage.enterAddressinAddressField();
				SeleniumUtils.wait(3);
				MyAccountPage.clickAddressLineCity();
				SeleniumUtils.wait(2);
				MyAccountPage.enterinCity();
				SeleniumUtils.wait(2);
				// MyAccountPage.clickAddressLineState();
				SeleniumUtils.wait(2);
				// MyAccountPage.clickAutosuggestedState();
				// SeleniumUtils.wait(2);
				MyAccountPage.clickAddressLineMobNumber();
				SeleniumUtils.wait(4);
				MyAccountPage.clickAddressLineAltNum();
				SeleniumUtils.wait(4);
				// MyAccountPage.clickAddressLineBirthdayMonth();
				// SeleniumUtils.wait(2);
				// MyAccountPage.clickAutosuggestedBirthday();
				SeleniumUtils.wait(3);
				MyAccountPage.clickAddressLineSaveButton();
				SeleniumUtils.wait(2);
				testcase.assertTrue(MyAccountPage.isPersonalInfoAutoAddressConfirm(),
						"Verify the functionality of the save button in Personal info section data is displayed",
						"Verify the functionality of the save button in Personal info section data is not displayed");
				testcase.pass("Personal Information section is displayed with auto suggestion data in My Account page");
				break;
			} catch (Exception e) {
				testcase.retry("Verify the functionality of the save button in Personal info section data is displayed",
						testcase, retry, e);
				e.printStackTrace();
			}
		}

	}

	// 39//
	//22//
	// To verify the functionality of 'Address Confirmation' popup for 'PERSONAL
	// INFORMATION' section in 'My Account' page.//
	@Test
	public void functionalityOfAddressConfirmationPopUp() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditPersonalInfo();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAddressLineOne();
				SeleniumUtils.wait(2);
				MyAccountPage.enterAddressinAddressField();
				SeleniumUtils.wait(3);
				MyAccountPage.clickAddressLineCity();
				SeleniumUtils.wait(2);
				MyAccountPage.enterinCity();
				SeleniumUtils.wait(2);
				// MyAccountPage.clickAddressLineState();
				SeleniumUtils.wait(2);
				// MyAccountPage.clickAutosuggestedState();
				// SeleniumUtils.wait(2);
				MyAccountPage.clickAddressLineMobNumber();
				SeleniumUtils.wait(4);
				MyAccountPage.clickAddressLineAltNum();
				SeleniumUtils.wait(4);
				// MyAccountPage.clickAddressLineBirthdayMonth();
				// SeleniumUtils.wait(2);
				// MyAccountPage.clickAutosuggestedBirthday();
				SeleniumUtils.wait(3);
				MyAccountPage.clickAddressLineSaveButton();
				SeleniumUtils.wait(2);
				testcase.assertTrue(MyAccountPage.isAddressConfirmationLabels(),
						"Verify the display of Confirm address fields in Address section",
						"Verify the display of Confirm address fields in Address section");
				testcase.pass(
						"Personal Information section is displayed with Confirm Address in Account Confirmation page");
				break;
			} catch (Exception e) {
				testcase.retry(
						"Personal Information section is displayed with Confirm Address in Account Confirmation page",
						testcase, retry, e);
				e.printStackTrace();
			}
		}

	}

	// 40//
	//23//
	// To verify the functionality of 'Confirm' button in 'Address Confirmation'
	// popup for 'PERSONAL INFORMATION' section in 'My Account' page.//
	@Test
	public void functionalityOfAddressConfirmButton() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditPersonalInfo();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAddressLineOne();
				SeleniumUtils.wait(2);
				MyAccountPage.enterAddressinAddressField();
				SeleniumUtils.wait(3);
				MyAccountPage.clickAddressLineCity();
				SeleniumUtils.wait(2);
				MyAccountPage.enterinCity();
				SeleniumUtils.wait(2);
				// MyAccountPage.clickAddressLineState();
				SeleniumUtils.wait(2);
				// MyAccountPage.clickAutosuggestedState();
				// SeleniumUtils.wait(2);
				MyAccountPage.clickAddressLineMobNumber();
				SeleniumUtils.wait(4);
				MyAccountPage.clickAddressLineAltNum();
				SeleniumUtils.wait(4);
				// MyAccountPage.clickAddressLineBirthdayMonth();
				// SeleniumUtils.wait(2);
				// MyAccountPage.clickAutosuggestedBirthday();
				SeleniumUtils.wait(3);
				MyAccountPage.clickAddressLineSaveButton();
				SeleniumUtils.wait(2);
				MyAccountPage.clickVerifiedAddressSection();
				SeleniumUtils.wait(2);
				testcase.assertTrue(MyAccountPage.isPersonalInfoAutoSuggestion(),
						"Verify the display of Address added in Personal info section",
						"Verify the display of Address added in Personal info section");
				testcase.pass("Personal Information section is displayed with Address");
				break;
			} catch (Exception e) {
				testcase.retry("Personal Information section is displayed with Address", testcase, retry, e);
				e.printStackTrace();
			}
		}

	}

	// 41//
	//24//
	// To verify the functionality of '->' button 'Use As Entered' address in
	// 'Address Confirmation' popup for 'PERSONAL INFORMATION' section in 'My
	// Account' page.//
	@Test
	public void functionalityOfUsAsAddressInAddConfirmation() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditPersonalInfo();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAddressLineOne();
				SeleniumUtils.wait(2);
				MyAccountPage.enterAddressinAddressField();
				SeleniumUtils.wait(3);
				MyAccountPage.clickAddressLineCity();
				SeleniumUtils.wait(2);
				MyAccountPage.enterinCity();
				SeleniumUtils.wait(2);
				// MyAccountPage.clickAddressLineState();
				SeleniumUtils.wait(2);
				// MyAccountPage.clickAutosuggestedState();
				// SeleniumUtils.wait(2);
				MyAccountPage.clickAddressLineMobNumber();
				SeleniumUtils.wait(4);
				MyAccountPage.clickAddressLineAltNum();
				SeleniumUtils.wait(4);
				// MyAccountPage.clickAddressLineBirthdayMonth();
				// SeleniumUtils.wait(2);
				// MyAccountPage.clickAutosuggestedBirthday();
				SeleniumUtils.wait(3);
				MyAccountPage.clickAddressLineSaveButton();
				SeleniumUtils.wait(2);
				MyAccountPage.clickUseAsAddressSection();
				SeleniumUtils.wait(2);
				testcase.assertTrue(MyAccountPage.isPersonalInfoAutoSuggestion(),
						"Verify the display of use as Address added in Personal info section",
						"Verify the display of use as Address added in Personal info section");
				testcase.pass("Personal Information section is displayed with Use as Address");
				break;
			} catch (Exception e) {
				testcase.retry("Personal Information section is displayed with Use as Address", testcase, retry, e);
				e.printStackTrace();
			}
		}

	}

	// 42//
	//25//
	// To verify the functionality of 'Cancel' button in 'Address Confirmation'
	// popup for 'PERSONAL INFORMATION' section in 'My Account' page.//
	@Test
	public void functionalityOfCancelButton() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditPersonalInfo();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAddressLineOne();
				SeleniumUtils.wait(2);
				MyAccountPage.enterAddressinAddressField();
				SeleniumUtils.wait(3);
				MyAccountPage.clickAddressLineCity();
				SeleniumUtils.wait(2);
				MyAccountPage.enterinCity();
				SeleniumUtils.wait(2);
				// MyAccountPage.clickAddressLineState();
				SeleniumUtils.wait(2);
				// MyAccountPage.clickAutosuggestedState();
				// SeleniumUtils.wait(2);
				MyAccountPage.clickAddressLineMobNumber();
				SeleniumUtils.wait(4);
				MyAccountPage.clickAddressLineAltNum();
				SeleniumUtils.wait(4);
				// MyAccountPage.clickAddressLineBirthdayMonth();
				// SeleniumUtils.wait(2);
				// MyAccountPage.clickAutosuggestedBirthday();
				SeleniumUtils.wait(3);
				MyAccountPage.clickAddressLineSaveButton();
				SeleniumUtils.wait(2);
				MyAccountPage.clickAddressCloseButton();
				SeleniumUtils.wait(2);
				MyAccountPage.clickAddressCancelButton();
				testcase.assertTrue(MyAccountPage.isPersonalInfoAutoSuggestion(),
						"Verify the functionality of the cancel button in address page",
						"Verify the functionality of the cancel button in address page");
				testcase.pass("Verify the functionality of the cancel button in address Section");
				break;
			} catch (Exception e) {
				testcase.retry("Verify the functionality of the cancel button in address Section", testcase, retry, e);
				e.printStackTrace();
			}
		}

	}

	// 43//
	//26//
	// To verify the functionality of 'X' icon in 'Address Confirmation' popup for
	// 'PERSONAL INFORMATION' section in 'My Account' page.//
	@Test
	public void functionalityOfCloseIconInAddConfirmation() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditPersonalInfo();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAddressLineOne();
				SeleniumUtils.wait(2);
				MyAccountPage.enterAddressinAddressField();
				SeleniumUtils.wait(3);
				MyAccountPage.clickAddressLineCity();
				SeleniumUtils.wait(2);
				MyAccountPage.enterinCity();
				SeleniumUtils.wait(2);
				// MyAccountPage.clickAddressLineState();
				SeleniumUtils.wait(2);
				// MyAccountPage.clickAutosuggestedState();
				// SeleniumUtils.wait(2);
				MyAccountPage.clickAddressLineMobNumber();
				SeleniumUtils.wait(4);
				MyAccountPage.clickAddressLineAltNum();
				SeleniumUtils.wait(4);
				// MyAccountPage.clickAddressLineBirthdayMonth();
				// SeleniumUtils.wait(2);
				// MyAccountPage.clickAutosuggestedBirthday();
				SeleniumUtils.wait(3);
				MyAccountPage.clickAddressLineSaveButton();
				SeleniumUtils.wait(2);
				MyAccountPage.clickAddressCloseButton();
				testcase.assertTrue(MyAccountPage.isPersonalInfoAutoSuggestion(),
						"Verify the functionality of the close icon in address page",
						"Verify the functionality of the close icon in address page");
				testcase.pass("Verify the functionality of the close icon in address confirmation Popup");
				break;
			} catch (Exception e) {
				testcase.retry("Verify the functionality of the close icon in address confirmation Popup", testcase,
						retry, e);
				e.printStackTrace();
			}
		}

	}
	// 44/
	//27//
	// To verify the error message displayed for invalid address for 'PERSONAL
	// INFORMATION' section in 'My Account' page.//

	@Test
	public void errorMessageForInvalidAddressInPersonalInfo() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing12@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditPersonalInfo();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAddressLineOne();
				SeleniumUtils.wait(2);
				MyAccountPage.enterInvalidAddressinAddressField();
				SeleniumUtils.wait(2);
				MyAccountPage.enterInvalidCity();
				MyAccountPage.clickAddressLineInvalidMobNumber();
				MyAccountPage.clickAddressLineInvalidAltNum();
				SeleniumUtils.wait(2);
				MyAccountPage.clickAddressLineSaveButton();
				// testcase.assertTrue(MyAccountPage.isErrorMessageDisplay(), "Error message is
				// displayed for Invalid address in personal Info section",
				// "Error message is displayed for Invalid address in personal Info section");
				testcase.pass("Error message is displayed for Invalid address in personal Info section");
				break;
			} catch (Exception e) {
				testcase.retry("Error message is displayed for Invalid address in personal Info section", testcase,
						retry, e);
				e.printStackTrace();
			}
		}

	}
	// 45//
	//28//
	// To verify the functionality of '^' icon of 'PERSONAL INFORMATION' section in
	// 'My Account' page.//

	@Test
	public void personalInfoMinimiseIcon() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(8);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickPersonalInfoMinimiseIcon();
				testcase.assertTrue(MyAccountPage.isPersonalInfoSectionTitle(),
						"Personal Info section Title is displayed", "Personal Info section Title is not displayed");
				testcase.pass("Personal Information section Minimise icon is displated in My Account page");
				break;
			} catch (Exception e) {
				testcase.retry("Personal Information section Minimise icon is displated in My Account page", testcase,
						retry, e);
				e.printStackTrace();
			}
		}
	}
	// 46//
	//29//
	// To verify the error message displayed for 'First Name' field on entering more
	// than 20 characters in 'PERSONAL INFORMATION' section in 'My Account' page.//

	@Test
	public void errorMessageForFirstNameEnteringMoreThanTwentyLetters() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditPersonalInfo();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAddressLineFirstname();
				SeleniumUtils.wait(2);
				MyAccountPage.clickAddressLineOne();
				SeleniumUtils.wait(2);
				MyAccountPage.enterAddressinAddressField();
				SeleniumUtils.wait(3);
				MyAccountPage.clickAddressLineCity();
				SeleniumUtils.wait(2);
				MyAccountPage.enterinCity();
				SeleniumUtils.wait(2);
				// MyAccountPage.clickAddressLineState();
				SeleniumUtils.wait(2);
				// MyAccountPage.clickAutosuggestedState();
				// SeleniumUtils.wait(2);
				MyAccountPage.clickAddressLineMobNumber();
				SeleniumUtils.wait(4);
				MyAccountPage.clickAddressLineAltNum();
				SeleniumUtils.wait(4);
				// MyAccountPage.clickAddressLineBirthdayMonth();
				// SeleniumUtils.wait(2);
				// MyAccountPage.clickAutosuggestedBirthday();
				SeleniumUtils.wait(3);
				MyAccountPage.clickAddressLineSaveButton();
				SeleniumUtils.wait(2);
				testcase.assertTrue(MyAccountPage.isErrorMessageForInvalidFirstName(),
						"Verify the error message for First name by entering more than 20 letters in Personal info section",
						"Verify the error message for First name by entering more than 20 letters in Personal info section");
				testcase.pass(
						"Error message is displayed for First name by entering more than 20 letters in Personal info section");
				break;
			} catch (Exception e) {
				testcase.retry(
						"Error message is displayed for First name by entering more than 20 letters in Personal info section",
						testcase, retry, e);
				e.printStackTrace();
			}
		}

	}
	// 47//
	//30//
	// To verify the error message displayed for 'Last Name' field on entering more
	// than 20 characters in 'PERSONAL INFORMATION' section in 'My Account' page.//

	@Test
	public void errorMessageForLastNameEnteringMoreThanTwentyLetters() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditPersonalInfo();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAddressLineLastname();
				SeleniumUtils.wait(2);
				MyAccountPage.clickAddressLineOne();
				SeleniumUtils.wait(2);
				MyAccountPage.enterAddressinAddressField();
				SeleniumUtils.wait(3);
				MyAccountPage.clickAddressLineCity();
				SeleniumUtils.wait(2);
				MyAccountPage.enterinCity();
				SeleniumUtils.wait(2);
				// MyAccountPage.clickAddressLineState();
				SeleniumUtils.wait(2);
				// MyAccountPage.clickAutosuggestedState();
				// SeleniumUtils.wait(2);
				MyAccountPage.clickAddressLineMobNumber();
				SeleniumUtils.wait(4);
				MyAccountPage.clickAddressLineAltNum();
				SeleniumUtils.wait(4);
				// MyAccountPage.clickAddressLineBirthdayMonth();
				// SeleniumUtils.wait(2);
				// MyAccountPage.clickAutosuggestedBirthday();
				SeleniumUtils.wait(3);
				MyAccountPage.clickAddressLineSaveButton();
				SeleniumUtils.wait(2);
				testcase.assertTrue(MyAccountPage.isErrorMessageForInvalidLastName(),
						"Verify the error message for Last name by entering more than 20 letters in Personal info section",
						"Verify the error message for Last name by entering more than 20 letters in Personal info section");
				testcase.pass(
						"Error message is displayed for Last name by entering more than 20 letters in Personal info section");
				break;
			} catch (Exception e) {
				testcase.retry(
						"Error message is displayed for Last name by entering more than 20 letters in Personal info section",
						testcase, retry, e);
				e.printStackTrace();
			}
		}

	}
	// 48//
	//31//
	// To verify the error message displayed for 'Address Line2' field on entering
	// more than 40 characters with invalid characters in 'PERSONAL INFORMATION'
	// section in 'My Account' page.//

	@Test
	public void errorMessageForAddressLineEnteringMoreThanFourtyLetters() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditPersonalInfo();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAddressLineValidFirstname();
				SeleniumUtils.wait(2);
				MyAccountPage.clickAddressLineValidLastname();
				SeleniumUtils.wait(2);
				MyAccountPage.clickAddressLineOne();
				SeleniumUtils.wait(2);
				MyAccountPage.enterSplLettersinAddressField();
				SeleniumUtils.wait(3);
				MyAccountPage.clickAddressLineCity();
				SeleniumUtils.wait(2);
				MyAccountPage.enterinCity();
				SeleniumUtils.wait(2);
				// MyAccountPage.clickAddressLineState();
				SeleniumUtils.wait(2);
				// MyAccountPage.clickAutosuggestedState();
				// SeleniumUtils.wait(2);
				MyAccountPage.clickAddressLineMobNumber();
				SeleniumUtils.wait(4);
				MyAccountPage.clickAddressLineAltNum();
				SeleniumUtils.wait(4);
				// MyAccountPage.clickAddressLineBirthdayMonth();
				// SeleniumUtils.wait(2);
				// MyAccountPage.clickAutosuggestedBirthday();
				SeleniumUtils.wait(3);
				MyAccountPage.clickAddressLineSaveButton();
				SeleniumUtils.wait(2);
				testcase.assertTrue(MyAccountPage.isErrorMessageForInvalidSplLettersInAddressField(),
						"Verify the error message for address filed by entering more than 40 Special letters in Personal info section",
						"Verify the error message for address filed by entering more than 40 Special letters in Personal info section");
				testcase.pass(
						"Error message is displayed for address field by entering more than 40 spl letters in Personal info section");
				break;
			} catch (Exception e) {
				testcase.retry(
						"Error message is displayed for address field by entering more than 40 spl letters in Personal info section",
						testcase, retry, e);
				e.printStackTrace();
			}
		}

	}

	// 49//
	//32//
	// To verify the error message displayed for 'City' field on entering more than
	// 25 characters in 'PERSONAL INFORMATION' section in 'My Account' page.//
	@Test
	public void errorMessageForCityMoreThanTwentyFiveLetters() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditPersonalInfo();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAddressLineValidFirstname();
				SeleniumUtils.wait(2);
				MyAccountPage.clickAddressLineValidLastname();
				SeleniumUtils.wait(2);
				MyAccountPage.clickAddressLineOne();
				SeleniumUtils.wait(2);
				MyAccountPage.enterAddressinAddressField();
				SeleniumUtils.wait(3);
				MyAccountPage.clickAddressLineCity();
				SeleniumUtils.wait(2);
				MyAccountPage.enterInvalidCharectersinCityField();
				SeleniumUtils.wait(2);
				// MyAccountPage.clickAddressLineState();
				SeleniumUtils.wait(2);
				// MyAccountPage.clickAutosuggestedState();
				// SeleniumUtils.wait(2);
				MyAccountPage.clickAddressLineMobNumber();
				SeleniumUtils.wait(4);
				MyAccountPage.clickAddressLineAltNum();
				SeleniumUtils.wait(4);
				// MyAccountPage.clickAddressLineBirthdayMonth();
				// SeleniumUtils.wait(2);
				// MyAccountPage.clickAutosuggestedBirthday();
				SeleniumUtils.wait(3);
				MyAccountPage.clickAddressLineSaveButton();
				SeleniumUtils.wait(2);
				testcase.assertTrue(MyAccountPage.isErrorMessageForCityField(),
						"Verify the error message for city filed by entering more than 25 Special letters in Personal info section",
						"Verify the error message for city filed by entering more than 25 Special letters in Personal info section");
				testcase.pass(
						"Error message is displayed for city field by entering more than 25 spl letters in Personal info section");
				break;
			} catch (Exception e) {
				testcase.retry(
						"Error message is displayed for city field by entering more than 25 spl letters in Personal info section",
						testcase, retry, e);
				e.printStackTrace();
			}
		}
	}

	// 51//
	//33//
	// To verify the error message displayed for 'Zip Code' field on entering more
	// than 10 or less than 5 characters in 'PERSONAL INFORMATION' section in 'My
	// Account' page.//
	@Test
	public void errorMessageForZipcodeMoreThanTenLetters() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditPersonalInfo();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAddressLineValidFirstname();
				SeleniumUtils.wait(2);
				MyAccountPage.clickAddressLineValidLastname();
				SeleniumUtils.wait(2);
				MyAccountPage.clickAddressLineOne();
				SeleniumUtils.wait(2);
				MyAccountPage.enterAddressinAddressField();
				SeleniumUtils.wait(3);
				MyAccountPage.clickAddressLineCity();
				SeleniumUtils.wait(2);
				MyAccountPage.enterinCity();
				SeleniumUtils.wait(2);
				MyAccountPage.clickAddressLineInvalidZipcode();
				SeleniumUtils.wait(2);
				MyAccountPage.clickAddressLineMobNumber();
				SeleniumUtils.wait(4);
				MyAccountPage.clickAddressLineAltNum();
				SeleniumUtils.wait(4);
				// MyAccountPage.clickAddressLineBirthdayMonth();
				// SeleniumUtils.wait(2);
				// MyAccountPage.clickAutosuggestedBirthday();
				SeleniumUtils.wait(3);
				MyAccountPage.clickAddressLineSaveButton();
				SeleniumUtils.wait(2);
				testcase.assertTrue(MyAccountPage.isErrorMessageForZipcodeField(),
						"Verify the error message for Zipcode filed by entering more than 10 numbers in Personal info section",
						"Verify the error message for Zipcode filed by entering more than 10 numbers in Personal info section");
				testcase.pass(
						"Error message is displayed for zipcode field by entering more than 10 numbers in Personal info section");
				break;
			} catch (Exception e) {
				testcase.retry(
						"Error message is displayed for zipcode field by entering more than 10 numbers in Personal info section",
						testcase, retry, e);
				e.printStackTrace();
			}
		}

	}

	// 52//
	//34//
	// To verify the error message displayed for 'Mobile Phone Number' field on
	// entering more or less than 10 numeric characters in 'PERSONAL INFORMATION'
	// section in 'My Account' page.//
	@Test
	public void errorMessageForInvalidMobileNumber() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditPersonalInfo();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAddressLineValidFirstname();
				SeleniumUtils.wait(2);
				MyAccountPage.clickAddressLineValidLastname();
				SeleniumUtils.wait(2);
				MyAccountPage.clickAddressLineOne();
				SeleniumUtils.wait(2);
				MyAccountPage.enterAddressinAddressField();
				SeleniumUtils.wait(3);
				MyAccountPage.clickAddressLineCity();
				SeleniumUtils.wait(2);
				MyAccountPage.enterinCity();
				SeleniumUtils.wait(2);
				MyAccountPage.enterInvalidMobNumber();
				SeleniumUtils.wait(4);
				MyAccountPage.clickAddressLineAltNum();
				SeleniumUtils.wait(4);
				MyAccountPage.clickAddressLineSaveButton();
				SeleniumUtils.wait(2);
				testcase.assertTrue(MyAccountPage.isErrorMessageForInvalidMobNum(),
						"Verify the error message for Invalid Mobile number filed by entering less than 10 numbers in Personal info section",
						"Verify the error message for Invalid Mobile number filed by entering less than 10 numbers in Personal info section");
				testcase.pass(
						"Error message is displayed for Invalid mobile number by entering less than 10 numbers in Personal info section");
				break;
			} catch (Exception e) {
				testcase.retry(
						"Error message is displayed for Invalid mobile number by entering less than 10 numbers in Personal info section",
						testcase, retry, e);
				e.printStackTrace();
			}
		}

	}
	// 53//
	//35//
	// To verify the error message displayed for 'Alternate Phone Number' field on
	// entering more or less than 10 numeric characters in 'PERSONAL INFORMATION'
	// section in 'My Account' page.//

	@Test
	public void errorMessageForInvalidAltMobileNumber() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditPersonalInfo();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAddressLineValidFirstname();
				SeleniumUtils.wait(2);
				MyAccountPage.clickAddressLineValidLastname();
				SeleniumUtils.wait(2);
				MyAccountPage.clickAddressLineOne();
				SeleniumUtils.wait(2);
				MyAccountPage.enterAddressinAddressField();
				SeleniumUtils.wait(3);
				MyAccountPage.clickAddressLineCity();
				SeleniumUtils.wait(2);
				MyAccountPage.enterinCity();
				SeleniumUtils.wait(2);
				MyAccountPage.clickAddressLineMobNumber();
				SeleniumUtils.wait(2);
				MyAccountPage.enterInvalidAltNum();
				SeleniumUtils.wait(4);
				MyAccountPage.clickAddressLineSaveButton();
				SeleniumUtils.wait(2);
				testcase.assertTrue(MyAccountPage.isErrorMessageForInvalidAltMobNum(),
						"Verify the error message for Invalid Alternate Mobile number filed by entering less than 10 numbers in Personal info section",
						"Verify the error message for Invalid Alternate Mobile number filed by entering less than 10 numbers in Personal info section");
				testcase.pass(
						"Error message is displayed for Invalid Alternate mobile number by entering less than 10 numbers in Personal info section");
				break;
			} catch (Exception e) {
				testcase.retry(
						"Error message is displayed for Invalid Alternate mobile number by entering less than 10 numbers in Personal info section",
						testcase, retry, e);
				e.printStackTrace();
			}
		}

	}
	// 58//
	//36//
	// To verify the functionality of 'Edit Email' button of 'PASSWORD & SECURITY'
	// section in 'My Account' page.//

	@Test
	public void editEmailNSecurityDataTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditEmailPasswordSecurity();
				SeleniumUtils.wait(5);
				testcase.assertTrue(MyAccountPage.isEmailSecuritySectionLabels(),
						"Edit Email  Security section labels is displayed",
						"Edit Email Security section labels is not displayed");
				testcase.pass("Email and Security section is allowed to edit in My Account page");
				break;
			} catch (Exception e) {
				testcase.retry("Email and Security section is allowed to edit in My Account page", testcase, retry, e);
				e.printStackTrace();
			}
		}
	}
	// 59//
	//37//
	// To verify the display of 'CHANGE EMAIL' popup of 'PASSWORD & SECURITY'
	// section in 'My Account' page.//

	@Test
	public void changeEmailPopUpINSecurityDataTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditEmailPasswordSecurity();
				SeleniumUtils.wait(5);
				testcase.assertTrue(MyAccountPage.isChangeEmailPopup(),
						"Change email popup in Security section labels is displayed",
						"Change email popup in Security section labels is displayed");
				testcase.pass("Change email Popup is displayed in My Account page");
				break;
			} catch (Exception e) {
				testcase.retry("Change email Popup is displayed in My Account page", testcase, retry, e);
				e.printStackTrace();
			}
		}
	}

	// 60//
	//38//
	// To verify the display and disappearance of placeholder in 'New Email' textbox
	// of 'CHANGE EMAIL' popup of 'PASSWORD & SECURITY' section in 'My Account'
	// page.//
	@Test
	public void newEmailTextboxInChangeEmailPopup() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditEmailPasswordSecurity();
				SeleniumUtils.wait(5);
				MyAccountPage.displayNewEmailTextbox();
				SeleniumUtils.wait(2);
				MyAccountPage.clickNewEmailTextbox();
				testcase.assertTrue(MyAccountPage.displayNewEmailTextbox(),
						"Verify the display of New email textbox in Change email pop up",
						"Verify the display of New email textbox in Change email pop up");
				testcase.pass(
						"verify the display and disappearance of placeholder in 'New Email' textbox of 'CHANGE EMAIL' popup");
				break;
			} catch (Exception e) {
				testcase.retry(
						"verify the display and disappearance of placeholder in 'New Email' textbox of 'CHANGE EMAIL' popup",
						testcase, retry, e);
				e.printStackTrace();
			}
		}
	}

	// 61//
	//39//
	// To verify the display and disappearance of placeholder in 'Confirm Email'
	// textbox of 'CHANGE EMAIL' popup of 'PASSWORD & SECURITY' section in 'My
	// Account' page.//
	@Test
	public void confirmEmailTextboxInChangeEmailPopup() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditEmailPasswordSecurity();
				SeleniumUtils.wait(5);
				MyAccountPage.displayConfirmEmailTextbox();
				SeleniumUtils.wait(2);
				MyAccountPage.clickConfirmEmailTextbox();
				testcase.assertTrue(MyAccountPage.displayConfirmEmailTextbox(),
						"Verify the display of Confirm email textbox in Change email pop up",
						"Verify the display of Confirm email textbox in Change email pop up");
				testcase.pass(
						"verify the display and disappearance of placeholder in 'Confirm Email' textbox of 'CHANGE EMAIL' popup");
				break;
			} catch (Exception e) {
				testcase.retry(
						"verify the display and disappearance of placeholder in 'Confirm Email' textbox of 'CHANGE EMAIL' popup",
						testcase, retry, e);
				e.printStackTrace();
			}
		}
	}
	// 62//
	//40//
	// To verify the display and disappearance of placeholder in 'Confirm Email'
	// textbox of 'CHANGE EMAIL' popup of 'PASSWORD & SECURITY' section in 'My
	// Account' page.//

	@Test
	public void enterAnyDataNconfirmEmailTextboxInChangeEmailPopup() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditEmailPasswordSecurity();
				SeleniumUtils.wait(5);
				MyAccountPage.displayConfirmEmailTextbox();
				SeleniumUtils.wait(2);
				MyAccountPage.clickConfirmEmailTextbox();
				SeleniumUtils.wait(2);
				MyAccountPage.enterDataNConfirmEmailBox();
				testcase.assertTrue(MyAccountPage.displayConfirmEmailTextbox(),
						"Verify the display of disappearance of placeholder in Confirm email textbox in Change email pop up",
						"Verify the display of disappearance of placeholder in Confirm email textbox in Change email pop up");
				testcase.pass(
						"verify the display and disappearance of placeholder when User enters dara in confirm email textbox");
				break;
			} catch (Exception e) {
				testcase.retry(
						"verify the display and disappearance of placeholder when User enters dara in confirm email textbox",
						testcase, retry, e);
				e.printStackTrace();
			}
		}
	}

	// 63//
	//41//
	// To verify that the signed In user is able to change email address in
	// 'PASSWORD & SECURITY' section in 'My Account' page.//
	@Test
	public void signedUserAbleToChangeEmailNChangeEmailPopup() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditEmailPasswordSecurity();
				SeleniumUtils.wait(5);
				MyAccountPage.enterValidNewEmailInTextbox();
				SeleniumUtils.wait(2);
				MyAccountPage.enterValidNewEmailInConfirmEmailTextbox();
				SeleniumUtils.wait(2);
				testcase.assertTrue(MyAccountPage.displayConfirmEmailTextbox(),
						"Verify the display of signed user is able to enter valid email in email texboxes in Change email pop up",
						"Verify the display of signed user is able to enter valid email in email texboxes in Change email pop up");
				testcase.pass(
						"verify the display of signed in user is able to enter data in email textbox in confirm email textbox");
				break;
			} catch (Exception e) {
				testcase.retry(
						"verify the display of signed in user is able to enter data in email textbox in confirm email textbox",
						testcase, retry, e);
				e.printStackTrace();
			}
		}
	}

	// 64//
	//42//
	// To verify the functionality of 'Cancel' button in 'CHANGE EMAIL' popup in
	// 'PASSWORD & SECURITY' section in 'My Account' page.//
	@Test
	public void verifyCancelButtonInChangeEmailPopup() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditEmailPasswordSecurity();
				SeleniumUtils.wait(5);
				MyAccountPage.clickCancelButton();
				SeleniumUtils.wait(2);
				testcase.assertTrue(MyAccountPage.isPasswordSecuritySectionTitle(),
						"Functionality of Cancel button in Change email pop up",
						"Functionality of Cancel button in Change email pop up");
				testcase.pass("Verify the functionality of Cancel button in Change email pop up");
				break;
			} catch (Exception e) {
				testcase.retry("Verify the functionality of Cancel button in Change email pop up", testcase, retry, e);
				e.printStackTrace();
			}
		}
	}
	// 65//
	//43//
	// To verify the functionality of 'X' icon in 'CHANGE EMAIL' popup in 'PASSWORD
	// & SECURITY' section in 'My Account' page.//

	@Test
	public void verifyCloseIconInChangeEmailPopup() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditEmailPasswordSecurity();
				SeleniumUtils.wait(5);
				MyAccountPage.clickCloseIconInEmailPopup();
				SeleniumUtils.wait(2);
				testcase.assertTrue(MyAccountPage.isPasswordSecuritySectionTitle(),
						"Functionality of Close Icon in Change email pop up",
						"Functionality of Close Icon in Change email pop up");
				testcase.pass("Verify the functionality of Close Icon in Change email pop up");
				break;
			} catch (Exception e) {
				testcase.retry("Verify the functionality of Close Icon in Change email pop up", testcase, retry, e);
				e.printStackTrace();
			}
		}
	}
	// 66//
	//44//
	// To verify the display of error message for already used email address in
	// 'CHANGE EMAIL' popup of 'PASSWORD & SECURITY' section in 'My Account' page.//

	@Test
	public void errorMessageForAlreadyUsedEmailNChangeEmailPopup() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditEmailPasswordSecurity();
				SeleniumUtils.wait(5);
				MyAccountPage.enterValidRegisteredNewEmailInTextbox();
				SeleniumUtils.wait(2);
				MyAccountPage.enterValidRegisteredConfirmEmailInTextbox();
				SeleniumUtils.wait(2);
				MyAccountPage.clickUpdateButtonInConfirmEmailPopup();
				testcase.assertTrue(MyAccountPage.displayErrorMessage(),
						"Error message for already used email ID in Change email pop up",
						"Error message for already used email ID in Change email pop up");
				testcase.pass("Verify the display of error message for already used email ID in Change email pop up");
				break;
			} catch (Exception e) {
				testcase.retry("Verify the display of error message for already used email ID in Change email pop up",
						testcase, retry, e);
				e.printStackTrace();
			}
		}
	}

	// 67//
	//45//
	// To verify the display of error message for invalid email address in 'CHANGE
	// EMAIL' popup of 'PASSWORD & SECURITY' section in 'My Account' page.//
	@Test
	public void errorMessageForInvalidEmailNChangeEmailPopup() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditEmailPasswordSecurity();
				SeleniumUtils.wait(5);
				MyAccountPage.enterInvalidNewEmailInTextbox();
				SeleniumUtils.wait(2);
				MyAccountPage.clickUpdateButtonInConfirmEmailPopup();
				testcase.assertTrue(MyAccountPage.displayErrorMessageForInvalidEmail(),
						"Error message for Invalid email ID in Change email pop up",
						"Error message for Invalid used email ID in Change email pop up");
				testcase.pass("Verify the display of error message for Invalid email ID in Change email pop up");
				break;
			} catch (Exception e) {
				testcase.retry("Verify the display of error message for Invalid email ID in Change email pop up",
						testcase, retry, e);
				e.printStackTrace();
			}
		}
	}

	// 68//
	//46//
	// To verify the display of error message for different email addresses in
	// 'CHANGE EMAIL' popup of 'PASSWORD & SECURITY' section in 'My Account' page.//
	@Test
	public void errorMessageForDiffEmailInConfirmEmailBox() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditEmailPasswordSecurity();
				SeleniumUtils.wait(5);
				MyAccountPage.enterValidRegisteredNewEmailInTextbox();
				SeleniumUtils.wait(2);
				MyAccountPage.enterValidNewEmailInConfirmEmailTextbox();
				SeleniumUtils.wait(2);
				MyAccountPage.clickUpdateButtonInConfirmEmailPopup();
				testcase.assertTrue(MyAccountPage.errorMessageForAnotherEmail(),
						"Error message for Invalid email ID in Change email pop up",
						"Error message for Invalid used email ID in Change email pop up");
				testcase.pass("Verify the display of error message for Invalid email ID in Change email pop up");
				break;
			} catch (Exception e) {
				testcase.retry("Verify the display of error message for Invalid email ID in Change email pop up",
						testcase, retry, e);
				e.printStackTrace();
			}
		}
	}

	// 69//
	//47//
	// To verify the error message for invalid email in 'CHANGE EMAIL' popup of
	// 'PASSWORD & SECURITY' section in 'My Account' page.//
	@Test
	public void errorMessageForInValidNewEmailNConfirmEmailBox() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditEmailPasswordSecurity();
				SeleniumUtils.wait(5);
				MyAccountPage.enterInvalidNewEmailInTextbox();
				SeleniumUtils.wait(2);
				MyAccountPage.enterValidRegisteredConfirmEmailInTextbox();
				SeleniumUtils.wait(2);
				MyAccountPage.clickUpdateButtonInConfirmEmailPopup();
				testcase.assertTrue(MyAccountPage.errorMessageForInvalidEmail(),
						"Error message for Invalid email ID in Email text box in Change email pop up",
						"Error message for Invalid email ID in Email text box in Change email pop up");
				testcase.pass(
						"Verify the display of error message for Invalid email ID in Email text box in Change email pop up");
				break;
			} catch (Exception e) {
				testcase.retry(
						"Verify the display of error message for Invalid email ID in Email text box in Change email pop up",
						testcase, retry, e);
				e.printStackTrace();
			}
		}
	}

	// 70//
	//48//
	// To verify the display of error messages for blank fields while editing in
	// 'PASSWORD & SECURITY' section in 'My Account' page.//
	@Test
	public void errorMessageForBlankFieldsNEmailNChangeEmailPopup() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditEmailPasswordSecurity();
				SeleniumUtils.wait(5);
				MyAccountPage.clickUpdateButtonInConfirmEmailPopup();
				testcase.assertTrue(MyAccountPage.displayErrorMessageForBlankFields(),
						"Error message for blank fields while editing in Change email pop up",
						"Error message for blank fields while editing in Change email pop up");
				testcase.pass(
						"Verify the display of Error message for blank fields while editing in Change email pop up");
				break;
			} catch (Exception e) {
				testcase.retry(
						"Verify the display of Error message for blank fields while editing in Change email pop up",
						testcase, retry, e);
				e.printStackTrace();
			}
		}
	}
	//49//
	// To verify that the user is able to login with new updated email address in
	// 'PASSWORD & SECURITY' section in 'My Account' page.//

	@Test
	public void loginWithNewUpdatedEmailAddress() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing12@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditEmailPasswordSecurity();
				SeleniumUtils.wait(5);
				MyAccountPage.enterNewRegisteredNewEmailInTextbox();
				SeleniumUtils.wait(2);
				MyAccountPage.enterNewRegisteredConfirmEmailInTextbox();
				SeleniumUtils.wait(2);
				MyAccountPage.clickUpdateButtonInConfirmEmailPopup();
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.clickLogoutButtonInConfirmEmailPopup();
				SeleniumUtils.wait(3);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(2);
				testcase.pass(
						"verify the display of signed in user is able to enter data in email textbox in confirm email textbox");
				break;
			} catch (Exception e) {
				testcase.retry(
						"verify the display of signed in user is able to enter data in email textbox in confirm email textbox",
						testcase, retry, e);
				e.printStackTrace();
			}
		}
	}
	//50//
	// To verify that the user is not able to login with old email address that has
	// been updated in 'PASSWORD & SECURITY' section in 'My Account' page.//

	@Test
	public void loginWithOldEmailAddress() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing12@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditEmailPasswordSecurity();
				SeleniumUtils.wait(5);
				MyAccountPage.enterNewRegisteredNewEmailInTextbox();
				SeleniumUtils.wait(2);
				MyAccountPage.enterNewRegisteredConfirmEmailInTextbox();
				SeleniumUtils.wait(2);
				MyAccountPage.clickUpdateButtonInConfirmEmailPopup();
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.clickLogoutButtonInConfirmEmailPopup();
				SeleniumUtils.wait(3);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(2);
				testcase.pass(
						"verify the display of signed in user is able to enter data in email textbox in confirm email textbox");
				break;
			} catch (Exception e) {
				testcase.retry(
						"verify the display of signed in user is able to enter data in email textbox in confirm email textbox",
						testcase, retry, e);
				e.printStackTrace();
			}
		}
	}
	//51//
	// To verify the display of 'CHANGE PASSWORD' popup of 'PASSWORD & SECURITY'
	// section in 'My Account' page.//

	@Test
	public void changePasswordNSecurityDataTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditPasswordSecurity();
				SeleniumUtils.wait(5);
				testcase.assertTrue(MyAccountPage.isChangePasswordPopUp(),
						"Change Password Security section label is displayed",
						"Change Password Security section label is not displayed");
				testcase.pass("Verify the display of Change password in Password security");
				break;
			} catch (Exception e) {
				testcase.retry("Verify the display of Change password in Password security", testcase, retry, e);
				e.printStackTrace();
			}
		}
	}
//52//
	// To verify that the signed In user is able to change password in 'PASSWORD &
	// SECURITY' section in 'My Account' page.//
	@Test
	public void signedNUserableTochangePasswordNSecurityDataTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditPasswordSecurity();
				SeleniumUtils.wait(5);
				MyAccountPage.clickCurrentPasswordSecurity();
				SeleniumUtils.wait(2);
				MyAccountPage.clickNewPasswordSecurity();
				SeleniumUtils.wait(2);
				MyAccountPage.clickConfirmPasswordSecurity();
				SeleniumUtils.wait(2);
				MyAccountPage.clickPasswordSecurityUpdateButton();
				SeleniumUtils.wait(2);
				testcase.assertTrue(MyAccountPage.isChangePasswordPopUp(),
						"Signed in user is able to Change the New Password in Password security fields",
						"Signed in user is able to Change the New Password in Password security fields");
				testcase.pass(
						"Verify that Signed in user is able to Change the New Password in Password security fields");
				break;
			} catch (Exception e) {
				testcase.retry(
						"Verify that Signed in user is able to Change the New Password in Password security fields",
						testcase, retry, e);
				e.printStackTrace();
			}
		}
	}
//53//
	// To verify that the user is able to login into his account with updated
	// password in 'PASSWORD & SECURITY' section in 'My Account' page.//
	@Test
	public void signedNUserableToLoginWithNewPassword() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditPasswordSecurity();
				SeleniumUtils.wait(5);
				MyAccountPage.clickCurrentPasswordSecurity();
				SeleniumUtils.wait(2);
				MyAccountPage.clickNewPasswordSecurity();
				SeleniumUtils.wait(2);
				MyAccountPage.clickConfirmPasswordSecurity();
				SeleniumUtils.wait(2);
				MyAccountPage.clickPasswordSecurityUpdateButton();
				SeleniumUtils.wait(2);
				MyAccountPage.clickLogoutButtonInConfirmEmailPopup();
				SeleniumUtils.wait(2);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				testcase.pass("Verify that Signed in user is able to Login with new password");
				break;
			} catch (Exception e) {
				testcase.retry("Verify that Signed in user is able to Login with new password", testcase, retry, e);
				e.printStackTrace();
			}
		}
	}
	// To verify that the user is not able to login into his account with old
	// password in 'PASSWORD & SECURITY' section in 'My Account' page.//
//54//
	@Test
	public void signedNUserableToLoginWithOldPassword() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditPasswordSecurity();
				SeleniumUtils.wait(5);
				MyAccountPage.clickCurrentPasswordSecurity();
				SeleniumUtils.wait(2);
				MyAccountPage.clickNewPasswordSecurity();
				SeleniumUtils.wait(2);
				MyAccountPage.clickConfirmPasswordSecurity();
				SeleniumUtils.wait(2);
				MyAccountPage.clickPasswordSecurityUpdateButton();
				SeleniumUtils.wait(2);
				MyAccountPage.clickLogoutButtonInConfirmEmailPopup();
				SeleniumUtils.wait(2);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@1234");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				testcase.pass("Verify that Signed in user is able to Login with Old password");
				break;
			} catch (Exception e) {
				testcase.retry("Verify that Signed in user is able to Login with Old password", testcase, retry, e);
				e.printStackTrace();
			}
		}
	}
	//55//
	// To verify the functionality of 'Cancel' button in 'CHANGE PASSWORD' popup in
	// 'PASSWORD & SECURITY' section in 'My Account' page.//

	@Test
	public void cancelButtonNSecurityDataTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditPasswordSecurity();
				SeleniumUtils.wait(5);
				MyAccountPage.clickCancelButtonInPasswordSecurity();
				testcase.assertTrue(MyAccountPage.isPasswordSecuritySectionTitle(),
						"Cancel button is displayed in Password Security section",
						"Cancel button is displayed in Password Security section");
				testcase.pass("Verify that the Cancel button is displayed in Password Security section");
				break;
			} catch (Exception e) {
				testcase.retry("Verify that the Cancel button is displayed in Password Security section", testcase,
						retry, e);
				e.printStackTrace();
			}
		}
	}
	//56//
	// To verify the functionality of 'X' icon in 'CHANGE PASSWORD' popup in
	// 'PASSWORD & SECURITY' section in 'My Account' page.//

	@Test
	public void closeButtonNSecurityDataTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditPasswordSecurity();
				SeleniumUtils.wait(5);
				MyAccountPage.clickCloseButtonInPasswordSecurity();
				testcase.assertTrue(MyAccountPage.isPasswordSecuritySectionTitle(),
						"Close button is displayed in Password Security section",
						"Close button is displayed in Password Security section");
				testcase.pass("Verify theat the Cancel button is displayed in Password Security section");
				break;
			} catch (Exception e) {
				testcase.retry("Verify that the Close button is displayed in Password Security section", testcase,
						retry, e);
				e.printStackTrace();
			}
		}
	}
	//57//
	// To verify the display of error message for wrong 'Current Password' in
	// 'CHANGE PASSWORD' popup of 'PASSWORD & SECURITY' section in 'My Account'
	// page.//

	@Test
	public void errorMessageForWrongCurrentPasswordNSecurityDataTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditPasswordSecurity();
				SeleniumUtils.wait(5);
				MyAccountPage.clickCurrentPasswordSecurity();
				SeleniumUtils.wait(2);
				MyAccountPage.clickNewPasswordSecurity();
				SeleniumUtils.wait(2);
				MyAccountPage.clickPasswordSecurityUpdateButton();
				testcase.assertTrue(MyAccountPage.isPasswordSecuritySectionErrorMessage(),
						"Error message is displayed for Current password in Password Security section",
						"Error message is displayed for Current password in Password Security section");
				testcase.pass("Verify Error message is displayed for Current password in Password Security section");
				break;
			} catch (Exception e) {
				testcase.retry("Verify Error message is displayed for Current password in Password Security section", testcase,
						retry, e);
				e.printStackTrace();
			}
		}
	}
	//58//
//To verify the display of error messages for same passwords while editing in 'PASSWORD & SECURITY' section in 'My Account' page.//
	@Test
	public void errorMessageForSamePasswordNSecurityDataTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditPasswordSecurity();
				SeleniumUtils.wait(5);
				MyAccountPage.clickCurrentPasswordSecurity();
				SeleniumUtils.wait(2);
				MyAccountPage.clickNewPasswordSecurity();
				SeleniumUtils.wait(2);
				MyAccountPage.clickConfirmPasswordSecurity();
				SeleniumUtils.wait(2);
				MyAccountPage.clickPasswordSecurityUpdateButton();
				testcase.assertTrue(MyAccountPage.isPasswordSecuritySectionErrorMessage(),
						"Error message is displayed for Current password in Password Security section",
						"Error message is displayed for Current password in Password Security section");
				testcase.pass("Verify Error message is displayed for Current password in Password Security section");
				break;
			} catch (Exception e) {
				testcase.retry("Verify Error message is displayed for Current password in Password Security section", testcase,
						retry, e);
				e.printStackTrace();
			}
		}
	}
	//59//
//To verify the error message for password that does not meet requirements in 'CHANGE PASSWORD' popup of 'PASSWORD & SECURITY' section in 'My Account' page.//
	
	@Test
	public void errorMessageForPasswordThatDoesntMeetRequirements() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditPasswordSecurity();
				SeleniumUtils.wait(5);
				MyAccountPage.clickCurrentPasswordSecurity();
				SeleniumUtils.wait(2);
				MyAccountPage.clickInvalidPasswordSecurity();
				SeleniumUtils.wait(2);
				MyAccountPage.clickPasswordSecurityUpdateButton();
				testcase.assertTrue(MyAccountPage.isPasswordSecuritySectionErrorMessage(),
						"Error message is displayed for password that does not meet requirements in Password Security section",
						"Error message is displayed for password that does not meet requirements in Password Security section");
				testcase.pass("Verify Error message is displayed for Current password in Password Security section");
				break;
			} catch (Exception e) {
				testcase.retry("Verify that the Error message is displayed for password that does not meet requirements in Password Security section", testcase,
						retry, e);
				e.printStackTrace();
			}
		}
	}
	//60//
//To verify the display of error messages for different passwords in New & Confirm password fields while editing in 'PASSWORD & SECURITY' section in 'My Account' page.//
	
	@Test
	public void errorMessageForDiffPasswordsInNewNdConfirmFields() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditPasswordSecurity();
				SeleniumUtils.wait(5);
				MyAccountPage.clickCurrentPasswordSecurity();
				SeleniumUtils.wait(2);
				MyAccountPage.clickNewPasswordSecurity();
				SeleniumUtils.wait(2);
				MyAccountPage.clickConfirmPasswordSecurity();
				SeleniumUtils.wait(2);
				MyAccountPage.clickPasswordSecurityUpdateButton();
				testcase.assertTrue(MyAccountPage.isPasswordSecuritySectionErrorMessage(),
						"Error message is displayed for different passwords in New and Confirm Password fields in Password Security section",
						"Error message is displayed for different passwords in New and Confirm Password fields in Password Security section");
				testcase.pass("Verify that the Error message is displayed for different passwords in New and Confirm Password fields in Password Security section");
				break;
			} catch (Exception e) {
				testcase.retry("Verify that the Error message is displayed for different passwords in New and Confirm Password fields in Password Security section", testcase,
						retry, e);
				e.printStackTrace();
			}
		}
	}
	//61//
//To verify the display of error messages for blank fields while editing in 'CHANGE PASSWORD' popup of 'PASSWORD & SECURITY' section in 'My Account' page.//
	
	@Test
	public void errorMessageForBlankFieldsNEmailNChangePasswordField() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickEditPasswordSecurity();
				SeleniumUtils.wait(5);
				MyAccountPage.clickPasswordSecurityUpdateButton();
				testcase.assertTrue(MyAccountPage.displayErrorMessageForPasswordBlankFields(),
						"Error message for blank fields while editing in Change password pop up",
						"Error message for blank fields while editing in Change password pop up");
				testcase.pass(
						"Verify the display of Error message for blank fields while editing in Change password pop up");
				break;
			} catch (Exception e) {
				testcase.retry(
						"Verify the display of Error message for blank fields while editing in Change password pop up",
						testcase, retry, e);
				e.printStackTrace();
			}
		}
	}
	//62//
//To verify the functionality of '-' icon of 'PASSWORD & SECURITY' section in 'My Account' page.//
	@Test
	public void functionalityOfMinusicon() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				MyAccountPage.clickMinimizePasswordSecurity();
				testcase.assertTrue(MyAccountPage.isPasswordSecuritySectionTitle(),
						"Functionality of '-' icon of 'PASSWORD & SECURITY' section in 'My Account' page",
						"Functionality of '-' icon of 'PASSWORD & SECURITY' section in 'My Account' page");
				testcase.pass(
						"Verify the Functionality of '-' icon of 'PASSWORD & SECURITY' section in 'My Account' page");
				break;
			} catch (Exception e) {
				testcase.retry(
						"Verify the Functionality of '-' icon of 'PASSWORD & SECURITY' section in 'My Account' page",
						testcase, retry, e);
				e.printStackTrace();
			}
		}
	}
	//63//
//To verify that the user edits the Reminders of 'COMMUNICATION PREFERENCES' section in 'My Account' page.//
	
	@Test
	public void communPreferenceEditRemindersTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				testcase.assertTrue(MyAccountPage.isCommnPreferenceSectionTitle(),
						"Communication Preferences section Title is displayed",
						"Communication Preferences section Title is not displayed");
				MyAccountPage.clickEditCommunicationPreference();
				SeleniumUtils.wait(2);
				MyAccountPage.clickRemindersNCommunicationPreference();
				MyAccountPage.clickSaveButtonNCommunicationPreference();
				testcase.assertTrue(MyAccountPage.isCommnPreferenceSectionTitle(),
						"Communication Preferences section Title is displayed",
						"Communication Preferences section Title is not displayed");
				testcase.pass("Communication Preferences edits reminders section is displayed");
				break;
			} catch (Exception e) {
				testcase.retry("Verify that the Communication Preferences edits reminders section is displayed in My account page",
						testcase, retry, e);
				e.printStackTrace();
			}
		}
	}
	//64//
//To verify that the user edits the Promotions of 'COMMUNICATION PREFERENCES' section in 'My Account' page.//
	
	@Test
	public void communPreferenceEditPromotionsTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				testcase.assertTrue(MyAccountPage.isCommnPreferenceSectionTitle(),
						"Communication Preferences section Title is displayed",
						"Communication Preferences section Title is not displayed");
				MyAccountPage.clickEditCommunicationPreference();
				SeleniumUtils.wait(2);
				MyAccountPage.clickPromotionsNCommunicationPreference();
				MyAccountPage.clickSaveButtonNCommunicationPreference();
				testcase.assertTrue(MyAccountPage.isCommnPreferenceSectionTitle(),
						"Communication Preferences section Title is displayed",
						"Communication Preferences section Title is not displayed");
				testcase.pass("Communication Preferences edits promotions section is displayed");
				break;
			} catch (Exception e) {
				testcase.retry("Verify that the Communication Preferences edits promotions section is displayed in My account page",
						testcase, retry, e);
				e.printStackTrace();
			}
		}
	}
	//65//
//To verify the functionality of 'Cancel' button in 'COMMUNICATION PREFERENCES' section in 'My Account' page.//
	
	@Test
	public void communPreferenceFunctionalityOfCancelButton() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				testcase.assertTrue(MyAccountPage.isCommnPreferenceSectionTitle(),
						"Communication Preferences section Title is displayed",
						"Communication Preferences section Title is not displayed");
				MyAccountPage.clickEditCommunicationPreference();
				SeleniumUtils.wait(2);
				MyAccountPage.clickCancelButtonNCommunicationPreference();
				testcase.assertTrue(MyAccountPage.isCommnPreferenceSectionTitle(),
						"Communication Preferences section Title is displayed",
						"Communication Preferences section Title is not displayed");
				testcase.pass("Communication Preferences cancel button is displayed");
				break;
			} catch (Exception e) {
				testcase.retry("Verify that the Communication Preferences cancel button is displayed in Account details page",
						testcase, retry, e);
				e.printStackTrace();
			}
		}
	}
	//66//
//To verify the functionality of 'View Installer details' link in the list of installers in 'MY PREFERRED INSTALLERS' section in 'My Account' page.//
	
	//@Test
	public void myPrefeInstallersViewInstallersDetailsLink() throws Exception {
			String name = new Object() {
			}.getClass().getEnclosingMethod().getName();
			TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
			Retry retry = new Retry(0);
			while (retry.retry()) {
				try {
					tyreURL();
					SeleniumUtils.wait(5);
					HeaderFooterPage.clickSignInOrRegistration();
					SeleniumUtils.wait(5);
					LoginPage.enterEmailInTextbox("testing@gmail.com");
					SeleniumUtils.wait(5);
					LoginPage.enterPasswordInTextbox("Test@123");
					SeleniumUtils.wait(5);
					LoginPage.clickSignInButton();
					SeleniumUtils.wait(3);
					testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
							"User has has not logged In");
					SeleniumUtils.wait(5);
					MyAccountPage.hoverOnMyAccount();
					SeleniumUtils.wait(5);
					MyAccountPage.clickAccountDetailsLink();
					SeleniumUtils.wait(5);
					testcase.assertTrue(MyAccountPage.isMyPrefereedInstallersSectionTitle(),
							"My Preferred Installers section Title is displayed",
							"My Preferred Installers section Title is not displayed");
					//Steps need to be updated//
					testcase.pass("My Preferred Installers section is displayed with title and list in My Account page");
					break;
				} catch (Exception e) {
					testcase.retry("My Preferred Installers section is displayed with title and list in My Account page",
							testcase, retry, e);
					e.printStackTrace();
				}
			}
		}
//67//
//To verify the functionality of '+Add  an Installer' button  in 'MY PREFERRED INSTALLERS' section when there are no installers in 'My Account' page.//
	
	//@Test
	public void myPrefeInstallersAddInstallersButton() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				testcase.assertTrue(MyAccountPage.isMyPrefereedInstallersSectionTitle(),
						"My Preferred Installers section Title is displayed",
						"My Preferred Installers section Title is not displayed");
				//Steps need to be updated//
				testcase.pass("My Preferred Installers section is displayed with title and list in My Account page");
				break;
			} catch (Exception e) {
				testcase.retry("My Preferred Installers section is displayed with title and list in My Account page",
						testcase, retry, e);
				e.printStackTrace();
			}
		}
	}
//68//
//To verify the functionality of 'Edit Nickname' link in 'MY PREFERRED INSTALLERS' section in 'My Account' page.//
	

	//@Test
	public void myPrefeInstallersEditNicknameLink() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(0);
		while (retry.retry()) {
			try {
				tyreURL();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.enterEmailInTextbox("testing@gmail.com");
				SeleniumUtils.wait(5);
				LoginPage.enterPasswordInTextbox("Test@123");
				SeleniumUtils.wait(5);
				LoginPage.clickSignInButton();
				SeleniumUtils.wait(3);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				SeleniumUtils.wait(5);
				MyAccountPage.hoverOnMyAccount();
				SeleniumUtils.wait(5);
				MyAccountPage.clickAccountDetailsLink();
				SeleniumUtils.wait(5);
				testcase.assertTrue(MyAccountPage.isMyPrefereedInstallersSectionTitle(),
						"My Preferred Installers section Title is displayed",
						"My Preferred Installers section Title is not displayed");
				//Steps need to be updated//
				testcase.pass("My Preferred Installers section is displayed with title and list in My Account page");
				break;
			} catch (Exception e) {
				testcase.retry("My Preferred Installers section is displayed with title and list in My Account page",
						testcase, retry, e);
				e.printStackTrace();
			}
		}
	}
//69//
//To verify the functionality of 'Save' button for 'Edit Nickname' in 'MY PREFERRED INSTALLERS' section in 'My Account' page.//
	//@Test
		public void myPrefeSaveButtonForEditNickname() throws Exception {
			String name = new Object() {
			}.getClass().getEnclosingMethod().getName();
			TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
			Retry retry = new Retry(0);
			while (retry.retry()) {
				try {
					tyreURL();
					SeleniumUtils.wait(5);
					HeaderFooterPage.clickSignInOrRegistration();
					SeleniumUtils.wait(5);
					LoginPage.enterEmailInTextbox("testing@gmail.com");
					SeleniumUtils.wait(5);
					LoginPage.enterPasswordInTextbox("Test@123");
					SeleniumUtils.wait(5);
					LoginPage.clickSignInButton();
					SeleniumUtils.wait(3);
					testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
							"User has has not logged In");
					SeleniumUtils.wait(5);
					MyAccountPage.hoverOnMyAccount();
					SeleniumUtils.wait(5);
					MyAccountPage.clickAccountDetailsLink();
					SeleniumUtils.wait(5);
					testcase.assertTrue(MyAccountPage.isMyPrefereedInstallersSectionTitle(),
							"My Preferred Installers section Title is displayed",
							"My Preferred Installers section Title is not displayed");
					//Steps need to be updated//
					testcase.pass("My Preferred Installers section is displayed with title and list in My Account page");
					break;
				} catch (Exception e) {
					testcase.retry("My Preferred Installers section is displayed with title and list in My Account page",
							testcase, retry, e);
					e.printStackTrace();
				}
			}
		}
//70//
//To verify the error message for invalid nickname in 'Edit Nickname' in 'MY PREFERRED INSTALLERS' section in 'My Account' page.//
		//@Test
				public void myPrefeInstaErrorMessForInvalidNickname() throws Exception {
					String name = new Object() {
					}.getClass().getEnclosingMethod().getName();
					TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
					Retry retry = new Retry(0);
					while (retry.retry()) {
						try {
							tyreURL();
							SeleniumUtils.wait(5);
							HeaderFooterPage.clickSignInOrRegistration();
							SeleniumUtils.wait(5);
							LoginPage.enterEmailInTextbox("testing@gmail.com");
							SeleniumUtils.wait(5);
							LoginPage.enterPasswordInTextbox("Test@123");
							SeleniumUtils.wait(5);
							LoginPage.clickSignInButton();
							SeleniumUtils.wait(3);
							testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
									"User has has not logged In");
							SeleniumUtils.wait(5);
							MyAccountPage.hoverOnMyAccount();
							SeleniumUtils.wait(5);
							MyAccountPage.clickAccountDetailsLink();
							SeleniumUtils.wait(5);
							testcase.assertTrue(MyAccountPage.isMyPrefereedInstallersSectionTitle(),
									"My Preferred Installers section Title is displayed",
									"My Preferred Installers section Title is not displayed");
							//Steps need to be updated//
							testcase.pass("My Preferred Installers section is displayed with title and list in My Account page");
							break;
						} catch (Exception e) {
							testcase.retry("My Preferred Installers section is displayed with title and list in My Account page",
									testcase, retry, e);
							e.printStackTrace();
						}
					}
				}
		
}
