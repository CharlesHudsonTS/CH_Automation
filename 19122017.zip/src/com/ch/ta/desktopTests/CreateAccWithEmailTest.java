package com.ch.ta.desktopTests;

import java.util.ArrayList;
import java.util.Iterator;

import org.openqa.selenium.Keys;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ch.ExcelUtils.ExcelProperty;
import com.ch.report.utils.AbstractTestCaseReport;
import com.ch.reports.TestCaseDetail;
import com.ch.reports.TestCaseFactory;
import com.ch.retry.Retry;
import com.ch.ta.bean.User;
import com.ch.ta.desktopPages.CreateAccWithEmailPage;
import com.ch.ta.desktopPages.CreateAnAccountPage;
import com.ch.ta.desktopPages.HeaderFooterPage;
import com.ch.ta.desktopPages.HomePage;
import com.ch.ta.desktopPages.LoginPage;
import com.ch.ta.desktopPages.MyAccountPage;
import com.ch.ta.utils.CommonUtils;
import com.ch.ta.utils.FileUtility;
import com.ch.ta.utils.constants.FileConstants;
import com.ch.utils.DriverFactory;
import com.ch.utils.SeleniumUtils;

@Listeners(com.ch.utils.ParallelFactory.class)
public class CreateAccWithEmailTest extends AbstractTestCaseReport implements FileConstants {

	// To verify the display and functionality of 'Log In' link in 'Create
	// account with email' page.
	// @Test
	public void createAccEmailSignInTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {
			SeleniumUtils.wait(5);
			HeaderFooterPage.clickSignInOrRegistration();
			SeleniumUtils.wait(5);
			LoginPage.clickCreateAccountLink();
			SeleniumUtils.wait(5);
			CreateAnAccountPage.clickCreateAccWithEmailButton();
			SeleniumUtils.wait(5);
			testcase.assertTrue(CreateAnAccountPage.isSignInLink(), "Sign In link is displayed",
					"Sign In link is not displayed");
			CreateAnAccountPage.clickSignInLinkCreateAcc();
			SeleniumUtils.wait(5);
			testcase.assertTrue(LoginPage.isSignInButton(),
					"Sign In button is displayed in create account with email page",
					"Sign In button is not displayed in create account with email page");
			testcase.pass("Display & Functionality of Sign In link in create account with email page");
		} catch (Exception e) {
			testcase.error("Display & Functionality of Sign In link in create account with email page", e);
			e.printStackTrace();
		}
	}

	// TA_REG_012
	// To verify the display of 'Setup Your Account' title & 'Log In' link in
	// 'Setup Your Account' page.
	@Test
	public void verfyTheCreateText() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(1);
		while (retry.retry()) {
			try {
				CommonUtils.getUrl();
				SeleniumUtils.wait(5);
				testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
						"Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				testcase.assertTrue(LoginPage.isCreateAccountLink(),
						"Create Account link is displayed in Sign In Flyout",
						"Create Account link is not displayed in Sign In Flyout");
				SeleniumUtils.wait(05);
				LoginPage.clickCreateAccountLink();
				SeleniumUtils.wait(5);
				CreateAnAccountPage.clickOnCreateAccountLink();
				SeleniumUtils.wait(04);
				HomePage.onHoverSiteLogo();
				SeleniumUtils.wait(5);
				String currentUrl1 = DriverFactory.getDriver().getCurrentUrl();
				boolean contains1 = currentUrl1.contains("registration");
				testcase.assertTrue(contains1, "Correct Navigation", "Incorrect Navigation");
				SeleniumUtils.wait(5);
				testcase.assertTrue(CreateAccWithEmailPage.isTitleStaticTextCreateAccount(), "Title is displayed",
						"Title is not displayed");
				testcase.pass("Create Account with eamil page is displayed with title as setup your account.");
				break;
			} catch (Exception e) {
				testcase.retry("Create Account with eamil page is displayed with title as setup your account.",
						testcase, retry, e);
				e.printStackTrace();
			}
		}
	}

	// TA_REG_013
	// To verify the display of 'SETUP YOUR ACCOUNT' section and 'CREATE AN
	// ACCOUNT' button in 'Setup Your Account' page.
	@Test
	public void setupYourAccSectionTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(1);
		while (retry.retry()) {
			try {
				CommonUtils.getUrl();
				SeleniumUtils.wait(5);
				testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
						"Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				testcase.assertTrue(LoginPage.isCreateAccountLink(),
						"Create Account link is displayed in Sign In Flyout",
						"Create Account link is not displayed in Sign In Flyout");
				SeleniumUtils.wait(05);
				LoginPage.clickCreateAccountLink();
				SeleniumUtils.wait(5);
				CreateAnAccountPage.clickOnCreateAccountLink();
				SeleniumUtils.wait(04);
				HomePage.onHoverSiteLogo();
				SeleniumUtils.wait(5);
				String currentUrl1 = DriverFactory.getDriver().getCurrentUrl();
				boolean contains1 = currentUrl1.contains("registration");
				testcase.assertTrue(contains1, "Correct Navigation", "Incorrect Navigation");
				SeleniumUtils.wait(5);
				testcase.assertTrue(CreateAccWithEmailPage.isTitleStaticTextCreateAccount(), "Title is displayed",
						"Title is not displayed");
				testcase.assertTrue(CreateAccWithEmailPage.isEmailAddressBox(), "Email Address textbox is displayed",
						"Email Address textbox is not displayed");
				testcase.assertTrue(CreateAccWithEmailPage.isCreatdConfmEmail(),
						"Confirm Email Address textbox is displayed", "Confirm Email Address textbox is not displayed");
				testcase.assertTrue(CreateAccWithEmailPage.isPasswordBox(), "Password textbox is displayed",
						"Password textbox is not displayed");
				testcase.assertTrue(CreateAccWithEmailPage.isConfirmPasswordBox(),
						"Confirm Password textbox is displayed", "Confirm Password textbox is not displayed");
				testcase.assertTrue(CreateAccWithEmailPage.isCreatdZipCode(), "Zipcode text box is displayed",
						"Zipcode text box is displayed");
				// testcase.assertTrue(CreateAccWithEmailPage.isSetUpUrSectiontext(),
				// "Setup your section static text displayed", "Setup your
				// section static text not displayed");
				testcase.assertTrue(CreateAccWithEmailPage.isCreateYourAccBtn(),
						"Create Your Account button is displayed", "Create Your Account button is not displayed");
				testcase.pass("Display of Setup your Account section in create account with email page");
				break;
			} catch (Exception e) {
				testcase.retry("Display of Setup your Account section in create account with email page", testcase,
						retry, e);
				e.printStackTrace();
			}
		}

	}

	// TA_REG_014
	// To verify the display and functionality of 'Tire America terms' link for
	// the 'I agree to Tire America terms' checkbox in 'Setup Your Account'
	// page.
	@Test
	public void termsNConditionsLinkTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(1);
		while (retry.retry()) {
			try {
				CommonUtils.getUrl();
				SeleniumUtils.wait(5);
				testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
						"Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				testcase.assertTrue(LoginPage.isCreateAccountLink(),
						"Create Account link is displayed in Sign In Flyout",
						"Create Account link is not displayed in Sign In Flyout");
				SeleniumUtils.wait(05);
				LoginPage.clickCreateAccountLink();
				SeleniumUtils.wait(5);
				CreateAnAccountPage.clickOnCreateAccountLink();
				SeleniumUtils.wait(04);
				HomePage.onHoverSiteLogo();
				SeleniumUtils.wait(5);
				String currentUrl1 = DriverFactory.getDriver().getCurrentUrl();
				boolean contains1 = currentUrl1.contains("registration");
				testcase.assertTrue(contains1, "Correct Navigation", "Incorrect Navigation");
				SeleniumUtils.wait(5);
				testcase.assertTrue(CreateAccWithEmailPage.isTitleStaticTextCreateAccount(), "Title is displayed",
						"Title is not displayed");
				CreateAccWithEmailPage.clickTermsNConditionsLink();
				SeleniumUtils.wait(5);
				testcase.assertTrue(CreateAccWithEmailPage.isTermsNConditionsLink(),
						"Terms and condition link was visiable.", "Terms and condition link was visiable.");
				testcase.pass("Functionality of Terms and Conditions link in create account with email page");
				break;
			} catch (Exception e) {
				testcase.retry("Functionality of Terms and Conditions link in create account with email page", testcase,
						retry, e);
				e.printStackTrace();
			}
		}
	}

	// TA_REG_015/TA_REG_017
	// To verify the display of 'Email Address' & 'Confirm Email Address' text
	// field placeholder in 'Setup Your Account' page.

	// To verify that the 'Email Address' & 'Confirm Email Address' placeholder
	// disappears when the text field is focused in 'Create an Account' page.
	@Test
	public void usernamePlaceholderFrEmailAndConfEmailAndDisap() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(1);
		while (retry.retry()) {
			try {

				CommonUtils.getUrl();
				SeleniumUtils.wait(5);
				testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
						"Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				testcase.assertTrue(LoginPage.isCreateAccountLink(),
						"Create Account link is displayed in Sign In Flyout",
						"Create Account link is not displayed in Sign In Flyout");
				SeleniumUtils.wait(05);
				LoginPage.clickCreateAccountLink();
				SeleniumUtils.wait(5);
				CreateAnAccountPage.clickOnCreateAccountLink();
				SeleniumUtils.wait(04);
				HomePage.onHoverSiteLogo();
				SeleniumUtils.wait(5);
				String currentUrl1 = DriverFactory.getDriver().getCurrentUrl();
				boolean contains1 = currentUrl1.contains("registration");
				testcase.assertTrue(contains1, "Correct Navigation", "Incorrect Navigation");
				SeleniumUtils.wait(5);
				testcase.assertEquals("Email Address",
						SeleniumUtils.getAttributes(
								ExcelProperty.getElementValue(CREATE_ACC_WITH_EMAIL_PAGE, EMAIL_ADDRESS_CREATE_ACC),
								"placeholder"));
				SeleniumUtils.wait(5);
				CreateAccWithEmailPage.enterEmailCreateAccEmail("Sathish@gmail.com");
				SeleniumUtils.wait(5);
				testcase.assertEquals("",
						SeleniumUtils.getAttributes(
								ExcelProperty.getElementValue(CREATE_ACC_WITH_EMAIL_PAGE, EMAIL_ADDRESS_CREATE_ACC),
								"placeholder"));

				testcase.assertEquals("Confirm Email Address", SeleniumUtils.getAttributes(
						ExcelProperty.getElementValue(CREATE_ACC_WITH_EMAIL_PAGE, CONF_EMAIL_ADDRESS_CREATE_ACC),
						"placeholder"));
				SeleniumUtils.wait(5);
				CreateAccWithEmailPage.enterConfEmailCreateAccEmail("Sathish@gmail.com");
				SeleniumUtils.wait(5);
				testcase.assertEquals("", SeleniumUtils.getAttributes(
						ExcelProperty.getElementValue(CREATE_ACC_WITH_EMAIL_PAGE, CONF_EMAIL_ADDRESS_CREATE_ACC),
						"placeholder"));
				testcase.pass("Display of placeholder before and after clicking on the Email Address textbox");
				break;
			} catch (Exception e) {
				testcase.retry("Display of placeholder before and after clicking on the Email Address textbox",
						testcase, retry, e);
				e.printStackTrace();
			}
		}
	}
	// TA_REG_016/TA_REG_018
	// To verify the display of 'Password' & 'Confirm Password' text fields
	// placeholder and the tip in 'Setup Your Account' page.

	// To verify that the 'Password & Confirm Password' placeholder disappears
	// when the text fields is focused in 'Create an Account' page.

	@Test
	public void passAndConfPassPlaceholderTestAndDisap() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(1);
		while (retry.retry()) {
			try {
				CommonUtils.getUrl();
				SeleniumUtils.wait(5);
				testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
						"Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				testcase.assertTrue(LoginPage.isCreateAccountLink(),
						"Create Account link is displayed in Sign In Flyout",
						"Create Account link is not displayed in Sign In Flyout");
				SeleniumUtils.wait(05);
				LoginPage.clickCreateAccountLink();
				SeleniumUtils.wait(5);
				CreateAnAccountPage.clickOnCreateAccountLink();
				SeleniumUtils.wait(04);
				HomePage.onHoverSiteLogo();
				SeleniumUtils.wait(5);
				String currentUrl1 = DriverFactory.getDriver().getCurrentUrl();
				boolean contains1 = currentUrl1.contains("registration");
				testcase.assertTrue(contains1, "Correct Navigation", "Incorrect Navigation");
				SeleniumUtils.wait(5);
				testcase.assertEquals("Password", SeleniumUtils.getAttributes(
						ExcelProperty.getElementValue(CREATE_ACC_WITH_EMAIL_PAGE, PASSWORD_CREATE_ACC), "placeholder"));
				SeleniumUtils.wait(5);
				CreateAccWithEmailPage.enterPwdCreateAccEmail("date@123");
				SeleniumUtils.wait(5);
				testcase.assertEquals("", SeleniumUtils.getAttributes(
						ExcelProperty.getElementValue(CREATE_ACC_WITH_EMAIL_PAGE, PASSWORD_CREATE_ACC), "placeholder"));
				SeleniumUtils.wait(5);
				testcase.assertEquals("Confirm Password",
						SeleniumUtils.getAttributes(
								ExcelProperty.getElementValue(CREATE_ACC_WITH_EMAIL_PAGE, CONFIRM_PASSWORD_CREATE_ACC),
								"placeholder"));
				SeleniumUtils.wait(5);
				CreateAccWithEmailPage.enterConPwdCreateAccEmail("date@123");
				SeleniumUtils.wait(5);
				testcase.assertEquals("",
						SeleniumUtils.getAttributes(
								ExcelProperty.getElementValue(CREATE_ACC_WITH_EMAIL_PAGE, CONFIRM_PASSWORD_CREATE_ACC),
								"placeholder"));
				testcase.pass("Display of placeholder before and after clicking on the Password textbox");
				break;
			} catch (Exception e) {
				testcase.retry("Display of placeholder before and after clicking on the Password textbox", testcase,
						retry, e);
				e.printStackTrace();
			}
		}
	}

	// TA_REG_019
	// To verify that the guest user is able to create account with only
	// mandatory fields in 'Create Account with Email' page.
	@Test
	public void createAccMandatoryFieldsTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(1);
		while (retry.retry()) {
			try {
				CommonUtils.getUrl();
				SeleniumUtils.wait(5);
				testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
						"Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				testcase.assertTrue(LoginPage.isCreateAccountLink(),
						"Create Account link is displayed in Sign In Flyout",
						"Create Account link is not displayed in Sign In Flyout");
				SeleniumUtils.wait(05);
				LoginPage.clickCreateAccountLink();
				SeleniumUtils.wait(5);
				CreateAnAccountPage.clickOnCreateAccountLink();
				SeleniumUtils.wait(04);
				HomePage.onHoverSiteLogo();
				SeleniumUtils.wait(5);
				String currentUrl1 = DriverFactory.getDriver().getCurrentUrl();
				boolean contains1 = currentUrl1.contains("registration");
				testcase.assertTrue(contains1, "Correct Navigation", "Incorrect Navigation");
				SeleniumUtils.wait(10);
				CreateAccWithEmailPage.enterEmailCreateAccEmail("test@gmail.com");
				CreateAccWithEmailPage.enterConfEmailCreateAccEmail("test@gmail.com");
				CreateAccWithEmailPage.enterPwdCreateAccEmail("Test@123");
				CreateAccWithEmailPage.enterConPwdCreateAccEmail("Test@123");
				CreateAccWithEmailPage.enterZipcodeAccEmail("99501");
				SeleniumUtils.wait(5);
				CreateAccWithEmailPage.clickAgreeTermsNConditions();
				SeleniumUtils.wait(15);
				try {
					CreateAccWithEmailPage.clickCreateYourAccBtn();
				} catch (Exception e) {
					SeleniumUtils.wait(04);
					CreateAccWithEmailPage.clickCreateYourAccBtn();
				}
				SeleniumUtils.wait(30);
				testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
						"User has has not logged In");
				testcase.pass("Account creation with mandatory fields in create account with email page");
				break;
			} catch (Exception e) {
				testcase.retry("Account creation with mandatory fields in create account with email page", testcase,
						retry, e);
				e.printStackTrace();
			}
		}
	}

	// TA_REG_021
	// To verify the functionality of 'SHOW' button in password field in 'Setup
	// Your Account' page.
	@Test
	public void showButtonInPwd() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(1);
		while (retry.retry()) {
			try {
				CommonUtils.getUrl();
				SeleniumUtils.wait(5);
				testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
						"Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				testcase.assertTrue(LoginPage.isCreateAccountLink(),
						"Create Account link is displayed in Sign In Flyout",
						"Create Account link is not displayed in Sign In Flyout");
				SeleniumUtils.wait(05);
				LoginPage.clickCreateAccountLink();
				SeleniumUtils.wait(5);
				CreateAnAccountPage.clickOnCreateAccountLink();
				SeleniumUtils.wait(04);
				HomePage.onHoverSiteLogo();
				SeleniumUtils.wait(5);
				String currentUrl1 = DriverFactory.getDriver().getCurrentUrl();
				boolean contains1 = currentUrl1.contains("registration");
				testcase.assertTrue(contains1, "Correct Navigation", "Incorrect Navigation");
				SeleniumUtils.wait(10);
				CreateAccWithEmailPage.enterEmailCreateAccEmail("test@gmail.com");
				SeleniumUtils.wait(5);
				CreateAccWithEmailPage.enterPwdCreateAccEmail("Test@123");
				SeleniumUtils.wait(5);
				CreateAccWithEmailPage.clickShowPwdButton();
				SeleniumUtils.wait(5);
				testcase.assertTrue(CreateAccWithEmailPage.showLinkInCreateFrPass(), "System is showing show password.",
						"System is showing show password.");
				testcase.pass("Functionality of SHOW button in password field in create account with email page");
				break;
			} catch (Exception e) {
				testcase.retry("Functionality of SHOW button in password field in create account with email page",
						testcase, retry, e);
				e.printStackTrace();
			}
		}
	}

	// TA_REG_022
	// To verify the functionality of 'HIDE' button in password field in 'Setup
	// Your Account' page.
	@Test
	public void hideButtonInPwd() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(1);
		while (retry.retry()) {
			try {
				CommonUtils.getUrl();
				SeleniumUtils.wait(5);
				testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
						"Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				testcase.assertTrue(LoginPage.isCreateAccountLink(),
						"Create Account link is displayed in Sign In Flyout",
						"Create Account link is not displayed in Sign In Flyout");
				SeleniumUtils.wait(05);
				LoginPage.clickCreateAccountLink();
				SeleniumUtils.wait(5);
				CreateAnAccountPage.clickOnCreateAccountLink();
				SeleniumUtils.wait(04);
				HomePage.onHoverSiteLogo();
				SeleniumUtils.wait(5);
				String currentUrl1 = DriverFactory.getDriver().getCurrentUrl();
				boolean contains1 = currentUrl1.contains("registration");
				testcase.assertTrue(contains1, "Correct Navigation", "Incorrect Navigation");
				SeleniumUtils.wait(10);
				CreateAccWithEmailPage.enterEmailCreateAccEmail("test@gmail.com");
				SeleniumUtils.wait(5);
				CreateAccWithEmailPage.enterPwdCreateAccEmail("Test@123");
				SeleniumUtils.wait(5);
				CreateAccWithEmailPage.clickShowPwdButton();
				SeleniumUtils.wait(5);
				CreateAccWithEmailPage.clickHidePwdButton();
				SeleniumUtils.wait(5);
				testcase.assertTrue(CreateAccWithEmailPage.hideLinkInCreateFrPass(), "System is showing show password.",
						"System is showing show password.");
				testcase.pass("Functionality of HIDE button in password field in create account with email page");
				break;
			} catch (Exception e) {
				testcase.retry("Functionality of HIDE button in password field in create account with email page",
						testcase, retry, e);
				e.printStackTrace();
			}
		}
	}

	// TA_REG_023
	// To verify the display of error messages when the mandatory fields are
	// left blank while creating account in 'Create Account with Email' page.
	@Test
	public void vrfyErrMsgForMandatorFrCreatAcc() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(1);
		while (retry.retry()) {
			try {
				CommonUtils.getUrl();
				SeleniumUtils.wait(5);
				testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
						"Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				testcase.assertTrue(LoginPage.isCreateAccountLink(),
						"Create Account link is displayed in Sign In Flyout",
						"Create Account link is not displayed in Sign In Flyout");
				SeleniumUtils.wait(05);
				LoginPage.clickCreateAccountLink();
				SeleniumUtils.wait(5);
				CreateAnAccountPage.clickOnCreateAccountLink();
				SeleniumUtils.wait(04);
				HomePage.onHoverSiteLogo();
				SeleniumUtils.wait(5);
				String currentUrl1 = DriverFactory.getDriver().getCurrentUrl();
				boolean contains1 = currentUrl1.contains("registration");
				testcase.assertTrue(contains1, "Correct Navigation", "Incorrect Navigation");
				CreateAccWithEmailPage.clickCreateYourAccBtn();
				SeleniumUtils.wait(5);
				testcase.assertEquals(SeleniumUtils.getText(
						ExcelProperty.getElementValue(CREATE_ACC_WITH_EMAIL_PAGE, EMAIL_ADDRESS_CREATE_ACC_ERR_MSG)),
						"Please enter your email address");
				testcase.assertEquals(SeleniumUtils.getText(ExcelProperty.getElementValue(CREATE_ACC_WITH_EMAIL_PAGE,
						CONF_EMAIL_ADDRESS_CREATE_ACC_ERR_MSG)), "Please enter your email address");
				testcase.assertEquals(
						SeleniumUtils.getText(
								ExcelProperty.getElementValue(CREATE_ACC_WITH_EMAIL_PAGE, PASSWORD_CREATE_ACC_ERR_MSG)),
						"Please confirm your password");
				testcase.assertEquals(SeleniumUtils.getText(
						ExcelProperty.getElementValue(CREATE_ACC_WITH_EMAIL_PAGE, CONFIRM_PASSWORD_CREATE_ACC_ERR_MSG)),
						"Please confirm your password");
				testcase.assertEquals(
						SeleniumUtils.getText(
								ExcelProperty.getElementValue(CREATE_ACC_WITH_EMAIL_PAGE, TERMS_N_COND_LINK_ERR_MSG)),
						"Please accept the Tire America Terms");
				testcase.pass("Error message for Account creation with blank fields in create account with email page");
				break;
			} catch (Exception e) {
				testcase.retry("Error message for Account creation with blank fields in create account with email page",
						testcase, retry, e);
				e.printStackTrace();
			}
		}
	}

	// TA_REG_024
	// To verify the display of error message when already existing email
	// address is entered in 'Create Account with Email' page.
	@Test
	public void alreadyRegisteredCreateAccError() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(1);
		while (retry.retry()) {
			try {
				CommonUtils.getUrl();
				SeleniumUtils.wait(5);
				testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
						"Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				testcase.assertTrue(LoginPage.isCreateAccountLink(),
						"Create Account link is displayed in Sign In Flyout",
						"Create Account link is not displayed in Sign In Flyout");
				SeleniumUtils.wait(05);
				LoginPage.clickCreateAccountLink();
				SeleniumUtils.wait(5);
				CreateAnAccountPage.clickOnCreateAccountLink();
				SeleniumUtils.wait(04);
				HomePage.onHoverSiteLogo();
				SeleniumUtils.wait(5);
				String currentUrl1 = DriverFactory.getDriver().getCurrentUrl();
				boolean contains1 = currentUrl1.contains("registration");
				testcase.assertTrue(contains1, "Correct Navigation", "Incorrect Navigation");
				SeleniumUtils.wait(10);
				CreateAccWithEmailPage.enterEmailCreateAccEmail("test@gmail.com");
				CreateAccWithEmailPage.enterConfEmailCreateAccEmail("test@gmail.com");
				CreateAccWithEmailPage.enterPwdCreateAccEmail("Test@123");
				CreateAccWithEmailPage.enterConPwdCreateAccEmail("Test@123");
				CreateAccWithEmailPage.enterZipcodeAccEmail("99501");
				SeleniumUtils.wait(5);
				CreateAccWithEmailPage.clickAgreeTermsNConditions();
				SeleniumUtils.wait(15);
				try {
					CreateAccWithEmailPage.clickCreateYourAccBtn();
				} catch (Exception e) {
					SeleniumUtils.wait(04);
					CreateAccWithEmailPage.clickCreateYourAccBtn();
				}
				SeleniumUtils.wait(04);
				testcase.assertEquals(
						SeleniumUtils.getText(
								ExcelProperty.getElementValue(CREATE_ACC_WITH_EMAIL_PAGE, EXIST_EMAIL_ERROR_MSG)),
						"error_existed_email");
				testcase.pass(
						"Error message for Account creation with already registered email address in create account with email page");
				break;
			} catch (Exception e) {
				testcase.retry(
						"Error message for Account creation with already registered email address in create account with email page",
						testcase, retry, e);
				e.printStackTrace();
			}
		}
	}

	// TA_REG_025
	// To verify the display of error message when user enters invalid email
	// address in 'Email Address' text field in 'Setup Your Account' page.
	@Test
	public void invalidEmailCreateAccError() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(1);
		while (retry.retry()) {
			try {
				CommonUtils.getUrl();
				SeleniumUtils.wait(5);
				testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
						"Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				testcase.assertTrue(LoginPage.isCreateAccountLink(),
						"Create Account link is displayed in Sign In Flyout",
						"Create Account link is not displayed in Sign In Flyout");
				SeleniumUtils.wait(05);
				LoginPage.clickCreateAccountLink();
				SeleniumUtils.wait(5);
				CreateAnAccountPage.clickOnCreateAccountLink();
				SeleniumUtils.wait(04);
				HomePage.onHoverSiteLogo();
				SeleniumUtils.wait(5);
				String currentUrl1 = DriverFactory.getDriver().getCurrentUrl();
				boolean contains1 = currentUrl1.contains("registration");
				testcase.assertTrue(contains1, "Correct Navigation", "Incorrect Navigation");
				SeleniumUtils.wait(10);
				CreateAccWithEmailPage.enterEmailCreateAccEmail("test.com");
				CreateAccWithEmailPage.enterConfEmailCreateAccEmail("test@gmail.com");
				CreateAccWithEmailPage.enterPwdCreateAccEmail("Test@123");
				CreateAccWithEmailPage.enterConPwdCreateAccEmail("Test@123");
				CreateAccWithEmailPage.enterZipcodeAccEmail("99501");
				SeleniumUtils.wait(5);
				CreateAccWithEmailPage.clickAgreeTermsNConditions();
				SeleniumUtils.wait(03);
				try {
					CreateAccWithEmailPage.clickCreateYourAccBtn();
				} catch (Exception e) {
					SeleniumUtils.wait(04);
					CreateAccWithEmailPage.clickCreateYourAccBtn();
				}
				SeleniumUtils.wait(04);
				testcase.assertEquals(SeleniumUtils.getText(
						ExcelProperty.getElementValue(CREATE_ACC_WITH_EMAIL_PAGE, EMAIL_ADDRESS_CREATE_ACC_ERR_MSG)),
						"");
				// Error message assertions to be added
				testcase.pass(
						"Error message for Account creation with invalid email address in create account with email page");
				break;
			} catch (Exception e) {
				testcase.retry(
						"Error message for Account creation with invalid email address in create account with email page",
						testcase, retry, e);
				e.printStackTrace();
			}
		}
	}

	// TA_REG_026
	// To verify the display of error message when user does not accept Tire
	// America terms while creating account in 'Setup Your Account' page.
	@Test
	public void unselectTermsCondCreateAccError() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(1);
		while (retry.retry()) {
			try {
				CommonUtils.getUrl();
				SeleniumUtils.wait(5);
				testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
						"Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				testcase.assertTrue(LoginPage.isCreateAccountLink(),
						"Create Account link is displayed in Sign In Flyout",
						"Create Account link is not displayed in Sign In Flyout");
				SeleniumUtils.wait(05);
				LoginPage.clickCreateAccountLink();
				SeleniumUtils.wait(5);
				CreateAnAccountPage.clickOnCreateAccountLink();
				SeleniumUtils.wait(04);
				HomePage.onHoverSiteLogo();
				SeleniumUtils.wait(5);
				String currentUrl1 = DriverFactory.getDriver().getCurrentUrl();
				boolean contains1 = currentUrl1.contains("registration");
				testcase.assertTrue(contains1, "Correct Navigation", "Incorrect Navigation");
				SeleniumUtils.wait(10);
				CreateAccWithEmailPage.enterEmailCreateAccEmail("test.com");
				CreateAccWithEmailPage.enterConfEmailCreateAccEmail("test@gmail.com");
				CreateAccWithEmailPage.enterPwdCreateAccEmail("Test@123");
				CreateAccWithEmailPage.enterConPwdCreateAccEmail("Test@123");
				CreateAccWithEmailPage.enterZipcodeAccEmail("99501");
				SeleniumUtils.wait(5);
				try {
					CreateAccWithEmailPage.clickCreateYourAccBtn();
				} catch (Exception e) {
					SeleniumUtils.wait(04);
					CreateAccWithEmailPage.clickCreateYourAccBtn();
				}
				SeleniumUtils.wait(04);
				// Error message assertions to be added
				testcase.assertEquals(
						SeleniumUtils.getText(
								ExcelProperty.getElementValue(CREATE_ACC_WITH_EMAIL_PAGE, TERMS_N_COND_LINK_ERR_MSG)),
						"Please accept the Tire America Terms");
				testcase.pass(
						"Error message for Account creation with unselected Terms and conditions check box in create account with email page");
				break;
			} catch (Exception e) {
				testcase.retry(
						"Error message for Account creation with unselected Terms and conditions check box in create account with email page",
						testcase, retry, e);
				e.printStackTrace();
			}
		}
	}

	// TA_REG_027
	// To verify the display of error message when user enters two different
	// email addresses in 'Email Address' & 'Confirm Email Address' text box
	// while creating account in 'Setup Your Account' page.
	@Test
	public void vrfyErrMsgFrTwoDiffEmailInCreatAcc() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(1);
		while (retry.retry()) {
			try {
				CommonUtils.getUrl();
				SeleniumUtils.wait(5);
				testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
						"Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				testcase.assertTrue(LoginPage.isCreateAccountLink(),
						"Create Account link is displayed in Sign In Flyout",
						"Create Account link is not displayed in Sign In Flyout");
				SeleniumUtils.wait(05);
				LoginPage.clickCreateAccountLink();
				SeleniumUtils.wait(5);
				CreateAnAccountPage.clickOnCreateAccountLink();
				SeleniumUtils.wait(04);
				HomePage.onHoverSiteLogo();
				SeleniumUtils.wait(5);
				String currentUrl1 = DriverFactory.getDriver().getCurrentUrl();
				boolean contains1 = currentUrl1.contains("registration");
				testcase.assertTrue(contains1, "Correct Navigation", "Incorrect Navigation");
				SeleniumUtils.wait(10);
				CreateAccWithEmailPage.enterEmailCreateAccEmail("test@gmail.com");
				CreateAccWithEmailPage.enterConfEmailCreateAccEmail("tes@gmail.com");
				CreateAccWithEmailPage.enterPwdCreateAccEmail("Test@123");
				CreateAccWithEmailPage.enterConPwdCreateAccEmail("Test@123");
				CreateAccWithEmailPage.enterZipcodeAccEmail("99501");
				SeleniumUtils.wait(5);
				CreateAccWithEmailPage.clickAgreeTermsNConditions();
				SeleniumUtils.wait(03);
				try {
					CreateAccWithEmailPage.clickCreateYourAccBtn();
				} catch (Exception e) {
					SeleniumUtils.wait(04);
					CreateAccWithEmailPage.clickCreateYourAccBtn();
				}
				SeleniumUtils.wait(04);
				// Error message assertions to be added
				testcase.assertEquals(SeleniumUtils.getText(ExcelProperty.getElementValue("", "")), "");
				testcase.pass("Vrfy the error message for the two different email ID for create account.");
				break;
			} catch (Exception e) {
				testcase.retry("Vrfy the error message for the two different email ID for create account.", testcase,
						retry, e);
				e.printStackTrace();
			}
		}
	}

	// TA_REG_028
	// To verify the display of error message when user enters two different
	// passwords in 'Password' & 'Confirm Password' text box while creating
	// account in 'Setup Your Account' page.

	@Test
	public void vrfyErrMsgFrTwoDiffPasswrdInCreatAcc() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(1);
		while (retry.retry()) {
			try {
				CommonUtils.getUrl();
				SeleniumUtils.wait(5);
				testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
						"Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				testcase.assertTrue(LoginPage.isCreateAccountLink(),
						"Create Account link is displayed in Sign In Flyout",
						"Create Account link is not displayed in Sign In Flyout");
				SeleniumUtils.wait(05);
				LoginPage.clickCreateAccountLink();
				SeleniumUtils.wait(5);
				CreateAnAccountPage.clickOnCreateAccountLink();
				SeleniumUtils.wait(04);
				HomePage.onHoverSiteLogo();
				SeleniumUtils.wait(5);
				String currentUrl1 = DriverFactory.getDriver().getCurrentUrl();
				boolean contains1 = currentUrl1.contains("registration");
				testcase.assertTrue(contains1, "Correct Navigation", "Incorrect Navigation");
				SeleniumUtils.wait(10);
				CreateAccWithEmailPage.enterEmailCreateAccEmail("test@gmail.com");
				CreateAccWithEmailPage.enterConfEmailCreateAccEmail("test@gmail.com");
				CreateAccWithEmailPage.enterPwdCreateAccEmail("Test@123");
				CreateAccWithEmailPage.enterConPwdCreateAccEmail("Test@12");
				CreateAccWithEmailPage.enterZipcodeAccEmail("99501");
				SeleniumUtils.wait(5);
				CreateAccWithEmailPage.clickAgreeTermsNConditions();
				SeleniumUtils.wait(03);
				try {
					CreateAccWithEmailPage.clickCreateYourAccBtn();
				} catch (Exception e) {
					SeleniumUtils.wait(04);
					CreateAccWithEmailPage.clickCreateYourAccBtn();
				}
				SeleniumUtils.wait(04);
				// Error message assertions to be added
				testcase.assertEquals(SeleniumUtils.getText(ExcelProperty.getElementValue("", "")), "");
				testcase.pass("Vrfy the error message for the two different Password for create account.");
				break;
			} catch (Exception e) {
				testcase.retry("Vrfy the error message for the two different Password for create account.", testcase,
						retry, e);
				e.printStackTrace();
			}
		}
	}

	// TA_REG_029
	// To verify the display of error message when user enters invalid password
	// in 'Password' text box while creating account in 'Setup Your Account'
	// page.

	@Test
	public void vry() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(1);
		while (retry.retry()) {
			try {
				CommonUtils.getUrl();
				SeleniumUtils.wait(5);
				testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
						"Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				testcase.assertTrue(LoginPage.isCreateAccountLink(),
						"Create Account link is displayed in Sign In Flyout",
						"Create Account link is not displayed in Sign In Flyout");
				SeleniumUtils.wait(05);
				LoginPage.clickCreateAccountLink();
				SeleniumUtils.wait(5);
				CreateAnAccountPage.clickOnCreateAccountLink();
				SeleniumUtils.wait(04);
				HomePage.onHoverSiteLogo();
				SeleniumUtils.wait(5);
				String currentUrl1 = DriverFactory.getDriver().getCurrentUrl();
				boolean contains1 = currentUrl1.contains("registration");
				testcase.assertTrue(contains1, "Correct Navigation", "Incorrect Navigation");
				SeleniumUtils.wait(10);
				CreateAccWithEmailPage.enterEmailCreateAccEmail("test@gmail.com");
				CreateAccWithEmailPage.enterConfEmailCreateAccEmail("test@gmail.com");
				CreateAccWithEmailPage.enterPwdCreateAccEmail("Test@123");
				CreateAccWithEmailPage.enterConPwdCreateAccEmail("Test@12");
				CreateAccWithEmailPage.enterZipcodeAccEmail("99501");
				SeleniumUtils.wait(5);
				CreateAccWithEmailPage.clickAgreeTermsNConditions();
				SeleniumUtils.wait(03);
				try {
					CreateAccWithEmailPage.clickCreateYourAccBtn();
				} catch (Exception e) {
					SeleniumUtils.wait(04);
					CreateAccWithEmailPage.clickCreateYourAccBtn();
				}
				SeleniumUtils.wait(04);
				// Error message assertions to be added
				testcase.assertEquals(SeleniumUtils.getText(ExcelProperty.getElementValue("", "")), "");
				testcase.pass("Vrfy the error message for the two different Password for create account.");
				break;
			} catch (Exception e) {
				testcase.retry("Vrfy the error message for the two different Password for create account.", testcase,
						retry, e);
				e.printStackTrace();
			}
		}
	}

	// To verify the display of 'TELL US ABOUT YOURSELF' section in 'Create
	// Account with Email' page.
	// @Test
	public void tellUsAboutUrselfSectionTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {
			SeleniumUtils.wait(5);
			HeaderFooterPage.clickSignInOrRegistration();
			SeleniumUtils.wait(5);
			LoginPage.clickCreateAccountLink();
			SeleniumUtils.wait(5);
			CreateAnAccountPage.clickCreateAccWithEmailButton();
			SeleniumUtils.wait(5);
			testcase.assertTrue(CreateAccWithEmailPage.isTellUsAbtSectionStaticText(), "Static text displayed",
					"static text not displayed");
			testcase.assertTrue(CreateAccWithEmailPage.isTellUsAbtSectionFields(), "Fields are displayed",
					"Fields are not displayed");
			testcase.pass(
					"Tell Us About Yourself section is displayed with title and static text with Fields in create account with email page");
		} catch (Exception e) {
			testcase.error(
					"Tell Us About Yourself section is displayed with title and static text with Fields in create account with email page",
					e);
			e.printStackTrace();
		}
	}

	// To verify that the user is able to create account by entering first name
	// & last name in 'Create an Account' page.
	// @Test
	public void createAccWithOptFieldsTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {
			SeleniumUtils.wait(5);
			HeaderFooterPage.clickSignInOrRegistration();
			SeleniumUtils.wait(5);
			LoginPage.clickCreateAccountLink();
			SeleniumUtils.wait(5);
			CreateAnAccountPage.clickCreateAccWithEmailButton();
			SeleniumUtils.wait(5);
			CreateAccWithEmailPage.enterEmailCreateAccEmail("test@gmail.com");
			SeleniumUtils.wait(5);
			CreateAccWithEmailPage.enterPwdCreateAccEmail("Test@123");
			SeleniumUtils.wait(5);
			CreateAccWithEmailPage.enterConPwdCreateAccEmail("Test@123");
			SeleniumUtils.wait(5);
			CreateAccWithEmailPage.enterFirstName("test");
			SeleniumUtils.wait(5);
			CreateAccWithEmailPage.enterLastName("testing");
			SeleniumUtils.wait(5);
			CreateAccWithEmailPage.clickAgreeTermsNConditions();
			SeleniumUtils.wait(5);
			CreateAccWithEmailPage.clickCreateYourAccBtn();
			SeleniumUtils.wait(5);
			testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
					"User has has not logged In");
			testcase.pass("Account creation with optional fields in create account with email page");
		} catch (Exception e) {
			testcase.error("Account creation with optional fields in create account with email page", e);
			e.printStackTrace();
		}
	}

	// To verify that the user is able to create account by adding address in
	// 'Create Account with Email' page.
	// @Test
	public void createAccWithAddressFieldsTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {
			SeleniumUtils.wait(5);
			HeaderFooterPage.clickSignInOrRegistration();
			SeleniumUtils.wait(5);
			LoginPage.clickCreateAccountLink();
			SeleniumUtils.wait(5);
			CreateAnAccountPage.clickCreateAccWithEmailButton();
			SeleniumUtils.wait(5);
			ArrayList<User> data = FileUtility.readAllUserData();
			for (Iterator<User> iterator = data.iterator(); iterator.hasNext();) {
				User user = iterator.next();
				SeleniumUtils.sendKeys(ExcelProperty.getElementValue(CREATE_ACC_WITH_EMAIL, EMAIL_ADDRESS_CREATE_ACC),
						user.getEmail());
				SeleniumUtils.sendKeys(ExcelProperty.getElementValue(CREATE_ACC_WITH_EMAIL, PASSWORD_CREATE_ACC),
						user.getPassword());
				SeleniumUtils.sendKeys(
						ExcelProperty.getElementValue(CREATE_ACC_WITH_EMAIL, CONFIRM_PASSWORD_CREATE_ACC),
						user.getConfirmPassword());
				SeleniumUtils.sendKeys(ExcelProperty.getElementValue(CREATE_ACC_WITH_EMAIL, FIRST_NAME),
						user.getFirstName());
				SeleniumUtils.sendKeys(ExcelProperty.getElementValue(CREATE_ACC_WITH_EMAIL, LAST_NAME),
						user.getLastName());
				SeleniumUtils.sendKeys(ExcelProperty.getElementValue(CREATE_ACC_WITH_EMAIL, ADDRESS_LINE1),
						user.getAddress());
				SeleniumUtils.sendKeys(ExcelProperty.getElementValue(CREATE_ACC_WITH_EMAIL, ADDRESS_LINE2),
						user.getContinuedAddress());
				SeleniumUtils.sendKeys(ExcelProperty.getElementValue(CREATE_ACC_WITH_EMAIL, CITY), user.getCity());
				SeleniumUtils.sendKeys(ExcelProperty.getElementValue(CREATE_ACC_WITH_EMAIL, STATE),
						user.getState() + Keys.ENTER);
				SeleniumUtils.sendKeys(ExcelProperty.getElementValue(CREATE_ACC_WITH_EMAIL, ZIPCODE),
						user.getZipCode());
				SeleniumUtils.sendKeys(ExcelProperty.getElementValue(CREATE_ACC_WITH_EMAIL, PHONE_NUM),
						user.getPrimaryPhone());
				SeleniumUtils.sendKeys(ExcelProperty.getElementValue(CREATE_ACC_WITH_EMAIL, ALT_PHONE_NUM),
						user.getAlternatePhone());
			}
			SeleniumUtils.wait(5);
			CreateAccWithEmailPage.clickAgreeTermsNConditions();
			SeleniumUtils.wait(5);
			CreateAccWithEmailPage.clickCreateYourAccBtn();
			SeleniumUtils.wait(5);
			testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
					"User has has not logged In");
			testcase.pass("Account creation with all optional fields in create account with email page");
		} catch (Exception e) {
			testcase.error("Account creation with all optional fields in create account with email page", e);
			e.printStackTrace();
		}
	}

	// To verify the display of 'KEEP IN CONTACT' section in 'Create Account
	// with Email' page.
	// To verify that the user is able to create account by subscribing to
	// special offers in 'Create Account with Email' page.
	// To verify that the user is able to navigate to 'My Account' page.
	// @Test
	public void createAccWithEmailSubscribeTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {
			SeleniumUtils.wait(5);
			HeaderFooterPage.clickSignInOrRegistration();
			SeleniumUtils.wait(5);
			LoginPage.clickCreateAccountLink();
			SeleniumUtils.wait(5);
			CreateAnAccountPage.clickCreateAccWithEmailButton();
			SeleniumUtils.wait(5);
			CreateAccWithEmailPage.enterEmailCreateAccEmail("test@gmail.com");
			SeleniumUtils.wait(5);
			CreateAccWithEmailPage.enterPwdCreateAccEmail("Test@123");
			SeleniumUtils.wait(5);
			CreateAccWithEmailPage.enterConPwdCreateAccEmail("Test@123");
			SeleniumUtils.wait(5);
			CreateAccWithEmailPage.enterFirstName("test");
			SeleniumUtils.wait(5);
			CreateAccWithEmailPage.enterLastName("testing");
			SeleniumUtils.wait(5);
			CreateAccWithEmailPage.clickAgreeTermsNConditions();
			SeleniumUtils.wait(5);
			testcase.assertTrue(CreateAccWithEmailPage.isKeepInContactLink(), "Keep in touch check box displayed",
					"Keep in touch check box not displayed");
			CreateAccWithEmailPage.clickKeepInContactLink();
			SeleniumUtils.wait(5);
			CreateAccWithEmailPage.clickCreateYourAccBtn();
			SeleniumUtils.wait(5);
			testcase.assertTrue(MyAccountPage.isMyAccountLink(), "User has successfully logged In",
					"User has has not logged In");
			testcase.pass(
					"Account creation with optional fields and subscribed to mails in create account with email page");
		} catch (Exception e) {
			testcase.error(
					"Account creation with optional fields and subscribed to mails in create account with email page",
					e);
			e.printStackTrace();
		}
	}

}
