package com.ch.ta.desktopTests;

import java.util.Iterator;
import java.util.Set;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ch.report.utils.AbstractTestCaseReport;
import com.ch.reports.TestCaseDetail;
import com.ch.reports.TestCaseFactory;
import com.ch.retry.Retry;
import com.ch.ta.desktopPages.CreateAccWithEmailPage;
import com.ch.ta.desktopPages.CreateAnAccountPage;
import com.ch.ta.desktopPages.HeaderFooterPage;
import com.ch.ta.desktopPages.HomePage;
import com.ch.ta.desktopPages.LoginPage;
import com.ch.ta.utils.CommonUtils;
import com.ch.ta.utils.constants.FileConstants;
import com.ch.utils.DriverFactory;
import com.ch.utils.SeleniumUtils;

@Listeners(com.ch.utils.ParallelFactory.class)
public class CreateAnAccountTest extends AbstractTestCaseReport implements FileConstants {

	// To verify the display and functionality of 'Create an Account' link in
	// 'Login' page.
	@Test
	public void createAccountLinkTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(1);
		while (retry.retry()) {
			try {
				CommonUtils.getUrl();
				SeleniumUtils.wait(5);
				testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
						"Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				testcase.assertTrue(LoginPage.isCreateAccountLink(),
						"Create Account link is displayed in Sign In Flyout",
						"Create Account link is not displayed in Sign In Flyout");
				SeleniumUtils.wait(05);
				LoginPage.clickCreateAccountLink();
				SeleniumUtils.wait(5);
				CreateAnAccountPage.clickOnCreateAccountLink();
				SeleniumUtils.wait(04);
				HomePage.onHoverSiteLogo();
				SeleniumUtils.wait(5);
				String currentUrl1 = DriverFactory.getDriver().getCurrentUrl();
				boolean contains1 = currentUrl1.contains("registration");
				testcase.assertTrue(contains1, "Correct Navigation", "Incorrect Navigation");
				testcase.pass("Create Account page is displayed on clicking create Account link in SignIn flyout");
				break;
			} catch (Exception e) {
				testcase.retry("Create Account page is displayed on clicking create Account link in SignIn flyout",
						testcase, retry, e);

				e.printStackTrace();
			}
		}
	}

	// To verify the display of site logo, 'Create an Account' title & static
	// text in 'Create an Account' page.
	@Test
	public void createAccountLogoTextTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		Retry retry = new Retry(1);
		while (retry.retry()) {
			try {
				CommonUtils.getUrl();
				SeleniumUtils.wait(5);
				HeaderFooterPage.clickSignInOrRegistration();
				SeleniumUtils.wait(5);
				LoginPage.clickCreateAccountLink();
				SeleniumUtils.wait(5);
				testcase.assertTrue(CreateAnAccountPage.isSiteLogoCreateAccount(), "Site Logo is displayed",
						"Site Logo is not displayed");
				testcase.assertTrue(CreateAnAccountPage.isTitleStaticTextCreateAccount(),
						"Title & Static text is displayed", "Title & Static text is not displayed");
				testcase.pass("Create Account page is displayed with site logo, title and static text");
				break;
			} catch (Exception e) {
				testcase.retry("Create Account page is displayed with site logo, title and static text", testcase,
						retry, e);

				e.printStackTrace();
			}
		}
	}

	// To verify the display and functionality of 'Log In' link in 'Create an
	// Account' page.
	@Test
	public void createAccountSignInTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {
			CommonUtils.getUrl();
			SeleniumUtils.wait(5);
			HeaderFooterPage.clickSignInOrRegistration();
			SeleniumUtils.wait(5);
			LoginPage.clickCreateAccountLink();
			SeleniumUtils.wait(5);
			testcase.assertTrue(CreateAnAccountPage.isSignInLink(), "Sign In link is displayed",
					"Sign In link is not displayed");
			CreateAnAccountPage.clickSignInLinkCreateAcc();
			SeleniumUtils.wait(5);
			testcase.assertTrue(LoginPage.isSignInButton(), "Sign In button is displayed in Create account page",
					"Sign In button is not displayed in Create account page");
			testcase.pass("Display & Functionality of Sign In link in Create Account page");
		} catch (Exception e) {
			testcase.error("Display & Functionality of Sign In link in Create Account page", e);
			e.printStackTrace();
		}
	}

	// To verify the display of 'Create Account with Email' button & social
	// media links in 'Create an Account' page.
	@Test
	public void createAccountUITest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {
			SeleniumUtils.wait(5);
			HeaderFooterPage.clickSignInOrRegistration();
			SeleniumUtils.wait(5);
			LoginPage.clickCreateAccountLink();
			SeleniumUtils.wait(5);
			testcase.assertTrue(CreateAnAccountPage.isCreateAccWithEmailButton(),
					"Create Account page is displayed with Create Account with Email button",
					"Create Account page is not displayed with Create Account with Email button");
			testcase.assertTrue(CreateAnAccountPage.isFacebookIcon(),
					"Facebook icon is displayed in Create Account page",
					"Facebook icon is not displayed in Create Account page");
			testcase.assertTrue(CreateAnAccountPage.isTwitterIcon(), "Twitter icon is displayed in Create Account page",
					"Twitter icon is not displayed in Create Account page");
			testcase.assertTrue(CreateAnAccountPage.isGoogleIcon(), "Google icon is displayed in Create Account page",
					"Google icon is not displayed in Create Account page");
			testcase.assertTrue(CreateAnAccountPage.isAOLIcon(), "AOL icon is displayed in Create Account page",
					"AOL icon is not displayed in Create Account page");
			testcase.assertTrue(CreateAnAccountPage.isLinkedInIcon(),
					"Linked In icon is displayed in Create Account page",
					"Linked In icon is not displayed in Create Account page");
			testcase.assertTrue(CreateAnAccountPage.isYahooIcon(), "Yahoo icon is displayed in Create Account page",
					"Yahoo icon is not displayed in Create Account page");
			testcase.pass("UI of Create Account page with Create account with email button and social media icons");
		} catch (Exception e) {
			testcase.error("UI of Create Account page with Create account with email button and social media icons", e);
			e.printStackTrace();
		}
	}

	// To verify that the user is able to create account by through social media
	// link 'Facebook' in 'Create an Account' page.
	@Test
	public void facebookIconTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {
			SeleniumUtils.wait(5);
			HeaderFooterPage.clickSignInOrRegistration();
			SeleniumUtils.wait(5);
			LoginPage.clickCreateAccountLink();
			SeleniumUtils.wait(5);
			CreateAnAccountPage.clickFacebookIcon();
			SeleniumUtils.wait(5);
			String parentWindowHandler = DriverFactory.getDriver().getWindowHandle();
			String subWindowHandler = null;

			Set<String> handles = DriverFactory.getDriver().getWindowHandles();
			Iterator<String> iterator = handles.iterator();
			while (iterator.hasNext()) {
				subWindowHandler = iterator.next();
			}
			DriverFactory.getDriver().switchTo().window(subWindowHandler);
			// TBC has not yet implemented the social media login
			Thread.sleep(2000);
			DriverFactory.getDriver().close();

			DriverFactory.getDriver().switchTo().window(parentWindowHandler);
			testcase.pass("User is able to Log In to his account using Facebook icon in Create Account page");
		} catch (Exception e) {
			testcase.error("User is able to Log In to his account using Facebook icon in Create Account page", e);
			e.printStackTrace();
		}
	}

	// To verify that the user is able to create account by through social media
	// link 'Twitter' in 'Create an Account' page.
	@Test
	public void twitterIconTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {
			SeleniumUtils.wait(5);
			HeaderFooterPage.clickSignInOrRegistration();
			SeleniumUtils.wait(5);
			LoginPage.clickCreateAccountLink();
			SeleniumUtils.wait(5);
			CreateAnAccountPage.clickTwitterIcon();
			SeleniumUtils.wait(5);
			String parentWindowHandler = DriverFactory.getDriver().getWindowHandle();
			String subWindowHandler = null;

			Set<String> handles = DriverFactory.getDriver().getWindowHandles();
			Iterator<String> iterator = handles.iterator();
			while (iterator.hasNext()) {
				subWindowHandler = iterator.next();
			}
			DriverFactory.getDriver().switchTo().window(subWindowHandler);
			// TBC has not yet implemented the social media login
			Thread.sleep(2000);
			DriverFactory.getDriver().close();

			DriverFactory.getDriver().switchTo().window(parentWindowHandler);
			testcase.pass("User is able to Log In to his account using Twitter icon in Create Account page");
		} catch (Exception e) {
			testcase.error("User is able to Log In to his account using Twitter icon in Create Account page", e);
			e.printStackTrace();
		}
	}

	// To verify that the user is able to create account by through social media
	// link 'Google' in 'Create an Account' page.
	@Test
	public void googleIconTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {
			SeleniumUtils.wait(5);
			HeaderFooterPage.clickSignInOrRegistration();
			SeleniumUtils.wait(5);
			LoginPage.clickCreateAccountLink();
			SeleniumUtils.wait(5);
			CreateAnAccountPage.clickGoogleIcon();
			SeleniumUtils.wait(5);
			String parentWindowHandler = DriverFactory.getDriver().getWindowHandle();
			String subWindowHandler = null;

			Set<String> handles = DriverFactory.getDriver().getWindowHandles();
			Iterator<String> iterator = handles.iterator();
			while (iterator.hasNext()) {
				subWindowHandler = iterator.next();
			}
			DriverFactory.getDriver().switchTo().window(subWindowHandler);
			// TBC has not yet implemented the social media login
			Thread.sleep(2000);
			DriverFactory.getDriver().close();

			DriverFactory.getDriver().switchTo().window(parentWindowHandler);
			testcase.pass("User is able to Log In to his account using Google icon in Create Account page");
		} catch (Exception e) {
			testcase.error("User is able to Log In to his account using Google icon in Create Account page", e);
			e.printStackTrace();
		}
	}

	// To verify that the user is able to create account by through social media
	// link 'Yahoo' in 'Create an Account' page.
	@Test
	public void yahooIconTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {
			SeleniumUtils.wait(5);
			HeaderFooterPage.clickSignInOrRegistration();
			SeleniumUtils.wait(5);
			LoginPage.clickCreateAccountLink();
			SeleniumUtils.wait(5);
			CreateAnAccountPage.clickYahooIcon();
			SeleniumUtils.wait(5);
			String parentWindowHandler = DriverFactory.getDriver().getWindowHandle();
			String subWindowHandler = null;

			Set<String> handles = DriverFactory.getDriver().getWindowHandles();
			Iterator<String> iterator = handles.iterator();
			while (iterator.hasNext()) {
				subWindowHandler = iterator.next();
			}
			DriverFactory.getDriver().switchTo().window(subWindowHandler);
			// TBC has not yet implemented the social media login
			Thread.sleep(2000);
			DriverFactory.getDriver().close();

			DriverFactory.getDriver().switchTo().window(parentWindowHandler);
			testcase.pass("User is able to Log In to his account using Yahoo icon in Create Account page");
		} catch (Exception e) {
			testcase.error("User is able to Log In to his account using Yahoo icon in Create Account page", e);
			e.printStackTrace();
		}
	}

	// To verify that the user is able to create account by through social media
	// link 'LinkedIn' in 'Create an Account' page.
	@Test
	public void linkedInIconTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {
			SeleniumUtils.wait(5);
			HeaderFooterPage.clickSignInOrRegistration();
			SeleniumUtils.wait(5);
			LoginPage.clickCreateAccountLink();
			SeleniumUtils.wait(5);
			CreateAnAccountPage.clickLinkedInIcon();
			SeleniumUtils.wait(5);
			String parentWindowHandler = DriverFactory.getDriver().getWindowHandle();
			String subWindowHandler = null;

			Set<String> handles = DriverFactory.getDriver().getWindowHandles();
			Iterator<String> iterator = handles.iterator();
			while (iterator.hasNext()) {
				subWindowHandler = iterator.next();
			}
			DriverFactory.getDriver().switchTo().window(subWindowHandler);
			// TBC has not yet implemented the social media login
			Thread.sleep(2000);
			DriverFactory.getDriver().close();

			DriverFactory.getDriver().switchTo().window(parentWindowHandler);
			testcase.pass("User is able to Log In to his account using LinkedIn icon in Create Account page");
		} catch (Exception e) {
			testcase.error("User is able to Log In to his account using LinkedIn icon in Create Account page", e);
			e.printStackTrace();
		}
	}

	// To verify that the user is able to create account by through social media
	// link 'AOL' in 'Create an Account' page.
	@Test
	public void aOLIconTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {
			SeleniumUtils.wait(5);
			HeaderFooterPage.clickSignInOrRegistration();
			SeleniumUtils.wait(5);
			LoginPage.clickCreateAccountLink();
			SeleniumUtils.wait(5);
			CreateAnAccountPage.clickAOLIcon();
			SeleniumUtils.wait(5);
			String parentWindowHandler = DriverFactory.getDriver().getWindowHandle();
			String subWindowHandler = null;

			Set<String> handles = DriverFactory.getDriver().getWindowHandles();
			Iterator<String> iterator = handles.iterator();
			while (iterator.hasNext()) {
				subWindowHandler = iterator.next();
			}
			DriverFactory.getDriver().switchTo().window(subWindowHandler);
			// TBC has not yet implemented the social media login
			Thread.sleep(2000);
			DriverFactory.getDriver().close();

			DriverFactory.getDriver().switchTo().window(parentWindowHandler);
			testcase.pass("User is able to Log In to his account using AOL icon in Create Account page");
		} catch (Exception e) {
			testcase.error("User is able to Log In to his account using AOL icon in Create Account page", e);
			e.printStackTrace();
		}
	}

	// To verify the functionality of 'Create Account with Email' button in
	// 'Create an Account' page.
	@Test
	public void createAccountWithEmailTest() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {
			SeleniumUtils.wait(5);
			HeaderFooterPage.clickSignInOrRegistration();
			SeleniumUtils.wait(5);
			LoginPage.clickCreateAccountLink();
			SeleniumUtils.wait(5);
			testcase.assertTrue(CreateAnAccountPage.isCreateAccWithEmailButton(),
					"Create Account With Email button displayed", "Create Account With Email button not displayed");
			CreateAnAccountPage.clickCreateAccWithEmailButton();
			SeleniumUtils.wait(5);
			testcase.assertTrue(CreateAccWithEmailPage.isEmailAddressBox(), "Create Account With Email page displayed",
					"Create Account With Email page not displayed");
			testcase.pass("Display & Functionality of create account with Email button in Create Account page");
		} catch (Exception e) {
			testcase.error("Display & Functionality of create account with Email button in Create Account page", e);
			e.printStackTrace();
		}
	}
}
