package com.ch.ta.desktopTests;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ch.report.utils.AbstractTestCaseReport;
import com.ch.reports.TestCaseDetail;
import com.ch.reports.TestCaseFactory;
import com.ch.ta.desktopPages.HomePage;
import com.ch.ta.utils.CommonUtils;
import com.ch.ta.utils.constants.FileConstants;


@Listeners(com.ch.utils.ParallelFactory.class)
public class HomePageMYMTest extends AbstractTestCaseReport implements FileConstants {

	@BeforeMethod
	public void tyreURL() throws Exception {
		CommonUtils.desktopView();
		CommonUtils.TBCURL();
	}

	// Test Case : 50
	// To verify the functionality of ' Licence Plate' tab in vehicle selector
	// overlay.
	@Test
	public void licencePlateTabFunctionality() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.isMonetateBanner();
			testcase.assertTrue(HomePage.isMonetateBanner(), "System should display Monetate Banner ",
					"System is not displaying Monetate Banner ");
			testcase.pass("System should display Monetate Banner ");
		} catch (Exception e) {
			testcase.error("System is not displaying Monetate Banner ", e);
			e.printStackTrace();
		}
	}

	// Test Case : 51
	// To verify the user is able to enter License plate number in license plate
	// text field in license plate tab from vehicle selector overlay.
	@Test
	public void enterLicencePlateNum() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			testcase.assertTrue(HomePage.isProgressBar(), "System should display Progress Bar ",
					"System is not displaying Progress Bar ");
			testcase.pass("System should display Progress Bar ");
		} catch (Exception e) {
			testcase.error("System is not displaying Progress Bar ", e);
			e.printStackTrace();
		}
	}

	// Test Case : 52
	// To verify the functionality of 'Call To Action'(CTA >>) button in license
	// plate number tab.
	@Test
	public void progresBarWithoutSelectingVehicle() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.isProgBarYourVehicle();
			testcase.assertTrue(HomePage.isProgBarYourVehicle(),
					"System should display Progress Bar with first step(Your Vehicle) should be highlighted.",
					"System is not displaying Progress Bar with first step(Your Vehicle) should be highlighted. ");
			testcase.pass("System should display Progress Bar with first step(Your Vehicle) should be highlighted. ");
		} catch (Exception e) {
			testcase.error(
					"System is not displaying Progress Bar with first step(Your Vehicle) should be highlighted. ", e);
			e.printStackTrace();
		}
	}

	// Test Case : 53
	// To verify the display and functionality of '<< Cancel' button in License
	// Plate' tab
	@Test
	public void licencePlateCancleButton() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.isProgBarYourVehicle();
			testcase.assertTrue(HomePage.isProgBarYourVehicle(),
					"System should display Progress Bar with first step(Your Vehicle) should be highlighted.",
					"System is not displaying Progress Bar with first step(Your Vehicle) should be highlighted. ");
			testcase.pass("System should display Progress Bar with first step(Your Vehicle) should be highlighted. ");
		} catch (Exception e) {
			testcase.error(
					"System is not displaying Progress Bar with first step(Your Vehicle) should be highlighted. ", e);
			e.printStackTrace();
		}
	}

	// Test Case : 54
	// To verify the user is able to navigate to 'VIN' tab from 'License plate'
	// tab in the License plate tab in vehicle selector overlay
	@Test
	public void licensePlateTabToVINTab() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.isASpot();
			testcase.assertTrue(HomePage.isASpot(), "System should display A-Spot section as per the configuration.",
					"System is not displaying A-Spot section as per the configuration. ");
			testcase.pass("System should display A-Spot section as per the configuration.");
		} catch (Exception e) {
			testcase.error("System is not displaying A-Spot section as per the configuration. ", e);
			e.printStackTrace();
		}
	}

	// Test Case : 55
	// To verify that user is able to navigate to 'Make/Model' tab from 'License
	// Plate' tab in the vehicle selector overlay.
	@Test
	public void licensePlateTabToMYMTab() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.isASpotYmmeComponent();
			testcase.assertTrue(HomePage.isASpotYmmeComponent(),
					"System should display A-Spot YMME Component as per the configuration.",
					"System is not displaying A-Spot  YMME Component as per the configuration. ");
			testcase.pass("System should display A-Spot YMME Component as per the configuration.");
		} catch (Exception e) {
			testcase.error("System is not displaying A-Spot YMME Component as per the configuration. ", e);
			e.printStackTrace();
		}
	}

	// Test Case : 56
	// To verify the functionality of 'CTA>>' button without entering License
	// Plate Number in license text field.
	@Test
	public void verifyCTAButton() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.isShopByVehicleDefault();
			testcase.assertTrue(HomePage.isShopByVehicleDefault(),
					"System should display Shop by vehicle tab as default.",
					"System is not displaying Shop by vehicle tab as default.");
			testcase.pass("System should display Shop by vehicle tab as default.");
		} catch (Exception e) {
			testcase.error("System is not displaying Shop by vehicle tab as default.", e);
			e.printStackTrace();
		}
	}

	// Test Case : 57
	// To verify the user is able to view 'State drop down' when the user
	// entered invalid text in 'State field cum drop down.
	@Test
	public void verifyStateDropDownWithInvalidData() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.isLiveChat();
			testcase.assertTrue(HomePage.isLiveChat(), "System should display live chat button to the side of page.",
					"System is not displaying live chat button to the side of page.");
			testcase.pass("System should display live chat button to the side of page.");
		} catch (Exception e) {
			testcase.error("System is not displaying live chat button to the side of page.", e);
			e.printStackTrace();
		}
	}

	// Test Case : 58
	// To verify the display of 'Tire Size Selector' overlay when the user is
	// not selected tire size for the vehicle.
	@Test
	public void verifyTireSizeSelector() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.clickLikeChat();
			testcase.assertTrue(HomePage.isLiveChat(), "System should display live chat button to the side of page.",
					"System is not displaying live chat button to the side of page.");
			testcase.pass("System should display live chat button to the side of page.");
		} catch (Exception e) {
			testcase.error("System is not displaying live chat button to the side of page.", e);
			e.printStackTrace();
		}
	}

	// Test Case : 59
	// To verify the functionality of 'Width, Ratio and Diameter' fields in the
	// tire size selector.
	@Test
	public void verifyTireSizeSelectorFields() throws Exception {
		String name = new Object() {
		}.getClass().getEnclosingMethod().getName();
		TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
		try {

			HomePage.isHowitWorksComponents();
			testcase.assertTrue(HomePage.isHowitWorksComponents(),
					" System should display How it works component on home page.",
					"System is not displaying How it works component on home page.");
			testcase.pass(" System should display How it works component on home page.");
		} catch (Exception e) {
			testcase.error("System is not displaying How it works component on home page.", e);
			e.printStackTrace();
		}
	}

}
