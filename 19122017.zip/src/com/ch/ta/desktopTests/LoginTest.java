package com.ch.ta.desktopTests;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;

import org.apache.poi.poifs.storage.HeaderBlockWriter;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ch.ExcelUtils.ExcelProperty;
import com.ch.report.utils.AbstractTestCaseReport;
import com.ch.reports.TestCaseDetail;
import com.ch.reports.TestCaseFactory;
import com.ch.retry.Retry;
import com.ch.ta.desktopPages.CreateAnAccountPage;
import com.ch.ta.desktopPages.HeaderFooterPage;
import com.ch.ta.desktopPages.HomePage;
import com.ch.ta.desktopPages.LoginPage;
import com.ch.ta.desktopPages.MyAccountPage;
import com.ch.ta.utils.CommonUtils;
import com.ch.ta.utils.constants.FileConstants;
import com.ch.utils.DriverFactory;
import com.ch.utils.PropertyUtil;
import com.ch.utils.SeleniumHelperUtils;
import com.ch.utils.SeleniumUtils;

@Listeners(com.ch.utils.ParallelFactory.class)
public class LoginTest extends AbstractTestCaseReport implements FileConstants
{
    public void tyreURL() throws Exception
    {
        CommonUtils.desktopView();
        CommonUtils.TBCURL();
    }

    // To verify the display of 'Login' link in top right corner of the Homepage
    // To verify the functionality of the 'Login' link in the Home page
    @Test
    public void signInHomeTest() throws Exception
    {
        String name = new Object()
        {}.getClass().getEnclosingMethod().getName();
        TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
        Retry retry = new Retry(2);
        while (retry.retry())
        {
            try
            {
                tyreURL();
                HeaderFooterPage.verifySignInOrRegistration();
                SeleniumUtils.wait(5);
                HeaderFooterPage.clickSignInOrRegistration();
                LoginPage.isKeepMeLoggedInBox();
                LoginPage.isCreateAccountLink();
                LoginPage.isSignInButton();
                LoginPage.isEmailTextbox();
                HeaderFooterPage.clickSignInOrRegistration();
                LoginPage.isPasswordTextbox();
                LoginPage.isForgotPasswordLink();
                LoginPage.isForgotUsernameLink();
                testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
                        "Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
                testcase.pass("Display & functionality of Sign In link in Home page");
                break;
            } catch (Exception e)
            {
                testcase.retry("Display & functionality of Sign In link in Home page", testcase, retry, e);
                e.printStackTrace();
            }
        }
    }

    // To verify the UI of 'Login' page.
    // To verify the display of the 'Username' textbox in the Login Page.
    // To verify the display of the 'Password' textbox in the Login Page.
    // To verify the display of the 'Keep me Logged In ' in the Login page
    // To verify the display of the 'Log In' button in the Login page
    // To verify the display of the 'Social media icons' and 'Or Log In with'
    // static text in the login page.
    @Test
    public void signInUITest() throws Exception
    {
        String name = new Object()
        {}.getClass().getEnclosingMethod().getName();
        TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
        Retry retry = new Retry(2);
        while (retry.retry())
        {
            try
            {
                tyreURL();
                SeleniumUtils.wait(5);
                testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
                        "Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
                SeleniumUtils.wait(5);
                HeaderFooterPage.clickSignInOrRegistration();
                SeleniumUtils.wait(5);
                testcase.assertTrue(LoginPage.isEmailTextbox(), "Email text box is displayed in Sign In Flyout",
                        "Email text box is not displayed in Sign In Flyout");
                testcase.assertTrue(LoginPage.isPasswordTextbox(), "Password text box is displayed in Sign In Flyout",
                        "Password text box is not displayed in Sign In Flyout");
                testcase.assertTrue(LoginPage.isSignInButton(), "Sign In button is displayed in Sign In Flyout",
                        "Sign In button is not displayed in Sign In Flyout");
                testcase.assertTrue(LoginPage.isKeepMeLoggedInBox(),
                        "Keep Me logged in checkbox is displayed in Sign In Flyout",
                        "Keep Me logged in checkbox is not displayed in Sign In Flyout");
                testcase.assertTrue(LoginPage.isForgotUsernameLink(),
                        "Forgot Username link is displayed in Sign In Flyout",
                        "Forgot Username link is not displayed in Sign In Flyout");
                testcase.assertTrue(LoginPage.isForgotPasswordLink(),
                        "Forgot Password link is displayed in Sign In Flyout",
                        "Forgot Password link is not displayed in Sign In Flyout");
                testcase.assertTrue(LoginPage.isCreateAccountLink(),
                        "Create Account link is displayed in Sign In Flyout",
                        "Create Account link is not displayed in Sign In Flyout");
                // testcase.assertTrue(LoginPage.isFacebookIcon(), "Facebook
                // icon is displayed in Sign In Flyout",
                // "Facebook icon is not displayed in Sign In Flyout");
                // testcase.assertTrue(LoginPage.isTwitterIcon(), "Twitter icon
                // is displayed in Sign In Flyout",
                // "Twitter icon is not displayed in Sign In Flyout");
                // testcase.assertTrue(LoginPage.isGoogleIcon(), "Google icon is
                // displayed in Sign In Flyout",
                // "Google icon is not displayed in Sign In Flyout");
                // testcase.assertTrue(LoginPage.isAOLIcon(), "AOL icon is
                // displayed in Sign In Flyout",
                // "AOL icon is not displayed in Sign In Flyout");
                // testcase.assertTrue(LoginPage.isLinkedInIcon(), "Linked In
                // icon is displayed in Sign In Flyout",
                // "Linked In icon is not displayed in Sign In Flyout");
                // testcase.assertTrue(LoginPage.isYahooIcon(), "Yahoo icon is
                // displayed in Sign In Flyout",
                // "Yahoo icon is not displayed in Sign In Flyout");
                testcase.pass("Verifying UI of Sign In flyout");
                break;
            } catch (Exception e)
            {
                testcase.retry("Verifying UI of Sign In flyout", testcase, retry, e);
                e.printStackTrace();
            }
        }
    }

    // To verify the display of the 'Create Account ' link in the Login page.
    // To verify the functionality of the 'Create Account' link in the Login
    // Page.
    @Test
    public void createAccountLinkTest() throws Exception
    {
        String name = new Object()
        {}.getClass().getEnclosingMethod().getName();
        TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
        Retry retry = new Retry(2);
        while (retry.retry())
        {
            try
            {
                tyreURL();
                SeleniumUtils.wait(5);
                testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
                        "Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
                SeleniumUtils.wait(5);
                HeaderFooterPage.clickSignInOrRegistration();
                SeleniumUtils.wait(5);
                testcase.assertTrue(LoginPage.isCreateAccountLink(),
                        "Create Account link is displayed in Sign In Flyout",
                        "Create Account link is not displayed in Sign In Flyout");
                LoginPage.clickCreateAccountLink();
                SeleniumUtils.wait(5);
                testcase.assertTrue(CreateAnAccountPage.isTitleStaticTextCreateAccount(),
                        "Create Account page is displayed with Create Account with Email button",
                        "Create Account page is not displayed with Create Account with Email button");
                testcase.pass("Create Account page is displayed on clicking create Account link in SignIn flyout");
                break;
            } catch (Exception e)
            {
                testcase.retry("Create Account page is displayed on clicking create Account link in SignIn flyout",
                        testcase, retry, e);
                e.printStackTrace();
            }
        }
    }

    // To verify the display of the 'Username' placeholder in the Login Page.
    // To verify that the 'Username' placeholder disappears when textbox is
    // focused in the Login page.
    @Test
    public void usernamePlaceholderTest() throws Exception
    {
        String name = new Object()
        {}.getClass().getEnclosingMethod().getName();
        TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
        Retry retry = new Retry(2);
        while (retry.retry())
        {
            try
            {
                tyreURL();
                SeleniumUtils.wait(5);
                testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
                        "Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
                SeleniumUtils.wait(5);
                HeaderFooterPage.clickSignInOrRegistration();
                SeleniumUtils.wait(5);
                testcase.assertEquals("Username", SeleniumUtils
                        .getAttributes(ExcelProperty.getElementValue(SIGN_IN, EMAIL_TEXTBOX), "placeholder"));
                SeleniumUtils.wait(5);
                LoginPage.enterEmailInTextbox("set@gmail.com");
                SeleniumUtils.wait(5);
                testcase.assertEquals("", SeleniumUtils
                        .getAttributes(ExcelProperty.getElementValue(SIGN_IN, EMAIL_TEXTBOX), "placeholder"));
                testcase.pass("Display of placeholder before and after clicking on the Email Address textbox");
                break;
            } catch (Exception e)
            {
                testcase.retry("Display of placeholder before and after clicking on the Email Address textbox",
                        testcase, retry, e);
                e.printStackTrace();
            }
        }
    }

    // To verify the display of the 'Password' placeholder in the Login Page.
    // To verify that the 'Password' placeholder disappears when textbox is
    // focused in the Login page.
    @Test
    public void passwordPlaceholderTest() throws Exception
    {
        String name = new Object()
        {}.getClass().getEnclosingMethod().getName();
        TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
        Retry retry = new Retry(2);
        while (retry.retry())
        {
            try
            {
                tyreURL();
                SeleniumUtils.wait(5);
                testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
                        "Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
                SeleniumUtils.wait(5);
                HeaderFooterPage.clickSignInOrRegistration();
                SeleniumUtils.wait(5);
                testcase.assertEquals("Password", SeleniumUtils
                        .getAttributes(ExcelProperty.getElementValue(SIGN_IN, PASSWORD_TEXTBOX), "placeholder"));
                SeleniumUtils.wait(5);
                LoginPage.enterPasswordInTextbox("pwd");
                SeleniumUtils.wait(5);
                testcase.assertEquals("", SeleniumUtils
                        .getAttributes(ExcelProperty.getElementValue(SIGN_IN, PASSWORD_TEXTBOX), "placeholder"));
                testcase.pass("Display of placeholder before and after clicking on the Password textbox");
                break;
            } catch (Exception e)
            {
                testcase.retry("Display of placeholder before and after clicking on the Password textbox", testcase,
                        retry, e);
                e.printStackTrace();
            }
        }
    }

    // To verify the functionality of the 'Login In' button in the login page.
    @Test
    public void validLoginTest() throws Exception
    {
        String name = new Object()
        {}.getClass().getEnclosingMethod().getName();
        TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
        Retry retry = new Retry(2);
        while (retry.retry())
        {
            try
            {

                tyreURL();
                SeleniumUtils.wait(5);
                testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
                        "Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
                SeleniumUtils.wait(5);
                HeaderFooterPage.clickSignInOrRegistration();
                SeleniumUtils.wait(5);
                LoginPage.enterEmailInTextbox("set@gmail.com");
                SeleniumUtils.wait(5);
                LoginPage.enterPasswordInTextbox("test@123");
                SeleniumUtils.wait(5);
                LoginPage.clickSignInButton();
                SeleniumUtils.wait(20);
                HeaderFooterPage.onHoverMyAccount();
                testcase.assertTrue(HeaderFooterPage.verifyMyAccount(), "User has successfully logged In",
                        "User has has not logged In");
                testcase.pass("User is able to Log In to his account by entering valid credentials in Sign In flyout");

                break;
            } catch (Exception e)
            {
                testcase.retry("User is able to Log In to his account by entering valid credentials in Sign In flyout",
                        testcase, retry, e);
                e.printStackTrace();
            }
        }
    }

    // To verify the error message when 'Username' and 'Password' fields are
    // left blank in login page.
    // To verify the error message when 'Password' field is left blank in the
    // login page.
    // To verify the error message when 'Username' left blank in the login page
    // To verify the error message when user enters 'Username' in Invalid format
    // in the login page
    // To verify the error message when user enters 'Password' in Invalid format
    // in the login page
    // To verify the error message when user enters 'Username' and 'Password' in
    // Invalid format in the login page
    // To verify the error message when user enters unregistered 'Username' in
    // the login page
    @Test
    public void invalidLoginTest() throws Exception
    {
        String name = new Object()
        {}.getClass().getEnclosingMethod().getName();
        TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
        Retry retry = new Retry(2);
        while (retry.retry())
        {
            try
            {
                tyreURL();
                SeleniumUtils.wait(5);
                testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
                        "Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
                SeleniumUtils.wait(5);
                HeaderFooterPage.clickSignInOrRegistration();
                SeleniumUtils.wait(5);
                ArrayList<InvalidLoginDatabean> data = FileUtility1.readDataFromCsv();
                for (Iterator<InvalidLoginDatabean> iterator = data.iterator(); iterator.hasNext();)
                {
                    InvalidLoginDatabean databean = (InvalidLoginDatabean) iterator.next();
                    LoginPage.enterEmailInTextbox(databean.getUsername());
                    System.out.println(databean.getUsername());
                    LoginPage.enterPasswordInTextbox(databean.getPassword());
                    System.out.println(databean.getPassword());
                    LoginPage.clickSignInButton();
                    try
                    {
                        // testcase.assertEquals(databean.getErrormessage(),SigninPage.errorMsgInvalid());
                    } catch (Exception e)
                    {
                        // testcase.assertEquals(databean.getErrormessage(),SigninPage.errorMsgInvalid());
                    }
                }

                testcase.pass("Error Messages for sign In with invalid data in Sign In flyout");
                break;
            } catch (Exception e)
            {
                testcase.retry("Error Messages for sign In with invalid data in Sign In flyout", testcase, retry, e);
                e.printStackTrace();
            }
        }
    }

    // To Verify the display of the 'Forgot password? ' link in the Login page.

    @Test
    public void forgotPasswordTest() throws Exception
    {
        String name = new Object()
        {}.getClass().getEnclosingMethod().getName();
        TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
        Retry retry = new Retry(2);
        while (retry.retry())
        {
            try
            {
                tyreURL();
                SeleniumUtils.wait(5);
                testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
                        "Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
                SeleniumUtils.wait(5);
                HeaderFooterPage.clickSignInOrRegistration();
                SeleniumUtils.wait(5);
                testcase.assertTrue(LoginPage.isForgotPasswordLink(),
                        "Forgot Username or Password link is displayed in Sign In flyout",
                        "Forgot Username or Password link is not displayed in Sign In flyout");
                SeleniumUtils.wait(5);
                LoginPage.clickForgotPasswordLink();
                SeleniumUtils.wait(5);
                testcase.assertTrue(LoginPage.verifyForgetPaswdTextInPopup(),
                        "Forgot Username or Password link is displayed in Sign In flyout",
                        "Forgot Username or Password link is not displayed in Sign In flyout");
                testcase.pass("Verifying UI & functionality of Forgot Username or Password link in Sign In flyout");
                break;
            } catch (Exception e)
            {
                testcase.retry("Verifying UI & functionality of Forgot Username or Password link in Sign In flyout",
                        testcase, retry, e);
                e.printStackTrace();
            }
        }
    }

    // To Verify the functionality of the 'Forgot Username? ' link in the Login
    // page.

    @Test
    public void forgotEmailTest() throws Exception
    {
        String name = new Object()
        {}.getClass().getEnclosingMethod().getName();
        TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
        Retry retry = new Retry(2);
        while (retry.retry())
        {
            try
            {
                tyreURL();
                SeleniumUtils.wait(5);
                testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
                        "Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
                SeleniumUtils.wait(5);
                HeaderFooterPage.clickSignInOrRegistration();
                SeleniumUtils.wait(5);
                testcase.assertTrue(LoginPage.isForgotUsernameLink(),
                        "Forgot Username or Password link is displayed in Sign In flyout",
                        "Forgot Username or Password link is not displayed in Sign In flyout");
                SeleniumUtils.wait(5);
                LoginPage.clickForgotUsernameLink();
                SeleniumUtils.wait(5);
                testcase.assertTrue(LoginPage.verifyForgetUserTextInPopup(),
                        "Forgot Username or Password link is displayed in Sign In flyout",
                        "Forgot Username or Password link is not displayed in Sign In flyout");
                testcase.pass("Verifying UI & functionality of Forgot Username or Password link in Sign In flyout");
                break;
            } catch (Exception e)
            {
                testcase.retry("Verifying UI & functionality of Forgot Username or Password link in Sign In flyout",
                        testcase, retry, e);
                e.printStackTrace();
            }
        }
    }

    // To verify the display of the 'Social media icons' and 'Or Sign In with'
    // static text in the Sign In flyout on the homepage.

    @Test
    public void socialmediaIconsandSignInText() throws Exception
    {
        String name = new Object()
        {}.getClass().getEnclosingMethod().getName();
        TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
        Retry retry = new Retry(2);
        while (retry.retry())
        {
            try
            {
                tyreURL();
                SeleniumUtils.wait(5);
                testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
                        "Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
                SeleniumUtils.wait(5);
                HeaderFooterPage.clickSignInOrRegistration();
                SeleniumUtils.wait(5);
                testcase.assertTrue(LoginPage.isdisplayedSocialMediaicons(), "Social media icons are displayed",
                        "Social media icons are displayed");
                testcase.pass("Verifying UI of social media icons and sigin in text link in Sign In flyout");
                break;
            } catch (Exception e)
            {
                testcase.retry("Verifying UI of social media icons and sigin in text link in Sign In flyout", testcase,
                        retry, e);
                e.printStackTrace();
            }
        }
    }

    // To verify the functionality of the 'Facebook' login in the Login Page
    @Test
    public void facebookIconTest() throws Exception
    {
        String name = new Object()
        {}.getClass().getEnclosingMethod().getName();
        TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
        Retry retry = new Retry(2);
        while (retry.retry())
        {
            try
            {
                tyreURL();
                SeleniumUtils.wait(5);
                testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
                        "Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
                SeleniumUtils.wait(5);
                HeaderFooterPage.clickSignInOrRegistration();
                SeleniumUtils.wait(5);
                LoginPage.clickFacebookIcon();
                SeleniumUtils.wait(5);
                String parentWindowHandler = DriverFactory.getDriver().getWindowHandle();
                String subWindowHandler = null;

                Set<String> handles = DriverFactory.getDriver().getWindowHandles();
                Iterator<String> iterator = handles.iterator();
                while (iterator.hasNext())
                {
                    subWindowHandler = iterator.next();
                }
                DriverFactory.getDriver().switchTo().window(subWindowHandler);
                // TBC has not yet implemented the social media login
                Thread.sleep(2000);
                DriverFactory.getDriver().close();

                DriverFactory.getDriver().switchTo().window(parentWindowHandler);
                testcase.pass("User is able to Log In to his account using Facebook icon in Sign In flyout");
                break;
            } catch (Exception e)
            {
                testcase.retry("User is able to Log In to his account using Facebook icon in Sign In flyout", testcase,
                        retry, e);
                e.printStackTrace();
            }
        }
    }

    // To verify the functionality of the 'Twitter' login in the Login Page
    @Test
    public void twitterIconTest() throws Exception
    {
        String name = new Object()
        {}.getClass().getEnclosingMethod().getName();
        TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
        Retry retry = new Retry(2);
        while (retry.retry())
        {
            try
            {
                tyreURL();
                SeleniumUtils.wait(5);
                testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
                        "Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
                SeleniumUtils.wait(5);
                HeaderFooterPage.clickSignInOrRegistration();
                SeleniumUtils.wait(5);
                LoginPage.clickTwitterIcon();
                SeleniumUtils.wait(5);
                String parentWindowHandler = DriverFactory.getDriver().getWindowHandle();
                String subWindowHandler = null;

                Set<String> handles = DriverFactory.getDriver().getWindowHandles();
                Iterator<String> iterator = handles.iterator();
                while (iterator.hasNext())
                {
                    subWindowHandler = iterator.next();
                }
                DriverFactory.getDriver().switchTo().window(subWindowHandler);
                // TBC has not yet implemented the social media login
                Thread.sleep(2000);
                DriverFactory.getDriver().close();

                DriverFactory.getDriver().switchTo().window(parentWindowHandler);
                testcase.pass("User is able to Log In to his account using Twitter icon in Sign In flyout");
                break;
            } catch (Exception e)
            {
                testcase.retry("User is able to Log In to his account using Twitter icon in Sign In flyout", testcase,
                        retry, e);
                e.printStackTrace();
            }
        }
    }

    // To verify the functionality of the 'Google' login in the Login Page
    @Test
    public void googleIconTest() throws Exception
    {
        String name = new Object()
        {}.getClass().getEnclosingMethod().getName();
        TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
        Retry retry = new Retry(2);
        while (retry.retry())
        {
            try
            {
                tyreURL();
                SeleniumUtils.wait(5);
                testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
                        "Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
                SeleniumUtils.wait(5);
                HeaderFooterPage.clickSignInOrRegistration();
                SeleniumUtils.wait(5);
                LoginPage.clickGoogleIcon();
                SeleniumUtils.wait(5);
                String parentWindowHandler = DriverFactory.getDriver().getWindowHandle();
                String subWindowHandler = null;

                Set<String> handles = DriverFactory.getDriver().getWindowHandles();
                Iterator<String> iterator = handles.iterator();
                while (iterator.hasNext())
                {
                    subWindowHandler = iterator.next();
                }
                DriverFactory.getDriver().switchTo().window(subWindowHandler);
                // TBC has not yet implemented the social media login
                Thread.sleep(2000);
                DriverFactory.getDriver().close();

                DriverFactory.getDriver().switchTo().window(parentWindowHandler);
                testcase.pass("User is able to Log In to his account using Google icon in Sign In flyout");
                break;
            } catch (Exception e)
            {
                testcase.retry("User is able to Log In to his account using Google icon in Sign In flyout", testcase,
                        retry, e);
                e.printStackTrace();
            }
        }
    }

    // To verify the functionality of the 'Yahoo' login in the Login Page
    @Test
    public void yahooIconTest() throws Exception
    {
        String name = new Object()
        {}.getClass().getEnclosingMethod().getName();
        TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
        Retry retry = new Retry(2);
        while (retry.retry())
        {
            try
            {
                tyreURL();
                SeleniumUtils.wait(5);
                testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
                        "Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
                SeleniumUtils.wait(5);
                HeaderFooterPage.clickSignInOrRegistration();
                SeleniumUtils.wait(5);
                LoginPage.clickYahooIcon();
                SeleniumUtils.wait(5);
                String parentWindowHandler = DriverFactory.getDriver().getWindowHandle();
                String subWindowHandler = null;

                Set<String> handles = DriverFactory.getDriver().getWindowHandles();
                Iterator<String> iterator = handles.iterator();
                while (iterator.hasNext())
                {
                    subWindowHandler = iterator.next();
                }
                DriverFactory.getDriver().switchTo().window(subWindowHandler);
                // TBC has not yet implemented the social media login
                Thread.sleep(2000);
                DriverFactory.getDriver().close();

                DriverFactory.getDriver().switchTo().window(parentWindowHandler);
                testcase.pass("User is able to Log In to his account using Yahoo icon in Sign In flyout");
                break;
            } catch (Exception e)
            {
                testcase.retry("User is able to Log In to his account using Yahoo icon in Sign In flyout", testcase,
                        retry, e);
                e.printStackTrace();
            }
        }
    }

    // To verify the functionality of the 'LinkedIn' login in the Login Page
    @Test
    public void linkedInIconTest() throws Exception
    {
        String name = new Object()
        {}.getClass().getEnclosingMethod().getName();
        TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
        Retry retry = new Retry(2);
        while (retry.retry())
        {
            try
            {
                tyreURL();
                SeleniumUtils.wait(5);
                testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
                        "Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
                SeleniumUtils.wait(5);
                HeaderFooterPage.clickSignInOrRegistration();
                SeleniumUtils.wait(5);
                LoginPage.clickLinkedInIcon();
                SeleniumUtils.wait(5);
                String parentWindowHandler = DriverFactory.getDriver().getWindowHandle();
                String subWindowHandler = null;

                Set<String> handles = DriverFactory.getDriver().getWindowHandles();
                Iterator<String> iterator = handles.iterator();
                while (iterator.hasNext())
                {
                    subWindowHandler = iterator.next();
                }
                DriverFactory.getDriver().switchTo().window(subWindowHandler);
                // TBC has not yet implemented the social media login
                Thread.sleep(2000);
                DriverFactory.getDriver().close();

                DriverFactory.getDriver().switchTo().window(parentWindowHandler);
                testcase.pass("User is able to Log In to his account using LinkedIn icon in Sign In flyout");
                break;
            } catch (Exception e)
            {
                testcase.retry("User is able to Log In to his account using LinkedIn icon in Sign In flyout", testcase,
                        retry, e);
                e.printStackTrace();
            }
        }
    }

    // To verify the functionality of the 'AOL' login in the Login Page
    @Test
    public void aOLIconTest() throws Exception
    {
        String name = new Object()
        {}.getClass().getEnclosingMethod().getName();
        TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
        Retry retry = new Retry(2);
        while (retry.retry())
        {
            try
            {
                tyreURL();
                SeleniumUtils.wait(5);
                testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
                        "Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
                SeleniumUtils.wait(5);
                HeaderFooterPage.clickSignInOrRegistration();
                SeleniumUtils.wait(5);
                LoginPage.clickAOLIcon();
                SeleniumUtils.wait(5);
                String parentWindowHandler = DriverFactory.getDriver().getWindowHandle();
                String subWindowHandler = null;

                Set<String> handles = DriverFactory.getDriver().getWindowHandles();
                Iterator<String> iterator = handles.iterator();
                while (iterator.hasNext())
                {
                    subWindowHandler = iterator.next();
                }
                DriverFactory.getDriver().switchTo().window(subWindowHandler);
                // TBC has not yet implemented the social media login
                Thread.sleep(2000);
                DriverFactory.getDriver().close();

                DriverFactory.getDriver().switchTo().window(parentWindowHandler);
                testcase.pass("User is able to Log In to his account using AOL icon in Sign In flyout");
                break;
            } catch (Exception e)
            {
                testcase.retry("User is able to Log In to his account using AOL icon in Sign In flyout", testcase,
                        retry, e);
                e.printStackTrace();
            }
        }
    }

    // To verify the functionality of the 'Keep me logged in' checkbox in the
    // Login Page.
    // To verify that the site is populated with credentials of user with 'Keep
    // me logged In' functionality the next time user opens the site.
    @Test
    public void selectKeepMeLoggedInTest() throws Exception
    {
        String name = new Object()
        {}.getClass().getEnclosingMethod().getName();
        TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
        Retry retry = new Retry(2);
        while (retry.retry())
        {
            try
            {
                tyreURL();
                SeleniumUtils.wait(5);
                testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
                        "Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
                SeleniumUtils.wait(5);
                HeaderFooterPage.clickSignInOrRegistration();
                SeleniumUtils.wait(5);
                LoginPage.enterEmailInTextbox("set@gmail.com");
                SeleniumUtils.wait(5);
                LoginPage.enterPasswordInTextbox("test@123");
                SeleniumUtils.wait(5);
                LoginPage.clickKeepMeLoggedIn();
                SeleniumUtils.wait(5);
                LoginPage.clickSignInButton();
                SeleniumUtils.wait(20);
                MyAccountPage.hoverOnMyAccount();
                SeleniumUtils.wait(5);
                MyAccountPage.clickSignOutLink();
                SeleniumUtils.wait(5);
                HeaderFooterPage.clickSignInOrRegistration();
                SeleniumUtils.wait(5);
                testcase.assertEquals("", LoginPage.keepMeLoggedInCheckbox());
                testcase.pass("Functionality of Keep me Logged In Check box selected in Sign In flyout");
                break;
            } catch (Exception e)
            {
                testcase.retry("Functionality of Keep me Logged In Check box selected in Sign In flyout", testcase,
                        retry, e);
                e.printStackTrace();
            }
        }
    }

    // To verify that the site is not populated with credentials of user with
    // 'Keep me logged In' functionality after user manually clearing the
    // cookies.
    @Test
    public void unselectKeepMeLoggedInTest() throws Exception
    {
        String name = new Object()
        {}.getClass().getEnclosingMethod().getName();
        TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
        Retry retry = new Retry(2);
        while (retry.retry())
        {
            try
            {
                tyreURL();
                SeleniumUtils.wait(5);
                testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
                        "Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
                SeleniumUtils.wait(5);
                HeaderFooterPage.clickSignInOrRegistration();
                SeleniumUtils.wait(5);
                LoginPage.signInWithFields("test@gmail.com", "test@123");
                SeleniumUtils.wait(5);
                LoginPage.clickKeepMeLoggedIn();
                SeleniumUtils.wait(5);
                LoginPage.clickKeepMeLoggedIn();
                SeleniumUtils.wait(5);
                MyAccountPage.hoverOnMyAccount();
                SeleniumUtils.wait(5);
                MyAccountPage.clickSignOutLink();
                SeleniumUtils.wait(5);
                HeaderFooterPage.clickSignInOrRegistration();
                SeleniumUtils.wait(5);
                testcase.assertEquals("", LoginPage.keepMeLoggedInCheckbox());
                testcase.pass("Functionality of Keep me Logged In Check box unselected in Sign In flyout");
                break;
            } catch (Exception e)
            {
                testcase.retry("Functionality of Keep me Logged In Check box unselected in Sign In flyout", testcase,
                        retry, e);
                e.printStackTrace();
            }
        }
    }

    // To verify the warning message when user enters wrong password for maximum
    // number of times in the login page.
    @Test
    public void warningInvalidLoginTest() throws Exception
    {
        String name = new Object()
        {}.getClass().getEnclosingMethod().getName();
        TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
        Retry retry = new Retry(2);
        while (retry.retry())
        {
            try
            {
                tyreURL();
                SeleniumUtils.wait(5);
                testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
                        "Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
                SeleniumUtils.wait(5);
                HeaderFooterPage.clickSignInOrRegistration();
                SeleniumUtils.wait(5);
                ArrayList<InvalidLoginDatabean> data = FileUtility1.readDataFromCsv();
                for (Iterator<InvalidLoginDatabean> iterator = data.iterator(); iterator.hasNext();)
                {
                    InvalidLoginDatabean databean = (InvalidLoginDatabean) iterator.next();
                    LoginPage.enterEmailInTextbox(databean.getUsername());
                    System.out.println(databean.getUsername());
                    LoginPage.enterPasswordInTextbox(databean.getPassword());
                    System.out.println(databean.getPassword());
                    LoginPage.clickSignInButton();
                }
                SeleniumUtils.wait(5);
                testcase.assertTrue(LoginPage.isWarningMessage(), "Warning message on 5 unsuccessful login",
                        "Warning message on 5 unsuccessful login not displayed");
                testcase.assertEquals(
                        "You have reached the maximum number of attempts allowed. Click here to Restore Your Account",
                        SeleniumUtils.getText(ExcelProperty.getElementValue(SIGN_IN, WARNING_MESSAGE)));
                testcase.pass("Warning message on 5 unsuccessful login is displayed");
                break;
            } catch (Exception e)
            {
                testcase.retry("Warning message on 5 unsuccessful login is displayed", testcase, retry, e);
                e.printStackTrace();
            }
        }
    }

    // To verify the functionality of the 'Restore Your Account' link in the
    // login page
    @Test
    public void restoreYourAccountLink() throws Exception
    {
        String name = new Object()
        {}.getClass().getEnclosingMethod().getName();
        TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
        Retry retry = new Retry(2);
        while (retry.retry())
        {
            try
            {
                tyreURL();
                SeleniumUtils.wait(5);
                testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
                        "Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
                SeleniumUtils.wait(5);
                HeaderFooterPage.clickSignInOrRegistration();
                SeleniumUtils.wait(5);
                ArrayList<InvalidLoginDatabean> data = FileUtility1.readDataFromCsv();
                for (Iterator<InvalidLoginDatabean> iterator = data.iterator(); iterator.hasNext();)
                {
                    InvalidLoginDatabean databean = (InvalidLoginDatabean) iterator.next();
                    LoginPage.enterEmailInTextbox(databean.getUsername());
                    System.out.println(databean.getUsername());
                    LoginPage.enterPasswordInTextbox(databean.getPassword());
                    System.out.println(databean.getPassword());
                    LoginPage.clickSignInButton();
                }
                SeleniumUtils.wait(5);
                testcase.assertTrue(LoginPage.isWarningMessage(), "Warning message on 5 unsuccessful login",
                        "Warning message on 5 unsuccessful login not displayed");
                testcase.assertEquals(
                        "You have reached the maximum number of attempts allowed. Click here to Restore Your Account",
                        SeleniumUtils.getText(ExcelProperty.getElementValue(SIGN_IN, WARNING_MESSAGE)));
                SeleniumUtils.wait(5);
                LoginPage.clickRestoreYourAccountLink();
                SeleniumUtils.wait(5);
                // assertion to be added after next sprint release
                testcase.pass(
                        "System should navigate to the respective page and allow the user to restore the account.");
                break;
            } catch (Exception e)
            {
                testcase.retry(
                        "System should navigate to the respective page and allow the user to restore the account.",
                        testcase, retry, e);
                e.printStackTrace();
            }
        }

    }
    // To verify the error message when 'Username' and 'Password' fields are
    // left blank in sign in a flyout on the homepage.

    @Test
    public void verifyErrorMsgwithEmptyUsernamePassword() throws Exception
    {
        String name = new Object()
        {}.getClass().getEnclosingMethod().getName();
        TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
        Retry retry = new Retry(2);
        while (retry.retry())
        {
            try
            {
                tyreURL();
                SeleniumUtils.wait(5);
                testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
                        "Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
                SeleniumUtils.wait(5);
                HeaderFooterPage.clickSignInOrRegistration();
                SeleniumUtils.wait(5);
                LoginPage.clickSignInButton();
                testcase.assertTrue(LoginPage.isusernameErrorMsg(),
                        "Error message is displayed when user has left username as blank",
                        "Error message is displayed when user has left username as blank");
                testcase.assertTrue(LoginPage.isPasswordErrorMsg(),
                        "Error message is displayed when user has left password as blank",
                        "Error message is displayed when user has left password as blank");

                testcase.pass(
                        "System is displaying error messages when user left blank in username and passowrd feilds");
                break;
            } catch (Exception e)
            {
                testcase.retry(
                        "System is displaying error messages when user left blank in username and passowrd feilds",
                        testcase, retry, e);
                e.printStackTrace();
            }
        }
    }

    // To verify the display of error message when 'username' field is left
    // blank in the sign in a flyout on the homepage.

    @Test
    public void verifyErrorMsgwithEmptyUsername() throws Exception
    {
        String name = new Object()
        {}.getClass().getEnclosingMethod().getName();
        TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
        Retry retry = new Retry(2);
        while (retry.retry())
        {
            try
            {
                tyreURL();
                SeleniumUtils.wait(5);
                testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
                        "Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
                SeleniumUtils.wait(5);
                HeaderFooterPage.clickSignInOrRegistration();
                SeleniumUtils.wait(5);
                LoginPage.enterPasswordInTextbox("test@123");
                SeleniumUtils.wait(5);
                LoginPage.clickSignInButton();
                testcase.assertTrue(LoginPage.isusernameErrorMsg(),
                        "Error message is displayed when user has left username as blank",
                        "Error message is displayed when user has left username as blank");

                testcase.pass("System is displaying error messages when user left blank in username feilds");
                break;
            } catch (Exception e)
            {
                testcase.retry("System is displaying error messages when user left blank in username feilds", testcase,
                        retry, e);
                e.printStackTrace();
            }
        }
    }

    // To verify the display of error message when 'Password' field is left
    // blank in the sign in a flyout on the homepage.

    @Test
    public void verifyErrorwithEmptyPassword() throws Exception
    {
        String name = new Object()
        {}.getClass().getEnclosingMethod().getName();
        TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
        Retry retry = new Retry(2);
        while (retry.retry())
        {
            try
            {
                tyreURL();
                SeleniumUtils.wait(5);
                testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
                        "Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
                SeleniumUtils.wait(5);
                HeaderFooterPage.clickSignInOrRegistration();
                SeleniumUtils.wait(5);
                LoginPage.enterEmailInTextbox("set@gmail.com");
                SeleniumUtils.wait(5);
                LoginPage.clickSignInButton();
                testcase.assertTrue(LoginPage.isPasswordErrorMsg(),
                        "Error message is displayed when user has left password as blank",
                        "Error message is displayed when user has left password as blank");

                testcase.pass("System is displaying error messages when user left blank in password feilds");
                break;
            } catch (Exception e)
            {
                testcase.retry("System is displaying error messages when user left blank in password feilds", testcase,
                        retry, e);
                e.printStackTrace();
            }
        }
    }

    // To verify the error message when the user entered Invalid 'Username' in
    // the sign in flyout on the homepage.

    @Test
    public void verifyErrorMsgwithInvalidUsername() throws Exception
    {
        String name = new Object()
        {}.getClass().getEnclosingMethod().getName();
        TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
        Retry retry = new Retry(2);
        while (retry.retry())
        {
            try
            {
                tyreURL();
                SeleniumUtils.wait(5);
                testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
                        "Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
                SeleniumUtils.wait(5);
                HeaderFooterPage.clickSignInOrRegistration();
                SeleniumUtils.wait(5);
                LoginPage.enterEmailInTextbox("%&&%$@24");
                SeleniumUtils.wait(5);
                LoginPage.enterPasswordInTextbox("test@123");
                SeleniumUtils.wait(5);
                LoginPage.clickSignInButton();
                testcase.assertTrue(LoginPage.isPasswordErrorMsg(),
                        "Error message is displayed when user has entered invalid username",
                        "Error message is displayed when user has entered invalid username");

                testcase.pass("System is displaying error message when user has entered invalid username");
                break;
            } catch (Exception e)
            {
                testcase.retry("System is displaying error message when user has entered invalid username", testcase,
                        retry, e);
                e.printStackTrace();
            }
        }
    }

    // To verify the display of error message when user entered invalid
    // 'Username' and 'Password' in the sign in flyout on the homepage.

    @Test
    public void verifyErrorMsgwithInvalidDetails() throws Exception
    {
        String name = new Object()
        {}.getClass().getEnclosingMethod().getName();
        TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
        Retry retry = new Retry(2);
        while (retry.retry())
        {
            try
            {
                tyreURL();
                SeleniumUtils.wait(5);
                testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
                        "Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
                SeleniumUtils.wait(5);
                LoginPage.enterEmailInTextbox("13231323");
                SeleniumUtils.wait(5);
                LoginPage.enterPasswordInTextbox("13231323");
                SeleniumUtils.wait(5);
                HeaderFooterPage.clickSignInOrRegistration();
                SeleniumUtils.wait(5);
                LoginPage.clickSignInButton();
                SeleniumUtils.wait(5);
                testcase.assertTrue(LoginPage.isusernameErrorMsg(),
                        "Error message is displayed when user has left username as blank",
                        "Error message is displayed when user has left username as blank");
                testcase.assertTrue(LoginPage.isPasswordErrorMsg(),
                        "Error message is displayed when user has left password as blank",
                        "Error message is displayed when user has left password as blank");

                testcase.pass(
                        "System is displaying error messages when user left blank in username and passowrd feilds");
                break;
            } catch (Exception e)
            {
                testcase.retry(
                        "System is displaying error messages when user left blank in username and passowrd feilds",
                        testcase, retry, e);
                e.printStackTrace();
            }
        }
    }

    // To verify the display of error message when user entered invalid
    // 'Password' in the sign in flyout
    @Test
    public void verifyErrorwithInvalidPassword() throws Exception
    {
        String name = new Object()
        {}.getClass().getEnclosingMethod().getName();
        TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
        Retry retry = new Retry(2);
        while (retry.retry())
        {
            try
            {
                tyreURL();
                SeleniumUtils.wait(5);
                testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
                        "Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
                SeleniumUtils.wait(5);
                HeaderFooterPage.clickSignInOrRegistration();
                SeleniumUtils.wait(5);
                LoginPage.enterEmailInTextbox("set@gmail.com");
                SeleniumUtils.wait(5);
                LoginPage.enterPasswordInTextbox("*(^%hxdsu8");
                SeleniumUtils.wait(5);
                LoginPage.clickSignInButton();
                testcase.assertTrue(LoginPage.isPasswordErrorMsg(),
                        "Error message is displayed when user has enterd invalid password",
                        "Error message is displayed when user has enterd invalid password");

                testcase.pass("System is displaying error messages when user has enterd invalid password");
                break;
            } catch (Exception e)
            {
                testcase.retry("System is displaying error messages when user has enterd invalid password", testcase,
                        retry, e);
                e.printStackTrace();
            }
        }
    }

    // To verify the display of error message when the user entered unregistered
    // 'Username' in 'Username' field in the sign in flyout on the homepage.
    @Test
    public void verifyErrorwithUnregisterUsername() throws Exception
    {
        String name = new Object()
        {}.getClass().getEnclosingMethod().getName();
        TestCaseDetail testcase = TestCaseFactory.createTestCaseDetail(this.getClass(), name);
        Retry retry = new Retry(2);
        while (retry.retry())
        {
            try
            {
                tyreURL();
                SeleniumUtils.wait(5);
                testcase.assertTrue(HeaderFooterPage.verifySignInOrRegistration(),
                        "Sign In link is displayed in Home page", "Sign In link is not displayed in Home page");
                SeleniumUtils.wait(5);
                HeaderFooterPage.clickSignInOrRegistration();
                SeleniumUtils.wait(5);
                LoginPage.enterEmailInTextbox("demo@gmail.com");
                SeleniumUtils.wait(5);
                // LoginPage.enterPasswordInTextbox("demo@123");
                SeleniumUtils.wait(5);
                LoginPage.clickSignInButton();
                testcase.assertTrue(LoginPage.isPasswordErrorMsg(),
                        "Error message is displayed when user has enterd Unregistered password",
                        "Error message is displayed when user has enterd Unregistered password");
                testcase.assertTrue(LoginPage.isusernameErrorMsg(),
                        "Error message is displayed when user has enterd Unregistered username",
                        "Error message is displayed when user has enterd Unregistered username");

                testcase.pass(
                        "System is displaying error messages when user has enterd Unregistered username and  password");
                break;
            } catch (Exception e)
            {
                testcase.retry(
                        "System is displaying error messages when user has enterd Unregistered username and  password",
                        testcase, retry, e);
                e.printStackTrace();
            }
        }
    }

    // To verify the warning message when user enters wrong password for maximum
    // number of times in the sign in flyout.

    // Not automatable

}
