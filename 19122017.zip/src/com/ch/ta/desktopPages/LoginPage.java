package com.ch.ta.desktopPages;

import com.ch.ExcelUtils.ExcelProperty;
import com.ch.ta.utils.constants.FileConstants;
import com.ch.utils.SeleniumUtils;

public class LoginPage implements FileConstants
{

    public static boolean isEmailTextbox() throws Exception
    {
        boolean flag = false;
        try
        {
            flag = SeleniumUtils.iSDisplayed(ExcelProperty.getElementValue(SIGN_IN, EMAIL_TEXTBOX));
        } catch (Exception e)
        {
            e.printStackTrace();
        }
        System.out.println("Email textbox is displayed in Sign In flyout");
        return flag;
    }

    public static boolean isPasswordTextbox() throws Exception
    {
        boolean flag = false;
        try
        {
            flag = SeleniumUtils.iSDisplayed(ExcelProperty.getElementValue(SIGN_IN, PASSWORD_TEXTBOX));
        } catch (Exception e)
        {
            e.printStackTrace();
        }
        System.out.println("Password textbox is displayed in Sign In flyout");
        return flag;
    }

    public static boolean isSignInButton() throws Exception
    {
        boolean flag = false;
        try
        {
            flag = SeleniumUtils.iSDisplayed(ExcelProperty.getElementValue(SIGN_IN, SIGN_IN_BUTTON));
        } catch (Exception e)
        {
            e.printStackTrace();
        }
        System.out.println("Sign In button is displayed in Sign In flyout");
        return flag;
    }

    public static boolean isKeepMeLoggedInBox() throws Exception
    {
        boolean flag = false;
        try
        {
            flag = SeleniumUtils.iSDisplayed(ExcelProperty.getElementValue(SIGN_IN, KEEP_ME_LOGGED_IN));
        } catch (Exception e)
        {
            e.printStackTrace();
        }
        System.out.println("Keep me logged in check box is displayed in Sign In flyout");
        return flag;
    }

    public static boolean isForgotUsernameLink() throws Exception
    {
        boolean flag = false;
        try
        {
            flag = SeleniumUtils.iSDisplayed(ExcelProperty.getElementValue(SIGN_IN, FORGOT_USERNAME_LINK));
        } catch (Exception e)
        {
            e.printStackTrace();
        }
        System.out.println("Forgot Username or Password link is displayed in Sign In flyout");
        return flag;
    }

    public static boolean isForgotPasswordLink() throws Exception
    {
        boolean flag = false;
        try
        {
            flag = SeleniumUtils.iSDisplayed(ExcelProperty.getElementValue(SIGN_IN, FORGOT_PWD_LINK));
        } catch (Exception e)
        {
            e.printStackTrace();
        }
        System.out.println("Forgot Username or Password link is displayed in Sign In flyout");
        return flag;
    }
    
    public static boolean isCreateAccountLink() throws Exception
    {
        boolean flag = false;
        try
        {
            flag = SeleniumUtils.iSDisplayed(ExcelProperty.getElementValue(SIGN_IN, CREATE_AN_ACCOUNT_LINK));
        } catch (Exception e)
        {
            e.printStackTrace();
        }
        System.out.println("Create account link is displayed in Sign In flyout");
        return flag;
    }

    public static boolean isFacebookIcon() throws Exception
    {
        boolean flag = false;
        try
        {
            flag = SeleniumUtils.iSDisplayed(ExcelProperty.getElementValue(SIGN_IN, FACEBOOK_ICON));
        } catch (Exception e)
        {
            e.printStackTrace();
        }
        System.out.println("Facebook icon is displayed in Sign In flyout");
        return flag;
    }

    public static boolean isTwitterIcon() throws Exception
    {
        boolean flag = false;
        try
        {
            flag = SeleniumUtils.iSDisplayed(ExcelProperty.getElementValue(SIGN_IN, TWITTER_ICON));
        } catch (Exception e)
        {
            e.printStackTrace();
        }
        System.out.println("Twitter icon is displayed in Sign In flyout");
        return flag;
    }

    public static boolean isGoogleIcon() throws Exception
    {
        boolean flag = false;
        try
        {
            flag = SeleniumUtils.iSDisplayed(ExcelProperty.getElementValue(SIGN_IN, GOOGLE_ICON));
        } catch (Exception e)
        {
            e.printStackTrace();
        }
        System.out.println("Google icon is displayed in Sign In flyout");
        return flag;
    }

    public static boolean isYahooIcon() throws Exception
    {
        boolean flag = false;
        try
        {
            flag = SeleniumUtils.iSDisplayed(ExcelProperty.getElementValue(SIGN_IN, YAHOO_ICON));
        } catch (Exception e)
        {
            e.printStackTrace();
        }
        System.out.println("Yahoo icon is displayed in Sign In flyout");
        return flag;
    }

    public static boolean isAOLIcon() throws Exception
    {
        boolean flag = false;
        try
        {
            flag = SeleniumUtils.iSDisplayed(ExcelProperty.getElementValue(SIGN_IN, AOL_ICON));
        } catch (Exception e)
        {
            e.printStackTrace();
        }
        System.out.println("AOL icon is displayed in Sign In flyout");
        return flag;
    }

    public static boolean isLinkedInIcon() throws Exception
    {
        boolean flag = false;
        try
        {
            flag = SeleniumUtils.iSDisplayed(ExcelProperty.getElementValue(SIGN_IN, LINKED_IN_ICON));
        } catch (Exception e)
        {
            e.printStackTrace();
        }
        System.out.println("LinkedIn icon is displayed in Sign In flyout");
        return flag;
    }

    public static void clickCreateAccountLink() throws Exception
    {
        SeleniumUtils.click(ExcelProperty.getElementValue(SIGN_IN, CREATE_AN_ACCOUNT_LINK));
        System.out.println("Create account link is clicked in Sign In flyout");
    }

    public static void clickKeepMeLoggedIn() throws Exception
    {
        SeleniumUtils.click(ExcelProperty.getElementValue(SIGN_IN, KEEP_ME_LOGGED_IN));
        System.out.println("keep me logged in check box is selected in Sign In flyout");
    }

    public static void clickEmailTextbox() throws Exception
    {
        SeleniumUtils.click(ExcelProperty.getElementValue(SIGN_IN, EMAIL_TEXTBOX));
        System.out.println("Email address text box is clicked in Sign In flyout");
    }

    public static void clickPasswordTextbox() throws Exception
    {
        SeleniumUtils.click(ExcelProperty.getElementValue(SIGN_IN, PASSWORD_TEXTBOX));
        System.out.println("Password text box is clicked in Sign In flyout");
    }

    public static void clickSignInButton() throws Exception
    {
        SeleniumUtils.click(ExcelProperty.getElementValue(SIGN_IN, SIGN_IN_BUTTON));
        System.out.println("Sign In button is clicked in Sign In flyout");
    }

    public static void clickForgotUsernameLink() throws Exception
    {
        SeleniumUtils.click(ExcelProperty.getElementValue(SIGN_IN, FORGOT_USERNAME_LINK));
        System.out.println("Forgot Password link is clicked in Sign In flyout");
    }

    public static void clickForgotPasswordLink() throws Exception
    {
        SeleniumUtils.click(ExcelProperty.getElementValue(SIGN_IN, FORGOT_PWD_LINK));
        System.out.println("Forgot Password link is clicked in Sign In flyout");
    }
    
    public static void clickFacebookIcon() throws Exception
    {
        SeleniumUtils.click(ExcelProperty.getElementValue(SIGN_IN, FACEBOOK_ICON));
        System.out.println("Facebook icon is clicked in Sign In flyout");
    }

    public static void clickTwitterIcon() throws Exception
    {
        SeleniumUtils.click(ExcelProperty.getElementValue(SIGN_IN, TWITTER_ICON));
        System.out.println("Twitter icon is clicked in Sign In flyout");
    }

    public static void clickGoogleIcon() throws Exception
    {
        SeleniumUtils.click(ExcelProperty.getElementValue(SIGN_IN, GOOGLE_ICON));
        System.out.println("Google icon is clicked in Sign In flyout");
    }

    public static void clickYahooIcon() throws Exception
    {
        SeleniumUtils.click(ExcelProperty.getElementValue(SIGN_IN, YAHOO_ICON));
        System.out.println("Yahoo icon is clicked in Sign In flyout");
    }

    public static void clickAOLIcon() throws Exception
    {
        SeleniumUtils.click(ExcelProperty.getElementValue(SIGN_IN, AOL_ICON));
        System.out.println("AOL icon is clicked in Sign In flyout");
    }

    public static void clickLinkedInIcon() throws Exception
    {
        SeleniumUtils.click(ExcelProperty.getElementValue(SIGN_IN, LINKED_IN_ICON));
        System.out.println("LinkedIn icon is clicked in Sign In flyout");
    }
    
    public static void enterEmailInTextbox(String email) throws Exception
    {
        SeleniumUtils.sendKeys(ExcelProperty.getElementValue(SIGN_IN, EMAIL_TEXTBOX), email);
        System.out.println("Email address is entered in email textbox in Sign In flyout");
    }
    
    public static void enterPasswordInTextbox(String pwd) throws Exception
    {
        SeleniumUtils.sendKeys(ExcelProperty.getElementValue(SIGN_IN, PASSWORD_TEXTBOX), pwd);
        System.out.println("password is entered in password textbox in Sign In flyout");
    }

    public static void signInWithFields(String email, String password) throws Exception
    {
        SeleniumUtils.sendKeys(ExcelProperty.getElementValue(SIGN_IN, EMAIL_TEXTBOX), email);
        SeleniumUtils.sendKeys(ExcelProperty.getElementValue(SIGN_IN, PASSWORD_TEXTBOX), password);
        SeleniumUtils.click(ExcelProperty.getElementValue(SIGN_IN, SIGN_IN_BUTTON));
        System.out.println("Email address, Password is entered textboxes, Sign In button is clicked in Sign In flyout");
    }
    
    public static String keepMeLoggedInCheckbox() throws Exception
    {
        System.out.println("value in email textbox is returned in Sign In flyout");
        return SeleniumUtils.getAttributes(ExcelProperty.getElementValue(SIGN_IN, EMAIL_TEXTBOX), "value");
    }
    
    public static boolean isWarningMessage() throws Exception
    {
        boolean flag = false;
        try
        {
            flag = SeleniumUtils.iSDisplayed(ExcelProperty.getElementValue(SIGN_IN, WARNING_MESSAGE));
        } catch (Exception e)
        {
            e.printStackTrace();
        }
        System.out.println("Warning message for 5 unsuccessful logins is displayed in Sign In flyout");
        return flag;
    }
    
    public static void clickRestoreYourAccountLink() throws Exception
    {
        SeleniumUtils.click(ExcelProperty.getElementValue(SIGN_IN, RESTORE_YOUR_ACC_LINK));
        System.out.println("Restore Your Account link is clicked in Sign In flyout");
    }

	public static boolean verifyForgetPaswdTextInPopup() {
		 boolean flag = false;
	        try
	        {
	            flag = SeleniumUtils.iSDisplayed(ExcelProperty.getElementValue(SIGN_IN, FORGET_PASSWORD_STATIC_TEXT));
	        } catch (Exception e)
	        {
	            e.printStackTrace();
	        }
	        System.out.println("Warning message for 5 unsuccessful logins is displayed in Sign In flyout");
	        return flag;
	}

	public static boolean isusernameErrorMsg() {
		 boolean flag = false;
	        try
	        {
	            flag = SeleniumUtils.iSDisplayed(ExcelProperty.getElementValue(SIGN_IN, USERNAME_ERROR_MESSAGE));
	        } catch (Exception e)
	        {
	            e.printStackTrace();
	        }
	        System.out.println("Error message should be displayed");
	        return flag;
	}

	public static boolean isPasswordErrorMsg() {
		 boolean flag = false;
	        try
	        {
	            flag = SeleniumUtils.iSDisplayed(ExcelProperty.getElementValue(SIGN_IN, PASSWORD_ERROR_MESSAGE));
	        } catch (Exception e)
	        {
	            e.printStackTrace();
	        }
	        System.out.println("Error message should be displayed");
	        return flag;
	}

	public static boolean isdisplayedSocialMediaicons() {
		boolean flag = false;
        try
        {
        	 flag = SeleniumUtils.iSDisplayed(ExcelProperty.getElementValue(SIGN_IN, FACEBOOK_ICON));
        	 flag = SeleniumUtils.iSDisplayed(ExcelProperty.getElementValue(SIGN_IN, TWITTER_ICON));
            flag = SeleniumUtils.iSDisplayed(ExcelProperty.getElementValue(SIGN_IN, AOL_ICON));
            flag = SeleniumUtils.iSDisplayed(ExcelProperty.getElementValue(SIGN_IN, LINKED_IN_ICON));
            flag = SeleniumUtils.iSDisplayed(ExcelProperty.getElementValue(SIGN_IN, GOOGLE_ICON));
        } catch (Exception e)
        {
            e.printStackTrace();
        }
        System.out.println("Social media icons should be displayed");
        return flag;
	}

	public static boolean verifyForgetUserTextInPopup() {
		 boolean flag = false;
	        try
	        {
	            flag = SeleniumUtils.iSDisplayed(ExcelProperty.getElementValue(SIGN_IN, FORGET_PASSWORD_STATIC_TEXT));
	        } catch (Exception e)
	        {
	            e.printStackTrace();
	        }
	        System.out.println("Clicking on forget email should navigate to Forget email popup");
	        return flag;
	}

	
}
