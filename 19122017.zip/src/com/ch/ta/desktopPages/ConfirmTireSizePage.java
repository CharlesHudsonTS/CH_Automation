package com.ch.ta.desktopPages;

import com.ch.ExcelUtils.ExcelProperty;
import com.ch.ta.utils.constants.FileConstants;
import com.ch.utils.PropertyUtil;
import com.ch.utils.SeleniumUtils;

public class ConfirmTireSizePage implements FileConstants
{
    public static void clickVinLink() throws Exception
    {
        SeleniumUtils.click(ExcelProperty.getElementValue("", ""));
    }

    public static void VinTabData(String data) throws Exception
    {
        SeleniumUtils.sendKeys(ExcelProperty.getElementValue("", ""), data);
    }

    public static void clickCallToAction() throws Exception
    {
        SeleniumUtils.click(ExcelProperty.getElementValue("", ""));
    }

    public static void clickBackLInk() throws Exception
    {
        SeleniumUtils.click(ExcelProperty.getElementValue("", ""));

    }

    public static void clicOnlyTireSize() throws Exception
    {
        SeleniumUtils.click(ExcelProperty.getElementValue("", ""));

    }

    public static void clicTireSize() throws Exception
    {
        SeleniumUtils.click(ExcelProperty.getElementValue("", ""));
    }

    public static void clickNotTireSize() throws Exception
    {
        SeleniumUtils.click(ExcelProperty.getElementValue("", ""));
    }

    public static void clickRearTireSize() throws Exception
    {
        SeleniumUtils.click(ExcelProperty.getElementValue("", ""));
    }

    public static boolean isRearTireSizeDropDowns() throws Exception
    {
        String element = PropertyUtil.getStaticText("");
        boolean flag = false;
        try
        {
            flag = SeleniumUtils.iSDisplayed(ExcelProperty.getElementValue("", ""));
            flag = SeleniumUtils.iSDisplayed(ExcelProperty.getElementValue("", ""));
            flag = SeleniumUtils.iSDisplayed(ExcelProperty.getElementValue("", ""));
            flag = SeleniumUtils.PageSourceContains(element);
        } catch (Exception e)
        {
            e.printStackTrace();
        }
        return flag;

    }

    public static void tireSizeFeatures(String data, String data1, String data2) throws Exception
    {
        SeleniumUtils.sendKeys(ExcelProperty.getElementValue("", ""), data);
        SeleniumUtils.sendKeys(ExcelProperty.getElementValue("", ""), data);
        SeleniumUtils.sendKeys(ExcelProperty.getElementValue("", ""), data);
        System.out.println("All aspects of tire size are entered");
    }

    public static void clickCustomerSizeResults() throws Exception
    {
        SeleniumUtils.click(ExcelProperty.getElementValue("", ""));

    }

    public static void clickStaggeredFitment() throws Exception
    {
        SeleniumUtils.click(ExcelProperty.getElementValue("", ""));
    }

    public static void clickFrontTires() throws Exception
    {
        SeleniumUtils.click(ExcelProperty.getElementValue("", ""));
    }

    public static void clickRearTires() throws Exception
    {
        SeleniumUtils.click(ExcelProperty.getElementValue("", ""));
    }

    public static void clickIconNearRearTire() throws Exception
    {
        SeleniumUtils.click(ExcelProperty.getElementValue("", ""));
    }

    public static void clickAccordionNotTireSize() throws Exception
    {
        SeleniumUtils.click(ExcelProperty.getElementValue("", ""));
    }

    public static void clickFindMyTireSize() throws Exception
    {
        SeleniumUtils.click(ExcelProperty.getElementValue("", ""));
    }

    public static void clickVehicleSelector() throws Exception
    {
        SeleniumUtils.click(ExcelProperty.getElementValue("", ""));
    }
}
